import os as local_value_1136
import torch.nn as local_value_1094
import torch as local_value_1650

def execute_step_0338(name, local_value_0687):
    local_value_1674 = local_value_1136.environ.get(name)
    if local_value_1674 is None:
        return bool(local_value_0687)
    local_value_1674 = local_value_1674.strip().lower()
    if local_value_1674 in ('1', 'true', 'yes', 'on'):
        return True
    if local_value_1674 in ('0', 'false', 'no', 'off'):
        return False
    raise ValueError(f'{name} must be 0/1 or true/false, got {local_value_1674!r}')

def execute_step_0345():
    local_value_1674 = local_value_1136.environ.get('SDN_DECODER_VARIANT')
    if local_value_1674 is None:
        return None
    local_value_1674 = local_value_1674.strip().lower()
    local_value_0412 = {'shallow': 'shallow', 'cross_scale': 'shallow', 'cross-scale': 'shallow', 'full': 'full', 'mcfbr': 'full'}
    if local_value_1674 not in local_value_0412:
        raise ValueError('Unknown SDN_DECODER_VARIANT={!r}. Use shallow / full.'.format(local_value_1674))
    return local_value_0412[local_value_1674]

class ComponentUnit0066(local_value_1094.Module):

    def __init__(local_value_1336, local_value_0962, local_value_1171, local_value_1006=1, stride=1, local_value_1192=0, dilation=1, groups=1, bias=True):
        super().__init__()
        local_value_1336.member_slot_0169 = local_value_1094.Sequential(local_value_1094.Conv2d(local_value_0962, local_value_1171, local_value_1006, stride, local_value_1192, dilation, groups, bias), local_value_1094.GroupNorm(local_value_1171 // 8, local_value_1171))

    def forward(local_value_1336, local_value_1699):
        return local_value_1336.member_slot_0169(local_value_1699)

class ComponentUnit0178(local_value_1094.Module):

    def __init__(local_value_1336, local_value_0980=2048, local_value_0825=768, local_value_0949=False):
        super().__init__()
        local_value_1336.member_slot_0394 = local_value_1094.Linear(local_value_0980, local_value_0825)
        if local_value_0949:
            local_value_1336.member_slot_0394 = local_value_1094.Identity()

    def forward(local_value_1336, local_value_1699):
        n, local_value_0272, h, local_value_1683 = local_value_1699.shape
        local_value_1699 = local_value_1699.flatten(2).transpose(1, 2)
        local_value_1699 = local_value_1336.member_slot_0394(local_value_1699)
        local_value_1699 = local_value_1699.permute(0, 2, 1).reshape(n, -1, h, local_value_1683)
        return local_value_1699

class ComponentUnit0219(local_value_1094.Module):

    def __init__(local_value_1336, dim):
        super().__init__()
        local_value_1336.member_slot_0155 = local_value_1094.Conv2d(in_channels=dim, out_channels=1, kernel_size=1)
        local_value_1336.sigmoid = local_value_1094.Sigmoid()

    def forward(local_value_1336, local_value_1701, local_value_1702, local_value_1703, local_value_1704):
        local_value_0272, local_value_0272, h, local_value_1683 = local_value_1701.shape
        local_value_0420 = local_value_1336.sigmoid(local_value_1336.member_slot_0155(local_value_1701))
        local_value_1702 = local_value_1094.Upsample(size=(h, local_value_1683), mode='bilinear')(local_value_1702)
        local_value_1703 = local_value_1094.Upsample(size=(h, local_value_1683), mode='bilinear')(local_value_1703)
        local_value_1704 = local_value_1094.Upsample(size=(h, local_value_1683), mode='bilinear')(local_value_1704)
        local_value_1702 = local_value_1702 * local_value_0420
        local_value_1703 = local_value_1703 * local_value_0420
        local_value_1704 = local_value_1704 * local_value_0420
        return (local_value_1702, local_value_1703, local_value_1704)

class ComponentUnit0181(local_value_1094.Module):

    def __init__(local_value_1336, dim):
        super().__init__()
        local_value_1336.member_slot_0174 = local_value_1094.Conv2d(dim, dim, kernel_size=3, padding=1, dilation=1, groups=dim, bias=False)
        local_value_1336.member_slot_0175 = local_value_1094.Conv2d(dim, dim, kernel_size=3, padding=2, dilation=2, groups=dim, bias=False)
        local_value_1336.member_slot_0176 = local_value_1094.Conv2d(dim, dim, kernel_size=3, padding=3, dilation=3, groups=dim, bias=False)
        local_value_1336.member_slot_0285 = local_value_1094.Sequential(local_value_1094.Conv2d(dim * 3, dim, kernel_size=1, bias=False), local_value_1094.GroupNorm(max(1, dim // 8), dim), local_value_1094.ReLU(inplace=True))

    def forward(local_value_1336, local_value_1699):
        local_value_1701 = local_value_1336.member_slot_0174(local_value_1699)
        local_value_1702 = local_value_1336.member_slot_0175(local_value_1699)
        local_value_1703 = local_value_1336.member_slot_0176(local_value_1699)
        local_value_1699 = local_value_1650.cat([local_value_1701, local_value_1702, local_value_1703], dim=1)
        return local_value_1336.member_slot_0285(local_value_1699)

class ComponentUnit0040(local_value_1094.Module):

    def __init__(local_value_1336, dim):
        super().__init__()
        local_value_1336.member_slot_0399 = local_value_1094.Sequential(local_value_1094.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim, bias=False), local_value_1094.GroupNorm(max(1, dim // 8), dim), local_value_1094.ReLU(inplace=True), local_value_1094.Conv2d(dim, dim, kernel_size=1, bias=False))

    def forward(local_value_1336, local_value_1699):
        return local_value_1699 + local_value_1336.member_slot_0399(local_value_1699)

class ContourFusionDecoder(local_value_1094.Module):

    def __init__(local_value_1336, local_value_0826, local_value_1046=8, size=(512, 512)):
        super(ContourFusionDecoder, local_value_1336).__init__()
        local_value_1336.size = size
        local_value_1336.member_slot_0238 = execute_step_0345()
        if local_value_1336.member_slot_0238 is None:
            local_value_1336.member_slot_0471 = execute_step_0338('SDN_USE_MSCONV_FORWARD', True)
        else:
            local_value_1336.member_slot_0471 = local_value_1336.member_slot_0238 == 'full'
        local_value_1336.member_slot_0351 = ComponentUnit0178(local_value_0980=local_value_0826[0], local_value_0825=local_value_1046)
        local_value_1336.member_slot_0352 = ComponentUnit0178(local_value_0980=local_value_0826[1], local_value_0825=local_value_1046)
        local_value_1336.member_slot_0353 = ComponentUnit0178(local_value_0980=local_value_0826[2], local_value_0825=local_value_1046)
        local_value_1336.member_slot_0354 = ComponentUnit0178(local_value_0980=local_value_0826[3], local_value_0825=local_value_1046)
        local_value_1336.member_slot_0212 = ComponentUnit0066(local_value_0962=local_value_1046, local_value_1171=local_value_1046)
        local_value_1336.member_slot_0213 = ComponentUnit0066(local_value_0962=local_value_1046, local_value_1171=local_value_1046)
        local_value_1336.member_slot_0215 = ComponentUnit0066(local_value_0962=local_value_1046, local_value_1171=local_value_1046)
        local_value_1336.member_slot_0216 = ComponentUnit0066(local_value_0962=local_value_1046, local_value_1171=local_value_1046)
        local_value_1336.member_slot_0444 = ComponentUnit0219(dim=local_value_1046)
        if local_value_1336.member_slot_0238 == 'shallow':
            local_value_1336.member_slot_0437 = ComponentUnit0066(local_value_0962=local_value_1046 * 4, local_value_1171=local_value_1046)
            local_value_1336.member_slot_0357 = None
            local_value_1336.member_slot_0169 = None
            local_value_1336.member_slot_0172 = None
        else:
            local_value_1336.member_slot_0357 = ComponentUnit0181(local_value_1046 * 4)
            local_value_1336.member_slot_0169 = local_value_1094.Sequential(ComponentUnit0066(local_value_0962=local_value_1046 * 4, local_value_1171=local_value_1046 * 4), ComponentUnit0066(local_value_0962=local_value_1046 * 4, local_value_1171=local_value_1046), local_value_1094.ReLU())
            local_value_1336.member_slot_0172 = ComponentUnit0040(local_value_1046)
            local_value_1336.member_slot_0437 = None
        local_value_1336.member_slot_0335 = local_value_1094.Sequential(local_value_1094.Conv2d(local_value_1046, local_value_1046 // 4, 1), local_value_1094.Conv2d(local_value_1046 // 4, local_value_1046 // 4, 1, groups=local_value_1046 // 4), local_value_1094.Conv2d(local_value_1046 // 4, 1, kernel_size=1), local_value_1094.Conv2d(1, 1, kernel_size=1))

    def forward(local_value_1336, inputs):
        local_value_1701, local_value_1702, local_value_1703, local_value_1704 = inputs
        local_value_1701 = local_value_1336.member_slot_0212(local_value_1336.member_slot_0351(local_value_1701))
        local_value_1702 = local_value_1336.member_slot_0213(local_value_1336.member_slot_0352(local_value_1702))
        local_value_1703 = local_value_1336.member_slot_0215(local_value_1336.member_slot_0353(local_value_1703))
        local_value_1704 = local_value_1336.member_slot_0216(local_value_1336.member_slot_0354(local_value_1704))
        local_value_1702, local_value_1703, local_value_1704 = local_value_1336.member_slot_0444(local_value_1701, local_value_1702, local_value_1703, local_value_1704)
        local_value_1336.local_value_1177 = [local_value_1701, local_value_1702, local_value_1703, local_value_1704]
        local_value_1701 = local_value_1094.Upsample(size=local_value_1336.size, mode='bilinear')(local_value_1701)
        local_value_1702 = local_value_1094.Upsample(size=local_value_1336.size, mode='bilinear')(local_value_1702)
        local_value_1703 = local_value_1094.Upsample(size=local_value_1336.size, mode='bilinear')(local_value_1703)
        local_value_1704 = local_value_1094.Upsample(size=local_value_1336.size, mode='bilinear')(local_value_1704)
        local_value_1699 = local_value_1650.cat([local_value_1701, local_value_1702, local_value_1703, local_value_1704], dim=1)
        if local_value_1336.member_slot_0238 == 'shallow':
            local_value_1699 = local_value_1336.member_slot_0437(local_value_1699)
        else:
            if local_value_1336.member_slot_0471:
                local_value_1699 = local_value_1336.member_slot_0357(local_value_1699)
            local_value_1699 = local_value_1336.member_slot_0169(local_value_1699)
            local_value_1699 = local_value_1336.member_slot_0172(local_value_1699)
        local_value_1699 = local_value_1336.member_slot_0335(local_value_1699)
        return local_value_1699
