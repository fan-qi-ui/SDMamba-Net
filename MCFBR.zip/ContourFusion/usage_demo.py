import torch as runtime_core
from public_entry import CrossScaleBoundaryUnit

chosen_device = 'cuda' if runtime_core.cuda.is_available() else 'cpu'
chosen_unit = CrossScaleBoundaryUnit(target_shape=(64, 64)).to(chosen_device).eval()
feature_bundle = [runtime_core.randn(1, width, side, side, device=chosen_device)
                  for width, side in [(16, 16), (32, 8), (64, 4), (128, 2)]]
with runtime_core.no_grad():
    print(chosen_unit(feature_bundle).shape)
