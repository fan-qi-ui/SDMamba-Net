import os as settings_core
import torch as runtime_core
if __package__:
    from .implementation.components.synthesis_path.contour_fusion import ContourFusionDecoder as DecoderKernel
else:
    from implementation.components.synthesis_path.contour_fusion import ContourFusionDecoder as DecoderKernel


class CrossScaleBoundaryUnit(runtime_core.nn.Module):
    def __init__(self, stage_widths=(16, 32, 64, 128), inner_width=8, target_shape=(512, 512)):
        super().__init__()
        former_setting = settings_core.environ.get('SDN_DECODER_VARIANT')
        try:
            settings_core.environ['SDN_DECODER_VARIANT'] = 'full'
            self.content_route = DecoderKernel(list(stage_widths), local_value_1046=inner_width, size=target_shape)
        finally:
            if former_setting is None:
                settings_core.environ.pop('SDN_DECODER_VARIANT', None)
            else:
                settings_core.environ['SDN_DECODER_VARIANT'] = former_setting

    def forward(self, feature_pyramid):
        return self.content_route(feature_pyramid)
