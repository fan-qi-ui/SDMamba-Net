# CrackMix

对应 SDMamba-Net1114.docx 第 4.1 节的数据集设置。此目录为原项目 `dataset/min` 的完整副本，仅将副本的顶层目录名称改为文章中的 CrackMix；图像、标注、文件名与原始划分保持不变。

| 划分 | 图像 | 标注 | DeepCrack 图像 | CrackMap 图像 |
| --- | ---: | ---: | ---: | ---: |
| train_img / train_lab | 384 | 384 | 300 | 84 |
| test_img / test_lab | 261 | 261 | 237 | 24 |
| 合计 | 645 | 645 | 537 | 108 |

逐文件核对图像与标注的文件名主干配对，并以 SHA-256 确认其与 min 原文件和对应 DeepCrack / CrackMap 来源文件一致。未加入 CrackMap 的 val 划分，保持文章中 645 张的现有划分。

`FILE_MANIFEST.csv` 记录每个数据文件的来源、大小与 SHA-256。本文没有向原数据目录添加任何文件。数据许可沿用 DeepCrack 和 CrackMap 原始数据集的条款，本次复制不另行授予许可。
