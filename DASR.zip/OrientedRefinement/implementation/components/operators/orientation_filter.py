import math as local_value_1039
import einops as local_value_0824
import torch as local_value_1650
import torch.nn as local_value_1094
import torch.nn.functional as local_value_0117

class ComponentUnit0115(local_value_1094.Module):

    def __init__(local_value_1336, in_channels, local_value_1045, out_channels, kernel_size=3, bias=True):
        super().__init__()
        local_value_1336.member_slot_0319 = local_value_1094.Conv2d(in_channels=in_channels, out_channels=local_value_1045, kernel_size=1, bias=bias)
        local_value_1336.member_slot_0475 = local_value_1094.Conv2d(local_value_1045, local_value_1045, kernel_size=(1, kernel_size), stride=1, padding=(0, kernel_size // 2), groups=local_value_1045)
        local_value_1336.member_slot_0305 = local_value_1094.Conv2d(local_value_1045, local_value_1045, kernel_size=(kernel_size, 1), stride=1, padding=(kernel_size // 2, 0), groups=local_value_1045)
        local_value_1336.member_slot_0381 = local_value_1094.Conv2d(in_channels=local_value_1045 * 2, out_channels=out_channels, kernel_size=1, bias=True)

    def forward(local_value_1336, local_value_1699):
        local_value_1699 = local_value_1336.member_slot_0319(local_value_1699)
        local_value_1729 = local_value_1336.member_slot_0475(local_value_1699)
        local_value_1711 = local_value_1336.member_slot_0305(local_value_1699)
        local_value_1699 = local_value_1650.cat([local_value_1729, local_value_1711], dim=1)
        local_value_1699 = local_value_1336.member_slot_0381(local_value_1699)
        return local_value_1699

class OrientationConditionedFilter(local_value_1094.Module):

    def __init__(local_value_1336, in_dim, local_value_1077, local_value_0490=(8, 8)):
        super().__init__()
        local_value_1336.local_value_1077 = local_value_1077
        local_value_1336.local_value_0490 = local_value_0490
        local_value_1336.member_slot_0314 = local_value_1094.Sequential(local_value_1094.Conv2d(local_value_1077, in_dim, kernel_size=1), local_value_1094.Conv2d(in_dim, in_dim, kernel_size=3, padding=1, groups=in_dim, bias=False), local_value_1094.GroupNorm(in_dim // 8, in_dim), local_value_1094.ReLU(inplace=True), local_value_1094.AdaptiveAvgPool2d((1, 1)))
        local_value_1336.weight = local_value_1094.Sequential(ComponentUnit0115(in_channels=in_dim, local_value_1045=in_dim // 2, out_channels=in_dim), local_value_1094.GroupNorm(in_dim // 8, in_dim))
        local_value_1336.member_slot_0211 = local_value_1094.Sequential(local_value_1094.Conv2d(in_channels=in_dim, out_channels=in_dim, kernel_size=1, stride=1), local_value_1094.GroupNorm(in_dim // 8, in_dim))
        local_value_1336.member_slot_0286 = local_value_1094.Sequential(ComponentUnit0115(in_channels=in_dim, local_value_1045=in_dim // 2, out_channels=in_dim, kernel_size=3), local_value_1094.GroupNorm(in_dim // 8, in_dim))
        local_value_1336.sigmoid = local_value_1094.Sigmoid()

    def forward(local_value_1336, local_value_1699):
        local_value_1268 = local_value_1699
        local_value_1699 = execute_step_0953(local_value_1699)
        local_value_1713 = local_value_1336.execute_step_0886(local_value_1699)
        local_value_1713 = local_value_1336.member_slot_0314(local_value_1713)
        local_value_1701 = local_value_1336.sigmoid(local_value_1336.weight(local_value_1699 + local_value_1713))
        local_value_1702 = local_value_1336.member_slot_0211(local_value_1699)
        local_value_1699 = local_value_1701 * local_value_1702
        local_value_1699 = execute_step_1203(local_value_1699)
        local_value_1699 = local_value_1699 + local_value_1268
        local_value_1699 = local_value_1336.member_slot_0286(local_value_1699)
        return local_value_1699

    def execute_step_0886(local_value_1336, local_value_1699):
        local_value_1716 = local_value_1699.mean(dim=1, keepdim=True)
        B, local_value_0272, H, W = local_value_1716.shape
        device = local_value_1716.device
        local_value_1357 = local_value_1650.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=local_value_1650.float32).view(1, 1, 3, 3).to(device)
        local_value_1358 = local_value_1650.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=local_value_1650.float32).view(1, 1, 3, 3).to(device)
        local_value_0806 = local_value_0117.conv2d(local_value_1716.float(), local_value_1357, padding=1)
        local_value_0813 = local_value_0117.conv2d(local_value_1716.float(), local_value_1358, padding=1)
        local_value_0898 = local_value_1650.atan2(local_value_0813, local_value_0806)
        local_value_0898 = local_value_1650.abs(local_value_0898)
        local_value_0489, local_value_0491 = local_value_1336.local_value_0490
        local_value_0149 = int(H / local_value_0489)
        local_value_0259 = int(W / local_value_0491)
        local_value_0716 = local_value_0898[:, :, :local_value_0149 * local_value_0489, :local_value_0259 * local_value_0491]
        local_value_0715 = local_value_0716.view(B, local_value_0149, local_value_0259, -1)
        local_value_0447 = local_value_1650.pi / local_value_1336.local_value_1077
        local_value_0445 = (local_value_0715 / local_value_0447).floor().long()
        local_value_0445 = local_value_1650.clamp(local_value_0445, 0, local_value_1336.local_value_1077 - 1)
        local_value_0446 = local_value_0445.view(B * local_value_0149 * local_value_0259, local_value_0715.shape[-1])
        weight = []
        for local_value_0939 in range(local_value_0446.shape[0]):
            local_value_0448 = local_value_0446[local_value_0939]
            local_value_0537 = local_value_1650.bincount(local_value_0448, minlength=local_value_1336.local_value_1077)
            weight.append(local_value_0537)
        weight = local_value_1650.stack(weight, dim=0).view(B, local_value_0149, local_value_0259, -1) / 64
        local_value_1386 = local_value_1650.pi / (2 * local_value_1336.local_value_1077)
        local_value_0932 = local_value_1650.linspace(local_value_1386, local_value_1650.pi - local_value_1386, local_value_1336.local_value_1077).to(device).repeat(B, local_value_0149, local_value_0259, 1) * weight
        return local_value_0932.permute(0, 3, 1, 2)

def execute_step_0953(local_value_1699):
    local_value_1699 = local_value_0824.rearrange(local_value_1699, 'b c (hg h) (wg w) -> (hg wg b) c h w', hg=2, wg=2)
    return local_value_1699

def execute_step_1203(local_value_1699):
    local_value_1699 = local_value_0824.rearrange(local_value_1699, '(hg wg b) c h w -> b c (hg h) (wg w)', hg=2, wg=2)
    return local_value_1699
