import torch as runtime_core
from public_entry import OrientedCandidateUnit

chosen_device = 'cuda' if runtime_core.cuda.is_available() else 'cpu'
chosen_unit = OrientedCandidateUnit(channel_width=16).to(chosen_device).eval()
feature_grid = runtime_core.randn(1, 16, 32, 32, device=chosen_device)
with runtime_core.no_grad():
    print(chosen_unit(feature_grid).shape)
