import torch as runtime_core
if __package__:
    from .implementation.components.operators.spectral_candidates import CandidateRelationGate as RelationKernel
    from .implementation.components.operators.orientation_filter import OrientationConditionedFilter as DirectionKernel
else:
    from implementation.components.operators.spectral_candidates import CandidateRelationGate as RelationKernel
    from implementation.components.operators.orientation_filter import OrientationConditionedFilter as DirectionKernel


class OrientedCandidateUnit(runtime_core.nn.Module):
    def __init__(self, channel_width=16, direction_bins=180, selection_fraction=0.125, selection_limit=1024):
        super().__init__()
        self.content_route = runtime_core.nn.Sequential(
            RelationKernel(channel_width, local_value_0475=selection_fraction,
                           local_value_1047=64, local_value_1042=selection_limit, local_value_1041=4),
            DirectionKernel(channel_width, direction_bins),
        )

    def forward(self, feature_grid):
        return self.content_route(feature_grid)
