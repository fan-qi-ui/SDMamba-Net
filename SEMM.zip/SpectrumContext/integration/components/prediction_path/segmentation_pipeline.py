import torch as local_value_1650
from torch import nn as local_value_1094
from components.synthesis_path import ContourFusionDecoder
from components.analysis_path import ComponentUnit0246
import torch.nn.functional as local_value_0117

class ComponentUnit0186(local_value_1094.Module):

    def __init__(local_value_1336, local_value_0429, local_value_0826, local_value_0416=None):
        super().__init__()
        local_value_1336.local_value_0416 = local_value_0416
        local_value_1336.local_value_0429 = local_value_0429
        local_value_1336.member_slot_0237 = ContourFusionDecoder(local_value_0826, local_value_1046=8, size=(local_value_0416.load_width, local_value_0416.load_height))

    def forward(local_value_1336, local_value_1299):
        local_value_1177 = local_value_1336.local_value_0429(local_value_1299)
        out = local_value_1336.member_slot_0237(local_value_1177)
        return out

class ComponentUnit0111(local_value_1094.Module):

    def __init__(local_value_1336, local_value_1356=1.0, dims=(-2, -1)):
        super(ComponentUnit0111, local_value_1336).__init__()
        local_value_1336.local_value_1356 = local_value_1356
        local_value_1336.dims = dims

    def forward(local_value_1336, local_value_1699, y):
        local_value_1651 = (local_value_1699 * y).sum(local_value_1336.dims)
        local_value_0865 = (local_value_1699 * (1 - y)).sum(local_value_1336.dims)
        local_value_0849 = ((1 - local_value_1699) * y).sum(local_value_1336.dims)
        local_value_0647 = (2 * local_value_1651 + local_value_1336.local_value_1356) / (2 * local_value_1651 + local_value_0865 + local_value_0849 + local_value_1336.local_value_1356)
        local_value_0647 = local_value_0647.mean()
        return 1 - local_value_0647

class ComponentUnit0237(local_value_1094.Module):

    def __init__(local_value_1336, local_value_0414=0.75, local_value_0877=2.0, local_value_0823=1.0, local_value_0836=0.5, local_value_0455=0.2, local_value_1356=1.0, eps=1e-07):
        super(ComponentUnit0237, local_value_1336).__init__()
        local_value_1336.local_value_0414 = local_value_0414
        local_value_1336.local_value_0877 = local_value_0877
        local_value_1336.local_value_0823 = local_value_0823
        local_value_1336.local_value_0836 = local_value_0836
        local_value_1336.local_value_0455 = local_value_0455
        local_value_1336.local_value_1356 = local_value_1356
        local_value_1336.eps = eps

    def execute_step_0887(local_value_1336, local_value_1748):
        local_value_0707 = local_value_0117.max_pool2d(local_value_1748, kernel_size=3, stride=1, padding=1)
        local_value_0831 = -local_value_0117.max_pool2d(-local_value_1748, kernel_size=3, stride=1, padding=1)
        local_value_0822 = (local_value_0707 - local_value_0831).clamp(0, 1)
        return local_value_0822

    def execute_step_0890(local_value_1336, local_value_1699):
        b, c, h, local_value_1683 = local_value_1699.shape
        local_value_1003 = local_value_1650.tensor([[[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]], dtype=local_value_1699.dtype, device=local_value_1699.device).unsqueeze(0)
        local_value_1004 = local_value_1650.tensor([[[-1, -2, -1], [0, 0, 0], [1, 2, 1]]], dtype=local_value_1699.dtype, device=local_value_1699.device).unsqueeze(0)
        local_value_1003 = local_value_1003.repeat(c, 1, 1, 1)
        local_value_1004 = local_value_1004.repeat(c, 1, 1, 1)
        local_value_0896 = local_value_0117.conv2d(local_value_1699, local_value_1003, padding=1, groups=c)
        local_value_0897 = local_value_0117.conv2d(local_value_1699, local_value_1004, padding=1, groups=c)
        local_value_0822 = local_value_1650.sqrt(local_value_0896 * local_value_0896 + local_value_0897 * local_value_0897 + local_value_1336.eps)
        local_value_0822 = local_value_0822 / (local_value_0822.amax(dim=(-2, -1), keepdim=True) + local_value_1336.eps)
        return local_value_0822

    def execute_step_0453(local_value_1336, local_value_1221, local_value_1748):
        local_value_1220 = local_value_1336.execute_step_0890(local_value_1221)
        local_value_1657 = local_value_1336.execute_step_0890(local_value_1748)
        dims = (-2, -1)
        local_value_0983 = (local_value_1220 * local_value_1657).sum(dims)
        local_value_1666 = local_value_1220.sum(dims) + local_value_1657.sum(dims)
        local_value_0706 = (2 * local_value_0983 + local_value_1336.local_value_1356) / (local_value_1666 + local_value_1336.local_value_1356 + local_value_1336.eps)
        return 1 - local_value_0706.mean()

    def forward(local_value_1336, local_value_1745, local_value_1748):
        local_value_1748 = local_value_1748.type_as(local_value_1745)
        local_value_0438 = local_value_0117.binary_cross_entropy_with_logits(local_value_1745, local_value_1748, reduction='none')
        local_value_1229 = local_value_1650.sigmoid(local_value_1745)
        local_value_1234 = local_value_1229 * local_value_1748 + (1 - local_value_1229) * (1 - local_value_1748)
        local_value_0415 = local_value_1336.local_value_0414 * local_value_1748 + (1 - local_value_1336.local_value_0414) * (1 - local_value_1748)
        local_value_0852 = local_value_0415 * (1 - local_value_1234).pow(local_value_1336.local_value_0877)
        local_value_0822 = local_value_1336.execute_step_0887(local_value_1748)
        local_value_1613 = 1.0 + local_value_1336.local_value_0823 * local_value_0822 + local_value_1336.local_value_0836 * local_value_1748
        local_value_0851 = local_value_1613 * local_value_0852 * local_value_0438
        local_value_0851 = local_value_0851.mean()
        local_value_0454 = local_value_1336.execute_step_0453(local_value_1229, local_value_1748)
        return local_value_0851 + local_value_1336.local_value_0455 * local_value_0454

class ComponentUnit0439(local_value_1094.Module):

    def __init__(local_value_1336, local_value_0416):
        super(ComponentUnit0439, local_value_1336).__init__()
        local_value_1336.member_slot_0164 = local_value_1094.BCEWithLogitsLoss()
        local_value_1336.member_slot_0243 = ComponentUnit0111()
        local_value_1336.member_slot_0274 = ComponentUnit0237(local_value_0414=getattr(local_value_0416, 'Focal_alpha', 0.75), local_value_0877=getattr(local_value_0416, 'Focal_gamma', 2.0), local_value_0823=getattr(local_value_0416, 'Focal_edge_weight', 1.0), local_value_0836=getattr(local_value_0416, 'Focal_fg_weight', 0.5), local_value_0455=getattr(local_value_0416, 'Focal_boundary_weight', 0.2))
        local_value_1336.local_value_0416 = local_value_0416

    def forward(local_value_1336, local_value_1745, local_value_1748):
        local_value_1748 = local_value_1748.type_as(local_value_1745)
        local_value_0438 = local_value_1336.member_slot_0164(local_value_1745, local_value_1748)
        local_value_0706 = local_value_1336.member_slot_0243(local_value_1745.sigmoid(), local_value_1748)
        local_value_0850 = local_value_1336.member_slot_0274(local_value_1745, local_value_1748)
        return local_value_1336.local_value_0416.member_slot_0003 * local_value_0438 + local_value_1336.local_value_0416.member_slot_0019 * local_value_0706 + local_value_1336.local_value_0416.member_slot_0022 * local_value_0850

def execute_step_0456(local_value_0416):
    device = local_value_1650.device(local_value_0416.device)
    local_value_0416.device = local_value_1650.device(local_value_0416.device)
    local_value_0825 = [16, 32, 64, 128]
    depths = [1, 1, 1, 1]
    local_value_1394 = [8, 8, 16, 16]
    local_value_0429 = ComponentUnit0246(in_dim=3, local_value_0825=local_value_0825, depths=depths, local_value_1054=2.0, local_value_1394=local_value_1394)
    model = ComponentUnit0186(local_value_0429, local_value_0825, local_value_0416).to(device)
    local_value_0538 = ComponentUnit0439(local_value_0416)
    local_value_0538.to(device)
    return (model, local_value_0538)
