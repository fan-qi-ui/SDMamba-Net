import os as local_value_1136
from timm.models.vision_transformer import trunc_normal_ as local_value_1658
import torch.nn as local_value_1094
import torch as local_value_1650
from mmseg.utils import get_root_logger as local_value_0889
from mmcv.runner import _load_checkpoint as local_value_0359
from torch.nn.modules.batchnorm import _BatchNorm as local_value_0276
from components.tensor_primitives import local_value_0168, local_value_0236, local_value_0201
from components.operators import OrientationConditionedFilter, SpectralDetailGate, CandidateRelationGate
from context_engine.components.context_blocks import ContextMixingBlock

def execute_step_0344(local_value_0687=0.125):
    local_value_1674 = float(local_value_1136.environ.get('SDN_CSA_RATIO', str(local_value_0687)))
    if not 0.0 < local_value_1674 <= 1.0:
        raise ValueError(f'SDN_CSA_RATIO must be in (0, 1], got {local_value_1674}')
    return local_value_1674

def execute_step_0343(local_value_0687=1024):
    local_value_1674 = int(local_value_1136.environ.get('SDN_CSA_MAX_TOKENS', str(local_value_0687)))
    if local_value_1674 < 1:
        raise ValueError(f'SDN_CSA_MAX_TOKENS must be >= 1, got {local_value_1674}')
    return local_value_1674

def execute_step_0347():
    local_value_1674 = local_value_1136.environ.get('SDN_VSS_VARIANT', 'fhe_csa').strip().lower()
    local_value_0412 = {'baseline': 'baseline', 'base': 'baseline', 'original': 'baseline', 'fhe': 'fhe', 'fhe_csa': 'fhe_csa', 'fhe+csa': 'fhe_csa', 'full': 'fhe_csa'}
    if local_value_1674 not in local_value_0412:
        raise ValueError(f'Unknown SDN_VSS_VARIANT={local_value_1674!r}. Use baseline / fhe / fhe_csa.')
    return local_value_0412[local_value_1674]

def execute_step_0346(name, local_value_0687, local_value_0412):
    local_value_1674 = local_value_1136.environ.get(name, local_value_0687).strip().lower()
    if local_value_1674 not in local_value_0412:
        local_value_0413 = ' / '.join(sorted(set(local_value_0412.values())))
        raise ValueError(f'Unknown {name}={local_value_1674!r}. Use {local_value_0413}.')
    return local_value_0412[local_value_1674]

def execute_step_0342():
    local_value_0528 = 'SDN_SEMM_VARIANT' in local_value_1136.environ or 'SDN_DASR_VARIANT' in local_value_1136.environ
    if not local_value_0528:
        return (None, None)
    local_value_1337 = execute_step_0346('SDN_SEMM_VARIANT', 'fhe_mamba_gl', {'none': 'none', 'off': 'none', 'fhe': 'fhe', 'fhe_mamba': 'fhe_mamba', 'fhe+mamba': 'fhe_mamba', 'fhe_mamba_gl': 'fhe_mamba_gl', 'fhe+mamba+global_local': 'fhe_mamba_gl', 'full': 'fhe_mamba_gl'})
    local_value_0639 = execute_step_0346('SDN_DASR_VARIANT', 'ccsa_deg', {'none': 'none', 'off': 'none', 'ccsa': 'ccsa', 'ccsa_deg': 'ccsa_deg', 'ccsa+deg': 'ccsa_deg', 'full': 'ccsa_deg'})
    return (local_value_1337, local_value_0639)

class ComponentUnit0245(local_value_1094.Module):

    def __init__(local_value_1336, in_dim, local_value_0697, local_value_1054=4.0, local_value_1394=64, local_value_1077=180, local_value_0475=0.125, local_value_1042=1024):
        super().__init__()
        local_value_1336.local_value_0697 = local_value_0697
        local_value_1336.member_slot_0472 = execute_step_0347()
        local_value_1336.member_slot_0435, local_value_1336.member_slot_0236 = execute_step_0342()
        local_value_1336.member_slot_0228 = execute_step_0344(local_value_0475)
        local_value_1336.member_slot_0227 = execute_step_0343(local_value_1042)
        local_value_1336.blocks = local_value_1094.ModuleList()
        for local_value_0272 in range(local_value_0697):
            if local_value_1336.member_slot_0435 is not None:
                local_value_1059 = []
                if local_value_1336.member_slot_0435 in {'fhe', 'fhe_mamba', 'fhe_mamba_gl'}:
                    local_value_1059.append(SpectralDetailGate(dim=in_dim, local_value_0561=0.18, local_value_1621=18.0))
                if local_value_1336.member_slot_0435 in {'fhe_mamba', 'fhe_mamba_gl'}:
                    local_value_1059.append(ContextMixingBlock(hidden_dim=in_dim, local_value_1380=local_value_1394, local_value_1054=local_value_1054, channel_first=True, use_global_local=local_value_1336.member_slot_0435 == 'fhe_mamba_gl'))
                if local_value_1336.member_slot_0236 in {'ccsa', 'ccsa_deg'}:
                    local_value_1059.append(CandidateRelationGate(dim=in_dim, local_value_0475=local_value_1336.member_slot_0228, local_value_1047=64, local_value_1042=local_value_1336.member_slot_0227, local_value_1041=4))
                if local_value_1336.member_slot_0236 == 'ccsa_deg':
                    local_value_1059.append(OrientationConditionedFilter(in_dim=in_dim, local_value_1077=local_value_1077))
                if not local_value_1059:
                    raise ValueError('The composable ablation must keep at least one SEMM or DASR component.')
            elif local_value_1336.member_slot_0472 == 'baseline':
                local_value_1059 = [ContextMixingBlock(hidden_dim=in_dim, local_value_1380=local_value_1394, local_value_1054=local_value_1054, channel_first=True), OrientationConditionedFilter(in_dim=in_dim, local_value_1077=local_value_1077)]
            elif local_value_1336.member_slot_0472 == 'fhe':
                local_value_1059 = [SpectralDetailGate(dim=in_dim, local_value_0561=0.18, local_value_1621=18.0), ContextMixingBlock(hidden_dim=in_dim, local_value_1380=local_value_1394, local_value_1054=local_value_1054, channel_first=True), OrientationConditionedFilter(in_dim=in_dim, local_value_1077=local_value_1077)]
            elif local_value_1336.member_slot_0472 == 'fhe_csa':
                local_value_1059 = [SpectralDetailGate(dim=in_dim, local_value_0561=0.18, local_value_1621=18.0), ContextMixingBlock(hidden_dim=in_dim, local_value_1380=local_value_1394, local_value_1054=local_value_1054, channel_first=True), CandidateRelationGate(dim=in_dim, local_value_0475=local_value_1336.member_slot_0228, local_value_1047=64, local_value_1042=local_value_1336.member_slot_0227, local_value_1041=4), OrientationConditionedFilter(in_dim=in_dim, local_value_1077=local_value_1077)]
            else:
                raise AssertionError(local_value_1336.member_slot_0472)
            local_value_1336.blocks.append(local_value_1094.Sequential(*local_value_1059))

    def forward(local_value_1336, local_value_1699):
        for local_value_0449 in local_value_1336.blocks:
            local_value_1699 = local_value_0449(local_value_1699)
        return local_value_1699

class ComponentUnit0246(local_value_1094.Module):

    def __init__(local_value_1336, in_dim=3, local_value_0825=[128, 256, 512], depths=[2, 2, 2], local_value_1054=4.0, local_value_1394=[49, 25, 9], local_value_0717=False, local_value_0990=True, local_value_1077=180, local_value_0475=0.125, local_value_1042=1024):
        super().__init__()
        local_value_1336.member_slot_0369 = len(depths)
        local_value_1336.local_value_0717 = local_value_0717
        if local_value_0990:
            local_value_1336.member_slot_0386 = local_value_0236(in_dim=in_dim, dim=local_value_0825[0])
        local_value_1336.local_value_0990 = local_value_0990
        local_value_1336.member_slot_0474 = local_value_1094.ModuleList()
        local_value_1336.member_slot_0250 = local_value_1094.ModuleList()
        for local_value_0946 in range(local_value_1336.member_slot_0369):
            local_value_1682 = ComponentUnit0245(in_dim=int(local_value_0825[local_value_0946]), local_value_0697=depths[local_value_0946], local_value_1054=local_value_1054, local_value_1394=local_value_1394[local_value_0946], local_value_1077=local_value_1077, local_value_0475=local_value_0475, local_value_1042=local_value_1042)
            local_value_1336.member_slot_0474.append(local_value_1682)
            if local_value_0946 < local_value_1336.member_slot_0369 - 1:
                local_value_1336.member_slot_0250.append(local_value_0201(in_dim=int(local_value_0825[local_value_0946]), out_dim=int(local_value_0825[local_value_0946 + 1])))
        local_value_1336.apply(local_value_1336.execute_step_0353)
        local_value_1336 = local_value_1650.nn.SyncBatchNorm.convert_sync_batchnorm(local_value_1336)
        local_value_1336.train()

    def execute_step_0353(local_value_1336, local_value_1028):
        if isinstance(local_value_1028, local_value_1094.Linear):
            local_value_1658(local_value_1028.weight, std=0.02)
            if local_value_1028.bias is not None:
                local_value_1094.init.constant_(local_value_1028.bias, 0)
        elif isinstance(local_value_1028, local_value_0168):
            local_value_1094.init.constant_(local_value_1028.bias, 0)
            local_value_1094.init.constant_(local_value_1028.weight, 1.0)
        elif isinstance(local_value_1028, local_value_1094.BatchNorm2d):
            local_value_1094.init.constant_(local_value_1028.bias, 0)
            local_value_1094.init.constant_(local_value_1028.weight, 1.0)

    def execute_step_0966(local_value_1336, local_value_1224=None):
        logger = local_value_0889()
        if local_value_1336.member_slot_0320 is None and local_value_1224 is None:
            logger.warn(f'No pre-trained weights for {local_value_1336.__class__.__name__}, training start from scratch')
        else:
            assert 'checkpoint' in local_value_1336.member_slot_0320, f'Only support specify `Pretrained` in init_cfg in {local_value_1336.__class__.__name__}'
            if local_value_1336.member_slot_0320 is not None:
                local_value_0521 = local_value_1336.member_slot_0320['checkpoint']
            else:
                local_value_0521 = local_value_1224
            local_value_0520 = local_value_0359(local_value_0521, logger=logger, map_location='cpu')
            if 'state_dict' in local_value_0520:
                state_dict = local_value_0520['state_dict']
            elif 'model' in local_value_0520:
                state_dict = local_value_0520['model']
            else:
                state_dict = local_value_0520
            local_value_1049, local_value_1663 = local_value_1336.load_state_dict(state_dict, False)
            logger.info(f'Miss {local_value_1049}')
            logger.info(f'Unexpected {local_value_1663}')

    def train(local_value_1336, mode=True):
        super(ComponentUnit0246, local_value_1336).train(mode)
        if mode:
            for local_value_1028 in local_value_1336.local_value_1059():
                if isinstance(local_value_1028, local_value_0276):
                    local_value_1028.eval()

    def forward(local_value_1336, local_value_1699):
        if local_value_1336.local_value_0990:
            local_value_1699 = local_value_1336.member_slot_0386(local_value_1699)
        local_value_1177 = []
        for local_value_0939 in range(local_value_1336.member_slot_0369):
            local_value_1699 = local_value_1336.member_slot_0474[local_value_0939](local_value_1699)
            local_value_1177.append(local_value_1699)
            if local_value_0939 < local_value_1336.member_slot_0369 - 1:
                local_value_1699 = local_value_1336.member_slot_0250[local_value_0939](local_value_1699)
        return local_value_1177
