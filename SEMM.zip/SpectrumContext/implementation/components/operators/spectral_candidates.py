import math as local_value_1039
import torch as local_value_1650
import torch.nn as local_value_1094

def execute_step_0363(num_channels: int, local_value_1040: int=8) -> local_value_1094.GroupNorm:
    groups = local_value_1039.gcd(num_channels, local_value_1040)
    groups = max(1, groups)
    return local_value_1094.GroupNorm(groups, num_channels)

class SpectralDetailGate(local_value_1094.Module):

    def __init__(local_value_1336, dim: int, local_value_0561: float=0.18, local_value_1621: float=18.0):
        super().__init__()
        local_value_1336.local_value_1621 = local_value_1621
        local_value_1336.member_slot_0232 = 0.05
        local_value_1336.member_slot_0231 = 0.45
        local_value_0963 = (local_value_0561 - local_value_1336.member_slot_0232) / (local_value_1336.member_slot_0231 - local_value_1336.member_slot_0232)
        local_value_0963 = max(0.0001, min(1 - 0.0001, local_value_0963))
        local_value_1336.member_slot_0230 = local_value_1094.Parameter(local_value_1650.logit(local_value_1650.tensor(local_value_0963, dtype=local_value_1650.float32)))
        local_value_1336.norm = execute_step_0363(dim)
        local_value_1336.member_slot_0313 = local_value_1094.Sequential(local_value_1094.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim, bias=False), execute_step_0363(dim), local_value_1094.GELU(), local_value_1094.Conv2d(dim, dim, kernel_size=1, bias=False))
        local_value_1336.local_value_0878 = local_value_1094.Sequential(local_value_1094.Conv2d(dim, dim, kernel_size=1, bias=True), local_value_1094.Sigmoid())
        local_value_1336.local_value_0877 = local_value_1094.Parameter(local_value_1650.tensor(0.1, dtype=local_value_1650.float32))

    def execute_step_0882(local_value_1336):
        return local_value_1336.member_slot_0232 + (local_value_1336.member_slot_0231 - local_value_1336.member_slot_0232) * local_value_1650.sigmoid(local_value_1336.member_slot_0230)

    def execute_step_0348(local_value_1336, h: int, local_value_1683: int, device: local_value_1650.device) -> local_value_1650.Tensor:
        local_value_0869 = local_value_1650.fft.fftfreq(h, d=1.0, device=device).view(1, 1, h, 1)
        local_value_0868 = local_value_1650.fft.rfftfreq(local_value_1683, d=1.0, device=device).view(1, 1, 1, local_value_1683 // 2 + 1)
        local_value_1245 = local_value_1650.sqrt(local_value_0868 * local_value_0868 + local_value_0869 * local_value_0869) / local_value_1039.sqrt(0.5)
        local_value_0561 = local_value_1336.execute_step_0882().to(device=device)
        return local_value_1650.sigmoid((local_value_1245 - local_value_0561) * local_value_1336.local_value_1621)

    def forward(local_value_1336, local_value_1699: local_value_1650.Tensor) -> local_value_1650.Tensor:
        dtype = local_value_1699.dtype
        b, c, h, local_value_1683 = local_value_1699.shape
        local_value_1731 = local_value_1699.float()
        local_value_1717 = local_value_1336.norm(local_value_1731)
        local_value_0866 = local_value_1650.fft.rfft2(local_value_1717, norm='ortho')
        mask = local_value_1336.execute_step_0348(h, local_value_1683, local_value_1699.device)
        local_value_0931 = local_value_1650.fft.irfft2(local_value_0866 * mask, s=(h, local_value_1683), norm='ortho')
        local_value_0931 = local_value_1336.member_slot_0313(local_value_0931).to(dtype=dtype)
        local_value_0878 = local_value_1336.local_value_0878(local_value_1731).to(dtype=dtype)
        local_value_0877 = local_value_1336.local_value_0877.to(dtype=dtype)
        return local_value_1699 + local_value_0877 * local_value_0878 * local_value_0931

class CandidateRelationGate(local_value_1094.Module):

    def __init__(local_value_1336, dim: int, local_value_0475: float=0.125, local_value_1047: int=64, local_value_1042: int=1024, local_value_1041: int=4, local_value_0422: float=0.0, local_value_1232: float=0.0):
        super().__init__()
        local_value_1336.local_value_0475 = local_value_0475
        local_value_1336.local_value_1047 = local_value_1047
        local_value_1336.local_value_1042 = local_value_1042
        local_value_0927 = max(dim // 4, 4)
        local_value_1336.member_slot_0415 = local_value_1094.Sequential(execute_step_0363(dim), local_value_1094.Conv2d(dim, local_value_0927, kernel_size=3, padding=1, bias=False), local_value_1094.GELU(), local_value_1094.Conv2d(local_value_0927, 1, kernel_size=1, bias=True))
        num_heads = min(local_value_1041, dim)
        while dim % num_heads != 0 and num_heads > 1:
            num_heads -= 1
        local_value_1336.norm = local_value_1094.LayerNorm(dim)
        local_value_1336.local_value_0421 = local_value_1094.MultiheadAttention(dim, num_heads=num_heads, dropout=local_value_0422, batch_first=True)
        local_value_1336.member_slot_0394 = local_value_1094.Sequential(local_value_1094.Linear(dim, dim), local_value_1094.Dropout(local_value_1232))
        local_value_1336.member_slot_0379 = local_value_1094.Sequential(local_value_1094.Conv2d(dim, dim, kernel_size=1, bias=True), local_value_1094.Sigmoid())
        local_value_1336.local_value_0877 = local_value_1094.Parameter(local_value_1650.tensor(0.1, dtype=local_value_1650.float32))

    def execute_step_0374(local_value_1336, local_value_1072: int) -> int:
        k = int(local_value_1072 * local_value_1336.local_value_0475)
        k = max(local_value_1336.local_value_1047, k)
        k = min(local_value_1336.local_value_1042, k, local_value_1072)
        return k

    def forward(local_value_1336, local_value_1699: local_value_1650.Tensor) -> local_value_1650.Tensor:
        b, c, h, local_value_1683 = local_value_1699.shape
        n = h * local_value_1683
        k = local_value_1336.execute_step_0374(n)
        local_value_1649 = local_value_1699.flatten(2).transpose(1, 2)
        local_value_1309 = local_value_1336.member_slot_0415(local_value_1699.float()).flatten(2).squeeze(1)
        local_value_0950 = local_value_1650.topk(local_value_1309, k=k, dim=1, largest=True, sorted=False).indices
        local_value_0951 = local_value_0950.unsqueeze(-1).expand(-1, -1, c)
        local_value_0473 = local_value_1650.gather(local_value_1649, dim=1, index=local_value_0951)
        local_value_0474 = local_value_1336.norm(local_value_0473.float()).to(dtype=local_value_0473.dtype)
        local_value_0424, local_value_0272 = local_value_1336.local_value_0421(local_value_0474, local_value_0474, local_value_0474, need_weights=False)
        local_value_0424 = local_value_1336.member_slot_0394(local_value_0424).to(dtype=local_value_1649.dtype)
        local_value_1362 = local_value_1650.zeros_like(local_value_1649)
        local_value_1362.scatter_(dim=1, index=local_value_0951, src=local_value_0424)
        local_value_1361 = local_value_1362.transpose(1, 2).reshape(b, c, h, local_value_1683)
        local_value_0878 = local_value_1336.member_slot_0379(local_value_1699.float()).to(dtype=local_value_1699.dtype)
        local_value_0877 = local_value_1336.local_value_0877.to(dtype=local_value_1699.dtype)
        return local_value_1699 + local_value_0877 * local_value_0878 * local_value_1361
