import torch as local_value_1650
import torch.nn.functional as local_value_0117
from einops import rearrange as local_value_1249, repeat

def execute_step_1313(local_value_1699):
    local_value_0238 = local_value_1699.size(-1)
    local_value_1707 = local_value_1650.cumsum(local_value_1699, dim=-1)
    local_value_1725 = local_value_1707[..., :, None] - local_value_1707[..., None, :]
    mask = local_value_1650.tril(local_value_1650.ones(local_value_0238, local_value_0238, device=local_value_1699.device, dtype=bool), diagonal=0)
    local_value_1725 = local_value_1725.masked_fill(~mask, -local_value_1650.inf)
    return local_value_1725

def execute_step_1312(local_value_1699):
    local_value_0238 = local_value_1699.size(-1)
    local_value_1699 = repeat(local_value_1699, '... d -> ... d e', e=local_value_0238)
    mask = local_value_1650.tril(local_value_1650.ones(local_value_0238, local_value_0238, device=local_value_1699.device, dtype=bool), diagonal=-1)
    local_value_1699 = local_value_1699.masked_fill(~mask, 0)
    local_value_1725 = local_value_1650.cumsum(local_value_1699, dim=-2)
    mask = local_value_1650.tril(local_value_1650.ones(local_value_0238, local_value_0238, device=local_value_1699.device, dtype=bool), diagonal=0)
    local_value_1725 = local_value_1725.masked_fill(~mask, -local_value_1650.inf)
    return local_value_1725

def execute_step_1375(local_value_0261, local_value_0000, B, local_value_0044, local_value_0451, local_value_0970=None):
    assert local_value_0261.dtype == local_value_0000.dtype == B.dtype == local_value_0044.dtype
    assert local_value_0261.shape[1] % local_value_0451 == 0
    local_value_0261, local_value_0000, B, local_value_0044 = [local_value_1249(local_value_1699, 'b (c l) ... -> b c l ...', l=local_value_0451) for local_value_1699 in (local_value_0261, local_value_0000, B, local_value_0044)]
    local_value_0000 = local_value_1249(local_value_0000, 'b c l h -> b h c l')
    local_value_0001 = local_value_1650.cumsum(local_value_0000, dim=-1)
    L = local_value_1650.exp(execute_step_1312(local_value_0000))
    local_value_0269 = local_value_1650.einsum('bclhn,bcshn,bhcls,bcshp->bclhp', local_value_0044, B, L, local_value_0261)
    local_value_0686 = local_value_1650.exp(local_value_0001[:, :, :, -1:] - local_value_0001)
    local_value_1400 = local_value_1650.einsum('bclhn,bhcl,bclhp->bchpn', B, local_value_0686, local_value_0261)
    if local_value_0970 is None:
        local_value_0970 = local_value_1650.zeros_like(local_value_1400[:, :1])
    local_value_1400 = local_value_1650.cat([local_value_0970, local_value_1400], dim=1)
    local_value_0685 = local_value_1650.exp(execute_step_1312(local_value_0117.pad(local_value_0001[:, :, :, -1], (1, 0))))
    local_value_1083 = local_value_1650.einsum('bhzc,bchpn->bzhpn', local_value_0685, local_value_1400)
    local_value_1400, local_value_0837 = (local_value_1083[:, :-1], local_value_1083[:, -1])
    local_value_1392 = local_value_1650.exp(local_value_0001)
    local_value_0270 = local_value_1650.einsum('bclhn,bchpn,bhcl->bclhp', local_value_0044, local_value_1400, local_value_1392)
    local_value_0267 = local_value_1249(local_value_0269 + local_value_0270, 'b c l h p -> b (c l) h p')
    return (local_value_0267, local_value_0837)

def execute_step_1031(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513, D=None, local_value_1753=None, local_value_0767=None, local_value_0970=None, local_value_1339=None, local_value_0794=False, local_value_0776=(0.0, float('inf')), local_value_1276=False):
    local_value_0434, local_value_1348, local_value_1089, local_value_0759 = B.shape
    local_value_1090, local_value_0925 = local_value_1699.shape[2:]
    while local_value_1348 % local_value_0513 != 0:
        local_value_0513 = local_value_0513 >> 1
    if local_value_1090 != local_value_1089:
        assert local_value_1090 % local_value_1089 == 0
        B = B.view(local_value_0434, local_value_1348, local_value_1089, 1, local_value_0759).repeat(1, 1, 1, local_value_1090 // local_value_1089, 1).view(local_value_0434, local_value_1348, local_value_1090, local_value_0759)
        local_value_0044 = local_value_0044.view(local_value_0434, local_value_1348, local_value_1089, 1, local_value_0759).repeat(1, 1, 1, local_value_1090 // local_value_1089, 1).view(local_value_0434, local_value_1348, local_value_1090, local_value_0759)
    if local_value_0767 is not None:
        local_value_0764 = local_value_0764 + local_value_0767
    if local_value_0794:
        local_value_0764 = local_value_0117.softplus(local_value_0764)
    local_value_1660 = local_value_1699 * local_value_0764.unsqueeze(-1)
    local_value_1683 = local_value_0000 * local_value_0764
    y, local_value_1391 = execute_step_1375(local_value_1660, local_value_1683, B, local_value_0044, local_value_0451=local_value_0513, local_value_0970=local_value_0970)
    if D is not None:
        y = y + D.view(y.shape[-2], -1) * local_value_1699
    if local_value_1753 is not None:
        y = y * (local_value_1753 * local_value_1650.sigmoid(local_value_1753))
    return (y, local_value_1391) if local_value_1276 else y
local_value_0258 = True
try:
    import triton as local_value_1655
except ImportError:
    local_value_0258 = False
if local_value_0258:
    try:
        from .engine_unit_025 import execute_step_1030
    except ImportError:
        from engine_unit_025 import execute_step_1030

def execute_step_1318(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513, D=None, local_value_1753=None, local_value_0767=None, local_value_0970=None, local_value_1339=None, local_value_0794=False, local_value_0776=(0.0, float('inf')), local_value_1276=False, local_value_0430=None):
    local_value_0849 = execute_step_1031 if local_value_0430 == 'torch' or not local_value_0258 else execute_step_1030
    return local_value_0849(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513, D, local_value_1753, local_value_0767, local_value_0970, local_value_1339, local_value_0794, local_value_0776, local_value_1276)

def execute_step_1623():
    local_value_1650.manual_seed(42)
    local_value_0434, local_value_1348, local_value_0513, dim, local_value_0925 = (1, 2048, 64, 2048, 64)
    local_value_1090 = dim // local_value_0925
    local_value_1089 = 1
    local_value_1089 = local_value_1090
    local_value_0759 = 64
    dtype = local_value_1650.float32
    device = 'cuda'
    local_value_1699 = local_value_1650.randn(local_value_0434, local_value_1348, local_value_1090, local_value_0925, dtype=dtype, device=device)
    local_value_0764 = local_value_0117.softplus(local_value_1650.randn(local_value_0434, local_value_1348, local_value_1090, dtype=local_value_1650.float32, device=device) - 4).requires_grad_()
    local_value_0000 = (-local_value_1650.exp(local_value_1650.rand(local_value_1090, dtype=local_value_1650.float32, device=device))).requires_grad_()
    B = local_value_1650.randn(local_value_0434, local_value_1348, local_value_1089, local_value_0759, dtype=dtype, device=device)
    local_value_0044 = local_value_1650.randn(local_value_0434, local_value_1348, local_value_1089, local_value_0759, dtype=dtype, device=device)
    D = local_value_1650.randn(local_value_1090, dtype=dtype, device=device)
    local_value_1751 = execute_step_1318(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513=64, D=D, local_value_0430='torch')
    local_value_1752 = execute_step_1318(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513=64, D=D, local_value_0430='triton')
    print((local_value_1751 - local_value_1752).abs().max())
    breakpoint()
    ...
if __name__ == '__main__':
    execute_step_1623()
    breakpoint()
