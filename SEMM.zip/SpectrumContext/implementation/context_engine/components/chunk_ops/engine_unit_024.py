import math as local_value_1039
import torch as local_value_1650
import torch.nn.functional as local_value_0117
import triton as local_value_1655
import triton.language as local_value_1631
from einops import rearrange as local_value_1249, repeat

def execute_step_0965(local_value_1075):
    return lambda local_value_1076: [local_value_1076[name].zero_() for name in local_value_1075 if local_value_1076[name] is not None]

@local_value_1655.autotune(configs=[local_value_1655.Config({'local_value_0024': 1}), local_value_1655.Config({'local_value_0024': 2}), local_value_1655.Config({'local_value_0024': 4}), local_value_1655.Config({'local_value_0024': 8}), local_value_1655.Config({'local_value_0024': 16}), local_value_1655.Config({'local_value_0024': 32}), local_value_1655.Config({'local_value_0024': 64})], key=['local_value_0513', 'local_value_1090'])
@local_value_1655.jit
def execute_step_0298(local_value_0789, local_value_0005, local_value_0768, local_value_0782, local_value_0574, local_value_0434, local_value_1348, local_value_1090, local_value_0513, dt_min, dt_max, local_value_1530, local_value_1541, local_value_1536, local_value_1412, local_value_1532, local_value_1537, local_value_1538, local_value_1540, local_value_1539, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_0097: local_value_1631.constexpr, HAS_DT_BIAS: local_value_1631.constexpr, local_value_0024: local_value_1631.constexpr, BLOCK_SIZE_CHUNK: local_value_1631.constexpr):
    local_value_1204 = local_value_1631.program_id(axis=0)
    local_value_1206 = local_value_1631.program_id(axis=1)
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_0513 * local_value_1541
    local_value_0782 += local_value_1204 * local_value_1537 + local_value_1206 * local_value_1538
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445
    local_value_1120 = local_value_1209 * local_value_0024 + local_value_1631.arange(0, local_value_0024)
    local_value_1117 = local_value_1631.arange(0, BLOCK_SIZE_CHUNK)
    local_value_0790 = local_value_0789 + (local_value_1120[:, None] * local_value_1536 + local_value_1117[None, :] * local_value_1541)
    local_value_0006 = local_value_0005 + local_value_1120 * local_value_1412
    local_value_0783 = local_value_0782 + (local_value_1120[:, None] * local_value_1540 + local_value_1117[None, :] * local_value_1539)
    local_value_0572 = local_value_0574 + (local_value_1120[:, None] * local_value_1447 + local_value_1117[None, :] * local_value_1446)
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0764 = local_value_1631.load(local_value_0790, mask=(local_value_1120[:, None] < local_value_1090) & (local_value_1117[None, :] < local_value_0514), other=0.0).to(local_value_1631.float32)
    if HAS_DT_BIAS:
        local_value_0767 = local_value_1631.load(local_value_0768 + local_value_1120 * local_value_1532, mask=local_value_1120 < local_value_1090, other=0.0).to(local_value_1631.float32)
        local_value_0764 += local_value_0767[:, None]
    if local_value_0097:
        local_value_0764 = local_value_1631.where(local_value_0764 <= 20.0, local_value_1631.math.log1p(local_value_1631.exp(local_value_0764)), local_value_0764)
    local_value_0764 = local_value_1631.minimum(local_value_1631.maximum(local_value_0764, dt_min), dt_max)
    local_value_0764 = local_value_1631.where((local_value_1120[:, None] < local_value_1090) & (local_value_1117[None, :] < local_value_0514), local_value_0764, 0.0)
    local_value_1631.store(local_value_0783, local_value_0764, mask=(local_value_1120[:, None] < local_value_1090) & (local_value_1117[None, :] < local_value_0513))
    local_value_0000 = local_value_1631.load(local_value_0006, mask=local_value_1120 < local_value_1090, other=0.0).to(local_value_1631.float32)
    local_value_0564 = local_value_0764 * local_value_0000[:, None]
    local_value_0566 = local_value_1631.cumsum(local_value_0564, axis=1)
    local_value_1631.store(local_value_0572, local_value_0566, mask=(local_value_1120[:, None] < local_value_1090) & (local_value_1117[None, :] < local_value_0513))

@local_value_1655.autotune(configs=[local_value_1655.Config({'local_value_0024': 1}, pre_hook=execute_step_0965(['local_value_0576', 'local_value_0675'])), local_value_1655.Config({'local_value_0024': 2}, pre_hook=execute_step_0965(['local_value_0576', 'local_value_0675'])), local_value_1655.Config({'local_value_0024': 4}, pre_hook=execute_step_0965(['local_value_0576', 'local_value_0675'])), local_value_1655.Config({'local_value_0024': 8}, pre_hook=execute_step_0965(['local_value_0576', 'local_value_0675'])), local_value_1655.Config({'local_value_0024': 16}, pre_hook=execute_step_0965(['local_value_0576', 'local_value_0675'])), local_value_1655.Config({'local_value_0024': 32}, pre_hook=execute_step_0965(['local_value_0576', 'local_value_0675'])), local_value_1655.Config({'local_value_0024': 64}, pre_hook=execute_step_0965(['local_value_0576', 'local_value_0675']))], key=['local_value_0513', 'local_value_1090'])
@local_value_1655.jit
def execute_step_0296(local_value_0666, local_value_0678, local_value_0789, local_value_0005, local_value_0768, local_value_0680, local_value_0576, local_value_0675, local_value_0434, local_value_1348, local_value_1090, local_value_0513, dt_min, dt_max, local_value_1473, local_value_1474, local_value_1482, local_value_1481, local_value_1493, local_value_1494, local_value_1496, local_value_1495, local_value_1530, local_value_1541, local_value_1536, local_value_1412, local_value_1532, local_value_1488, local_value_1497, local_value_1492, local_value_1448, local_value_1489, local_value_0097: local_value_1631.constexpr, HAS_DT_BIAS: local_value_1631.constexpr, local_value_0024: local_value_1631.constexpr, BLOCK_SIZE_CHUNK: local_value_1631.constexpr):
    local_value_1204 = local_value_1631.program_id(axis=0)
    local_value_1206 = local_value_1631.program_id(axis=1)
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_0678 += local_value_1204 * local_value_1493 + local_value_1206 * local_value_1494
    local_value_0666 += local_value_1204 * local_value_1473 + local_value_1206 * local_value_1474
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_0513 * local_value_1541
    local_value_0680 += local_value_1204 * local_value_1488 + local_value_1206 * local_value_0513 * local_value_1497
    local_value_1120 = local_value_1209 * local_value_0024 + local_value_1631.arange(0, local_value_0024)
    local_value_1117 = local_value_1631.arange(0, BLOCK_SIZE_CHUNK)
    local_value_0679 = local_value_0678 + (local_value_1120[:, None] * local_value_1496 + local_value_1117[None, :] * local_value_1495)
    local_value_0667 = local_value_0666 + (local_value_1120[:, None] * local_value_1482 + local_value_1117[None, :] * local_value_1481)
    local_value_0790 = local_value_0789 + (local_value_1120[:, None] * local_value_1536 + local_value_1117[None, :] * local_value_1541)
    local_value_0681 = local_value_0680 + (local_value_1120[:, None] * local_value_1492 + local_value_1117[None, :] * local_value_1497)
    local_value_0006 = local_value_0005 + local_value_1120 * local_value_1412
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0653 = local_value_1631.load(local_value_0667, mask=(local_value_1120[:, None] < local_value_1090) & (local_value_1117[None, :] < local_value_0514), other=0.0).to(local_value_1631.float32)
    local_value_0677 = local_value_1631.load(local_value_0679, mask=(local_value_1120[:, None] < local_value_1090) & (local_value_1117[None, :] < local_value_0514), other=0.0).to(local_value_1631.float32)
    local_value_0000 = local_value_1631.load(local_value_0006, mask=local_value_1120 < local_value_1090, other=0.0).to(local_value_1631.float32)
    local_value_0672 = local_value_0653 * local_value_0000[:, None] + local_value_0677
    local_value_0764 = local_value_1631.load(local_value_0790, mask=(local_value_1120[:, None] < local_value_1090) & (local_value_1117[None, :] < local_value_0514), other=0.0).to(local_value_1631.float32)
    if HAS_DT_BIAS:
        local_value_0767 = local_value_1631.load(local_value_0768 + local_value_1120 * local_value_1532, mask=local_value_1120 < local_value_1090, other=0.0).to(local_value_1631.float32)
        local_value_0764 += local_value_0767[:, None]
    if local_value_0097:
        local_value_0784 = local_value_0764
        local_value_0764 = local_value_1631.where(local_value_0764 <= 20.0, local_value_1631.math.log1p(local_value_1631.exp(local_value_0764)), local_value_0672)
    local_value_0522 = (local_value_0764 < dt_min) | (local_value_0764 > dt_max)
    local_value_0764 = local_value_1631.minimum(local_value_1631.maximum(local_value_0764, dt_min), dt_max)
    local_value_0764 = local_value_1631.where((local_value_1120[:, None] < local_value_1090) & (local_value_1117[None, :] < local_value_0514), local_value_0764, 0.0)
    local_value_0672 = local_value_1631.where((local_value_1120[:, None] < local_value_1090) & (local_value_1117[None, :] < local_value_0514), local_value_0672, 0.0)
    local_value_0672 = local_value_1631.where(local_value_0522, 0.0, local_value_0672)
    if local_value_0097:
        local_value_0672 = local_value_1631.where(local_value_0784 <= 20.0, local_value_0672 * local_value_1631.sigmoid(local_value_0784), local_value_0672)
    local_value_1631.store(local_value_0681, local_value_0672, mask=(local_value_1120[:, None] < local_value_1090) & (local_value_1117[None, :] < local_value_0514))
    local_value_0564 = local_value_1631.sum(local_value_0653 * local_value_0764, axis=1)
    local_value_1631.atomic_add(local_value_0576 + local_value_1120 * local_value_1448, local_value_0564, mask=local_value_1120 < local_value_1090)
    if HAS_DT_BIAS:
        local_value_0674 = local_value_1631.sum(local_value_0672, axis=1)
        local_value_1631.atomic_add(local_value_0675 + local_value_1120 * local_value_1489, local_value_0674, mask=local_value_1120 < local_value_1090)

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 64}, num_stages=3, num_warps=8), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=2), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=2), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=2)], key=['local_value_0923', 'local_value_0759', 'local_value_0513'])
@local_value_1655.jit
def execute_step_0330(local_value_1720, local_value_0427, local_value_1406, local_value_0789, local_value_0574, local_value_1346, local_value_0923, local_value_0759, local_value_0513, local_value_0434, local_value_1348, local_value_1092, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1429, local_value_1432, local_value_1431, local_value_1430, local_value_1592, local_value_1593, local_value_1597, local_value_1596, local_value_1595, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1586, local_value_1587, HAS_SEQ_IDX: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1111 = local_value_1631.cdiv(local_value_0759, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_0427 += local_value_1204 * local_value_1429 + local_value_1206 * local_value_0513 * local_value_1432 + local_value_1209 // local_value_1092 * local_value_1431
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + local_value_1209 * local_value_1602
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + local_value_1209 * local_value_1536
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + local_value_1209 * local_value_1447
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586 + local_value_1206 * local_value_0513 * local_value_1587
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_1722 = local_value_1720 + (local_value_1123[:, None] * local_value_1601 + local_value_1121[None, :] * local_value_1604)
    local_value_0428 = local_value_0427 + (local_value_1124[None, :] * local_value_1430 + local_value_1121[:, None] * local_value_1432)
    local_value_0790 = local_value_0789 + local_value_1121 * local_value_1534
    local_value_0568 = local_value_1631.load(local_value_0574 + (local_value_0513 - 1) * local_value_1446).to(local_value_1631.float32)
    local_value_0575 = local_value_0574 + local_value_1121 * local_value_1446
    if HAS_SEQ_IDX:
        local_value_1347 = local_value_1346 + local_value_1121 * local_value_1587
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    if HAS_SEQ_IDX:
        local_value_1341 = local_value_1631.load(local_value_1346 + (local_value_0514 - 1) * local_value_1587)
    local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
    for k in range(0, local_value_0514, BLOCK_SIZE_K):
        local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1123[:, None] < local_value_0923) & (local_value_1121[None, :] < local_value_0514 - k), other=0.0)
        b = local_value_1631.load(local_value_0428, mask=(local_value_1121[:, None] < local_value_0514 - k) & (local_value_1124[None, :] < local_value_0759), other=0.0).to(local_value_1631.float32)
        local_value_0567 = local_value_1631.load(local_value_0575, mask=local_value_1121 < local_value_0514 - k, other=0.0).to(local_value_1631.float32)
        if HAS_SEQ_IDX:
            local_value_1340 = local_value_1631.load(local_value_1347, mask=local_value_1121 < local_value_0514 - k, other=-1)
        local_value_0775 = local_value_1631.load(local_value_0790, mask=local_value_1121 < local_value_0514 - k, other=0.0).to(local_value_1631.float32)
        if not HAS_SEQ_IDX:
            local_value_1302 = local_value_1631.exp(local_value_0568 - local_value_0567) * local_value_0775
        else:
            local_value_1302 = local_value_1631.where(local_value_1340 == local_value_1341, local_value_1631.exp(local_value_0568 - local_value_0567) * local_value_0775, 0.0)
        b *= local_value_1302[:, None]
        b = b.to(local_value_1720.dtype.element_ty)
        local_value_0409 += local_value_1631.dot(local_value_1699, b)
        local_value_1722 += BLOCK_SIZE_K * local_value_1604
        local_value_0428 += BLOCK_SIZE_K * local_value_1432
        local_value_0790 += BLOCK_SIZE_K * local_value_1534
        local_value_0575 += BLOCK_SIZE_K * local_value_1446
        if HAS_SEQ_IDX:
            local_value_1347 += BLOCK_SIZE_K * local_value_1587
    local_value_1400 = local_value_0409.to(local_value_1406.dtype.element_ty)
    local_value_1406 += local_value_1204 * local_value_1592 + local_value_1206 * local_value_1593 + local_value_1209 * local_value_1597
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1407 = local_value_1406 + (local_value_1123[:, None] * local_value_1596 + local_value_1124[None, :] * local_value_1595)
    local_value_0467 = (local_value_1123[:, None] < local_value_0923) & (local_value_1124[None, :] < local_value_0759)
    local_value_1631.store(local_value_1407, local_value_1400, mask=local_value_0467)

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 64}, num_stages=3, num_warps=8, pre_hook=execute_step_0965(['local_value_0680', 'local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680', 'local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680', 'local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680', 'local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680', 'local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680', 'local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=4, pre_hook=execute_step_0965(['local_value_0680', 'local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=4, pre_hook=execute_step_0965(['local_value_0680', 'local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680', 'local_value_0661']))], key=['local_value_0513', 'local_value_0923', 'local_value_0759'])
@local_value_1655.jit
def execute_step_0328(local_value_1720, local_value_0427, local_value_0762, local_value_0789, local_value_0574, local_value_0810, local_value_0680, local_value_0661, local_value_0513, local_value_0923, local_value_0759, local_value_0434, local_value_1348, local_value_1092, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1429, local_value_1432, local_value_1431, local_value_1430, local_value_1524, local_value_1525, local_value_1597, local_value_1596, local_value_1595, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1544, local_value_1548, local_value_1546, local_value_1545, local_value_1488, local_value_1490, local_value_1492, local_value_1491, local_value_1475, local_value_1476, local_value_1480, local_value_1477, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr, BLOCK_SIZE_DSTATE: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1111 = local_value_1631.cdiv(local_value_0923, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + local_value_1209 * local_value_1602
    local_value_0427 += local_value_1204 * local_value_1429 + local_value_1206 * local_value_0513 * local_value_1432 + local_value_1209 // local_value_1092 * local_value_1431
    local_value_0762 += local_value_1204 * local_value_1524 + local_value_1206 * local_value_1525 + local_value_1209 * local_value_1597
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + local_value_1209 * local_value_1536
    local_value_0680 += local_value_1204 * local_value_1488 + local_value_1206 * local_value_1490 + local_value_1209 * local_value_1492
    local_value_0661 += local_value_1204 * local_value_1475 + local_value_1206 * local_value_1476 + local_value_1209 * local_value_1480
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + local_value_1209 * local_value_1447
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_DSTATE if BLOCK_SIZE_DSTATE <= 128 else BLOCK_SIZE_K)
    local_value_0428 = local_value_0427 + (local_value_1123[:, None] * local_value_1432 + local_value_1121[None, :] * local_value_1430)
    local_value_0763 = local_value_0762 + (local_value_1124[None, :] * local_value_1596 + local_value_1121[:, None] * local_value_1595)
    if BLOCK_SIZE_DSTATE <= 128:
        b = local_value_1631.load(local_value_0428, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1121[None, :] < local_value_0759), other=0.0)
        local_value_0760 = local_value_1631.load(local_value_0763, mask=(local_value_1121[:, None] < local_value_0759) & (local_value_1124[None, :] < local_value_0923), other=0.0)
        local_value_0760 = local_value_0760.to(local_value_0427.dtype.element_ty)
        local_value_0409 = local_value_1631.dot(b, local_value_0760)
    else:
        local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
        for k in range(0, local_value_0759, BLOCK_SIZE_K):
            b = local_value_1631.load(local_value_0428, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1121[None, :] < local_value_0759 - k), other=0.0)
            local_value_0760 = local_value_1631.load(local_value_0763, mask=(local_value_1121[:, None] < local_value_0759 - k) & (local_value_1124[None, :] < local_value_0923), other=0.0)
            local_value_0760 = local_value_0760.to(local_value_0427.dtype.element_ty)
            local_value_0409 += local_value_1631.dot(b, local_value_0760)
            local_value_0428 += BLOCK_SIZE_K * local_value_1430
            local_value_0763 += BLOCK_SIZE_K * local_value_1595
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0568 = local_value_1631.load(local_value_0574 + (local_value_0513 - 1) * local_value_1446).to(local_value_1631.float32)
    local_value_0790 = local_value_0789 + local_value_1123 * local_value_1534
    local_value_0575 = local_value_0574 + local_value_1123 * local_value_1446
    local_value_0569 = local_value_1631.load(local_value_0575, mask=local_value_1123 < local_value_0513, other=0.0).to(local_value_1631.float32)
    local_value_0777 = local_value_1631.load(local_value_0790, mask=local_value_1123 < local_value_0513, other=0.0).to(local_value_1631.float32)
    local_value_0409 *= local_value_1631.exp(local_value_0568 - local_value_0569)[:, None]
    local_value_1722 = local_value_1720 + (local_value_1123[:, None] * local_value_1604 + local_value_1124[None, :] * local_value_1601)
    local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
    local_value_0672 = local_value_1631.sum(local_value_0409 * local_value_1699, axis=1)
    local_value_0681 = local_value_0680 + local_value_1123 * local_value_1491
    local_value_1631.atomic_add(local_value_0681, local_value_0672, mask=local_value_1123 < local_value_0513)
    local_value_0655 = -(local_value_0672 * local_value_0777)
    local_value_0656 = -local_value_1631.sum(local_value_0655)
    local_value_0662 = local_value_0661 + local_value_1123 * local_value_1477
    local_value_1631.atomic_add(local_value_0662, local_value_0655, mask=local_value_1123 < local_value_0513)
    local_value_1631.atomic_add(local_value_0661 + (local_value_0513 - 1) * local_value_1477, local_value_0656)
    local_value_0806 = (local_value_0409 * local_value_0777[:, None]).to(local_value_0810.dtype.element_ty)
    local_value_0810 += local_value_1204 * local_value_1544 + local_value_1206 * local_value_0513 * local_value_1548 + local_value_1209 * local_value_1546
    local_value_0811 = local_value_0810 + (local_value_1123[:, None] * local_value_1548 + local_value_1124[None, :] * local_value_1545)
    local_value_1631.store(local_value_0811, local_value_0806, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923))

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 128}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661']))], key=['local_value_0513', 'local_value_0759', 'local_value_0923'])
@local_value_1655.jit
def execute_step_0324(local_value_1720, local_value_0762, local_value_0427, local_value_0789, local_value_0574, local_value_1346, local_value_0643, local_value_0661, local_value_0513, local_value_0759, local_value_0923, local_value_0434, local_value_1348, local_value_1090, local_value_1093, local_value_1089, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1524, local_value_1525, local_value_1597, local_value_1596, local_value_1595, local_value_1429, local_value_1432, local_value_1431, local_value_1430, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1586, local_value_1587, local_value_1454, local_value_1460, local_value_1461, local_value_1456, local_value_1455, local_value_1475, local_value_1476, local_value_1480, local_value_1477, HAS_DDA_CS: local_value_1631.constexpr, HAS_SEQ_IDX: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1213 = local_value_1631.program_id(axis=2)
    local_value_1212 = local_value_1213 // local_value_1089
    local_value_1208 = local_value_1213 - local_value_1212 * local_value_1089
    local_value_1111 = local_value_1631.cdiv(local_value_0759, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1602
    local_value_0643 += local_value_1204 * local_value_1454 + local_value_1206 * local_value_0513 * local_value_1460 + local_value_1208 * local_value_1456 + local_value_1212 * local_value_1461
    local_value_0762 += local_value_1204 * local_value_1524 + local_value_1206 * local_value_1525 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1597
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1536
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1447
    if HAS_DDA_CS:
        local_value_0427 += local_value_1204 * local_value_1429 + local_value_1206 * local_value_0513 * local_value_1432 + local_value_1208 * local_value_1431
        local_value_0661 += local_value_1204 * local_value_1475 + local_value_1206 * local_value_1476 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1480
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586 + local_value_1206 * local_value_0513 * local_value_1587
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_1722 = local_value_1720 + (local_value_1123[:, None] * local_value_1604 + local_value_1121[None, :] * local_value_1601)
    local_value_0763 = local_value_0762 + (local_value_1124[None, :] * local_value_1595 + local_value_1121[:, None] * local_value_1596)
    local_value_0790 = local_value_0789 + local_value_1123 * local_value_1534
    local_value_0575 = local_value_0574 + local_value_1123 * local_value_1446
    if HAS_DDA_CS:
        local_value_0428 = local_value_0427 + (local_value_1123[:, None] * local_value_1432 + local_value_1124[None, :] * local_value_1430)
        local_value_0662 = local_value_0661 + local_value_1123 * local_value_1477
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
    if HAS_DDA_CS:
        b = local_value_1631.load(local_value_0428, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0759), other=0.0).to(local_value_1631.float32)
    if HAS_SEQ_IDX:
        local_value_1342 = local_value_1631.load(local_value_1346 + local_value_1123 * local_value_1587, mask=local_value_1123 < local_value_0514, other=-1)
        local_value_1341 = local_value_1631.load(local_value_1346 + (local_value_0514 - 1) * local_value_1587)
    local_value_1091 = min(local_value_1093, local_value_1090 // local_value_1089 - local_value_1212 * local_value_1093)
    for h in range(local_value_1091):
        local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1121[None, :] < local_value_0923), other=0.0)
        local_value_0760 = local_value_1631.load(local_value_0763, mask=(local_value_1121[:, None] < local_value_0923) & (local_value_1124[None, :] < local_value_0759), other=0.0)
        local_value_0760 = local_value_0760.to(local_value_1722.dtype.element_ty)
        local_value_0641 = local_value_1631.dot(local_value_1699, local_value_0760)
        local_value_0568 = local_value_1631.load(local_value_0574 + (local_value_0513 - 1) * local_value_1446).to(local_value_1631.float32)
        local_value_0569 = local_value_1631.load(local_value_0575, mask=local_value_1123 < local_value_0513, other=0.0).to(local_value_1631.float32)
        local_value_0777 = local_value_1631.load(local_value_0790, mask=local_value_1123 < local_value_0513, other=0.0).to(local_value_1631.float32)
        if not HAS_SEQ_IDX:
            local_value_1302 = local_value_1631.exp(local_value_0568 - local_value_0569)
        else:
            local_value_1302 = local_value_1631.where(local_value_1342 == local_value_1341, local_value_1631.exp(local_value_0568 - local_value_0569), 0.0)
        local_value_0641 *= (local_value_1302 * local_value_0777)[:, None]
        if HAS_DDA_CS:
            local_value_0655 = local_value_1631.sum(local_value_0641 * b, axis=1)
            local_value_1631.atomic_add(local_value_0662 + local_value_1477, local_value_0655, mask=local_value_1123 < local_value_0513 - 1)
        local_value_0409 += local_value_0641
        local_value_1722 += local_value_1602
        local_value_0763 += local_value_1597
        local_value_0790 += local_value_1536
        local_value_0574 += local_value_1447
        local_value_0575 += local_value_1447
        if HAS_DDA_CS:
            local_value_0662 += local_value_1480
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0644 = local_value_0643 + (local_value_1123[:, None] * local_value_1460 + local_value_1124[None, :] * local_value_1455)
    local_value_1631.store(local_value_0644, local_value_0409, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0759))

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_N': 16, 'BLOCK_SIZE_K': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_N': 16, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=8, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=8, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=8, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=8, pre_hook=execute_step_0965(['local_value_0661']))], key=['local_value_0513', 'local_value_0923', 'local_value_0759'])
@local_value_1655.jit
def execute_step_0326(local_value_1720, local_value_0427, local_value_0762, local_value_0789, local_value_0574, local_value_1346, local_value_0661, local_value_0513, local_value_0923, local_value_0759, local_value_0434, local_value_1348, local_value_1092, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1429, local_value_1432, local_value_1431, local_value_1430, local_value_1524, local_value_1525, local_value_1597, local_value_1596, local_value_1595, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1586, local_value_1587, local_value_1475, local_value_1476, local_value_1480, local_value_1477, HAS_SEQ_IDX: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr, BLOCK_SIZE_DSTATE: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1111 = local_value_1631.cdiv(local_value_0923, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + local_value_1209 * local_value_1602
    local_value_0427 += local_value_1204 * local_value_1429 + local_value_1206 * local_value_0513 * local_value_1432 + local_value_1209 // local_value_1092 * local_value_1431
    local_value_0762 += local_value_1204 * local_value_1524 + local_value_1206 * local_value_1525 + local_value_1209 * local_value_1597
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + local_value_1209 * local_value_1536
    local_value_0661 += local_value_1204 * local_value_1475 + local_value_1206 * local_value_1476 + local_value_1209 * local_value_1480
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + local_value_1209 * local_value_1447
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586 + local_value_1206 * local_value_0513 * local_value_1587
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_DSTATE if BLOCK_SIZE_DSTATE <= 128 else BLOCK_SIZE_K)
    local_value_0428 = local_value_0427 + (local_value_1123[:, None] * local_value_1432 + local_value_1121[None, :] * local_value_1430)
    local_value_0763 = local_value_0762 + (local_value_1124[None, :] * local_value_1596 + local_value_1121[:, None] * local_value_1595)
    if BLOCK_SIZE_DSTATE <= 128:
        b = local_value_1631.load(local_value_0428, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1121[None, :] < local_value_0759), other=0.0)
        local_value_0760 = local_value_1631.load(local_value_0763, mask=(local_value_1121[:, None] < local_value_0759) & (local_value_1124[None, :] < local_value_0923), other=0.0)
        local_value_0760 = local_value_0760.to(local_value_0427.dtype.element_ty)
        local_value_0409 = local_value_1631.dot(b, local_value_0760)
    else:
        local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
        for k in range(0, local_value_0759, BLOCK_SIZE_K):
            b = local_value_1631.load(local_value_0428, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1121[None, :] < local_value_0759 - k), other=0.0)
            local_value_0760 = local_value_1631.load(local_value_0763, mask=(local_value_1121[:, None] < local_value_0759 - k) & (local_value_1124[None, :] < local_value_0923), other=0.0)
            local_value_0760 = local_value_0760.to(local_value_0427.dtype.element_ty)
            local_value_0409 += local_value_1631.dot(b, local_value_0760)
            local_value_0428 += BLOCK_SIZE_K * local_value_1430
            local_value_0763 += BLOCK_SIZE_K * local_value_1595
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0569 = local_value_1631.load(local_value_0574 + local_value_1123 * local_value_1446, mask=local_value_1123 < local_value_0513, other=0.0).to(local_value_1631.float32)
    local_value_0568 = local_value_1631.load(local_value_0574 + (local_value_0513 - 1) * local_value_1446).to(local_value_1631.float32)
    if not HAS_SEQ_IDX:
        local_value_1302 = local_value_1631.exp(local_value_0568 - local_value_0569)
    else:
        local_value_1342 = local_value_1631.load(local_value_1346 + local_value_1123 * local_value_1587, mask=local_value_1123 < local_value_0514, other=-1)
        local_value_1341 = local_value_1631.load(local_value_1346 + (local_value_0514 - 1) * local_value_1587)
        local_value_1302 = local_value_1631.where(local_value_1342 == local_value_1341, local_value_1631.exp(local_value_0568 - local_value_0569), 0.0)
    local_value_0409 *= local_value_1302[:, None]
    local_value_1722 = local_value_1720 + (local_value_1123[:, None] * local_value_1604 + local_value_1124[None, :] * local_value_1601)
    local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
    local_value_0790 = local_value_0789 + local_value_1123 * local_value_1534
    local_value_0777 = local_value_1631.load(local_value_0790, mask=local_value_1123 < local_value_0513, other=0.0).to(local_value_1631.float32)
    local_value_0672 = local_value_1631.sum(local_value_0409 * local_value_1699, axis=1)
    local_value_0655 = local_value_0672 * local_value_0777
    local_value_0662 = local_value_0661 + local_value_1123 * local_value_1477
    local_value_1631.atomic_add(local_value_0662 + local_value_1477, local_value_0655, mask=local_value_1123 < local_value_0513 - 1)

def execute_step_0297(local_value_0764, local_value_0000, local_value_0513, local_value_0767=None, local_value_0794=False, local_value_0776=(0.0, float('inf'))):
    local_value_0434, local_value_1348, local_value_1090 = local_value_0764.shape
    assert local_value_0000.shape == (local_value_1090,)
    if local_value_0767 is not None:
        assert local_value_0767.shape == (local_value_1090,)
    local_value_1078 = local_value_1039.ceil(local_value_1348 / local_value_0513)
    local_value_0781 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_0513, device=local_value_0764.device, dtype=local_value_1650.float32)
    local_value_0573 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_0513, device=local_value_0764.device, dtype=local_value_1650.float32)
    local_value_0900 = lambda local_value_0177: (local_value_0434, local_value_1078, local_value_1655.cdiv(local_value_1090, local_value_0177['local_value_0024']))
    with local_value_1650.cuda.device(local_value_0764.device.index):
        execute_step_0298[local_value_0900](local_value_0764, local_value_0000, local_value_0767, local_value_0781, local_value_0573, int(local_value_0434), int(local_value_1348), int(local_value_1090), int(local_value_0513), local_value_0776[0], local_value_0776[1], local_value_0764.stride(0), local_value_0764.stride(1), local_value_0764.stride(2), local_value_0000.stride(0), local_value_0767.stride(0) if local_value_0767 is not None else 0, local_value_0781.stride(0), local_value_0781.stride(2), local_value_0781.stride(1), local_value_0781.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), local_value_0794, HAS_DT_BIAS=local_value_0767 is not None, BLOCK_SIZE_CHUNK=local_value_1655.next_power_of_2(local_value_0513))
    return (local_value_0573, local_value_0781)

def execute_step_0295(local_value_0653, local_value_0677, local_value_0764, local_value_0000, local_value_0767=None, local_value_0794=False, local_value_0776=(0.0, float('inf')), local_value_0672=None):
    local_value_0434, local_value_1348, local_value_1090 = local_value_0764.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0653.shape
    assert local_value_0653.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0677.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0000.shape == (local_value_1090,)
    if local_value_0767 is not None:
        assert local_value_0767.shape == (local_value_1090,)
        local_value_0674 = local_value_1650.empty_like(local_value_0767, dtype=local_value_1650.float32)
    else:
        local_value_0674 = None
    if local_value_0672 is not None:
        assert local_value_0672.shape == local_value_0764.shape
    else:
        local_value_0672 = local_value_1650.empty_like(local_value_0764)
    local_value_0564 = local_value_1650.empty_like(local_value_0000, dtype=local_value_1650.float32)
    local_value_0900 = lambda local_value_0177: (local_value_0434, local_value_1078, local_value_1655.cdiv(local_value_1090, local_value_0177['local_value_0024']))
    with local_value_1650.cuda.device(local_value_0764.device.index):
        execute_step_0296[local_value_0900](local_value_0653, local_value_0677, local_value_0764, local_value_0000, local_value_0767, local_value_0672, local_value_0564, local_value_0674, int(local_value_0434), int(local_value_1348), int(local_value_1090), int(local_value_0513), local_value_0776[0], local_value_0776[1], local_value_0653.stride(0), local_value_0653.stride(2), local_value_0653.stride(1), local_value_0653.stride(3), local_value_0677.stride(0), local_value_0677.stride(2), local_value_0677.stride(1), local_value_0677.stride(3), local_value_0764.stride(0), local_value_0764.stride(1), local_value_0764.stride(2), local_value_0000.stride(0), local_value_0767.stride(0) if local_value_0767 is not None else 0, local_value_0672.stride(0), local_value_0672.stride(1), local_value_0672.stride(2), local_value_0564.stride(0), local_value_0674.stride(0) if local_value_0674 is not None else 0, local_value_0794, HAS_DT_BIAS=local_value_0767 is not None, BLOCK_SIZE_CHUNK=local_value_1655.next_power_of_2(local_value_0513))
    return (local_value_0672, local_value_0564, local_value_0674)

def execute_step_0329(B, local_value_1699, local_value_0764, local_value_0573, local_value_1339=None, local_value_1400=None, local_value_1405=True):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
    assert local_value_1090 % local_value_1089 == 0
    assert B.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0573.shape == local_value_0764.shape
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    if local_value_1400 is not None:
        assert local_value_1400.shape == (local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759)
    else:
        local_value_1404 = local_value_1650.float32 if local_value_1405 else B.dtype
        local_value_1400 = local_value_1650.empty((local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759), device=local_value_1699.device, dtype=local_value_1404)
    local_value_0899 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0925, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0759, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1090)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0330[local_value_0899](local_value_1699, B, local_value_1400, local_value_0764, local_value_0573, local_value_1339, int(local_value_0925), int(local_value_0759), int(local_value_0513), int(local_value_0434), int(local_value_1348), int(local_value_1090 // local_value_1089), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), B.stride(0), B.stride(1), B.stride(2), B.stride(-1), local_value_1400.stride(0), local_value_1400.stride(1), local_value_1400.stride(2), local_value_1400.stride(3), local_value_1400.stride(4), local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), HAS_SEQ_IDX=local_value_1339 is not None)
    return local_value_1400

def execute_step_0327(B, local_value_1699, local_value_0764, local_value_0573, local_value_0760, local_value_0806=None):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
    assert local_value_1090 % local_value_1089 == 0
    assert B.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0573.shape == local_value_0764.shape
    assert local_value_0760.shape == (local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759)
    if local_value_0806 is not None:
        assert local_value_0806.shape == local_value_1699.shape
    else:
        local_value_0806 = local_value_1650.empty_like(local_value_1699)
    local_value_0672 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_0513, device=local_value_0764.device, dtype=local_value_1650.float32)
    local_value_0658 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_0513, device=local_value_0573.device, dtype=local_value_1650.float32)
    local_value_0907 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0925, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1090)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0328[local_value_0907](local_value_1699, B, local_value_0760, local_value_0764, local_value_0573, local_value_0806, local_value_0672, local_value_0658, int(local_value_0513), int(local_value_0925), int(local_value_0759), int(local_value_0434), int(local_value_1348), int(local_value_1090 // local_value_1089), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), B.stride(0), B.stride(1), B.stride(2), B.stride(-1), local_value_0760.stride(0), local_value_0760.stride(1), local_value_0760.stride(2), local_value_0760.stride(3), local_value_0760.stride(4), local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), local_value_0806.stride(0), local_value_0806.stride(1), local_value_0806.stride(2), local_value_0806.stride(3), local_value_0672.stride(0), local_value_0672.stride(2), local_value_0672.stride(1), local_value_0672.stride(3), local_value_0658.stride(0), local_value_0658.stride(2), local_value_0658.stride(1), local_value_0658.stride(3), BLOCK_SIZE_DSTATE=max(local_value_1655.next_power_of_2(local_value_0759), 16))
    return (local_value_0806, local_value_0672.to(local_value_0764.dtype), local_value_0658.to(local_value_0573.dtype))

def execute_step_0323(local_value_1699, local_value_0764, local_value_0573, local_value_0760, local_value_1339=None, B=None, local_value_1089=1):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    local_value_0759 = local_value_0760.shape[-1]
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0573.shape == local_value_0764.shape
    assert local_value_0760.shape == (local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759)
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    if B is not None:
        assert B.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
        local_value_0038 = (B.stride(0), B.stride(1), B.stride(2), B.stride(3))
        local_value_0658 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_0513, device=local_value_1699.device, dtype=local_value_1650.float32)
        local_value_0663 = (local_value_0658.stride(0), local_value_0658.stride(2), local_value_0658.stride(1), local_value_0658.stride(3))
    else:
        local_value_0038 = (0, 0, 0, 0)
        local_value_0658 = None
        local_value_0663 = (0, 0, 0, 0)
    local_value_1092 = local_value_1090 // local_value_1089
    local_value_1355 = local_value_1650.cuda.get_device_properties(local_value_1699.device).multi_processor_count
    local_value_1093 = max(min(local_value_1039.ceil(local_value_0434 * local_value_1078 * local_value_1090 / local_value_1355), local_value_1092), 1)
    local_value_1107 = local_value_1655.cdiv(local_value_1092, local_value_1093)
    local_value_0582 = local_value_1650.empty(local_value_0434, local_value_1348, local_value_1107, local_value_1089, local_value_0759, device=local_value_1699.device, dtype=local_value_1650.float32)
    local_value_0901 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0759, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1107 * local_value_1089)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0324[local_value_0901](local_value_1699, local_value_0760, B, local_value_0764, local_value_0573, local_value_1339, local_value_0582, local_value_0658, int(local_value_0513), int(local_value_0759), int(local_value_0925), int(local_value_0434), int(local_value_1348), int(local_value_1090), int(local_value_1093), int(local_value_1089), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), local_value_0760.stride(0), local_value_0760.stride(1), local_value_0760.stride(2), local_value_0760.stride(3), local_value_0760.stride(4), *local_value_0038, local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), local_value_0582.stride(0), local_value_0582.stride(1), local_value_0582.stride(2), local_value_0582.stride(3), local_value_0582.stride(4), *local_value_0663, HAS_DDA_CS=local_value_0658 is not None, HAS_SEQ_IDX=local_value_1339 is not None, BLOCK_SIZE_K=max(local_value_1655.next_power_of_2(local_value_0925), 16))
    local_value_0582 = local_value_0582.sum(2)
    if local_value_0658 is not None:
        local_value_1650.cumsum(local_value_0658, dim=-1, out=local_value_0658)
    return local_value_0582 if B is None else (local_value_0582, local_value_0658)

def execute_step_0325(B, local_value_1699, local_value_0764, local_value_0573, local_value_0760, local_value_1339=None):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
    assert local_value_1090 % local_value_1089 == 0
    assert B.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0573.shape == local_value_0764.shape
    assert local_value_0760.shape == (local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759)
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    local_value_0658 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_0513, device=local_value_1699.device, dtype=local_value_1650.float32)
    local_value_0905 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0925, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1090)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0326[local_value_0905](local_value_1699, B, local_value_0760, local_value_0764, local_value_0573, local_value_1339, local_value_0658, int(local_value_0513), int(local_value_0925), int(local_value_0759), int(local_value_0434), int(local_value_1348), int(local_value_1090 // local_value_1089), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), B.stride(0), B.stride(1), B.stride(2), B.stride(-1), local_value_0760.stride(0), local_value_0760.stride(1), local_value_0760.stride(2), local_value_0760.stride(3), local_value_0760.stride(4), local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), local_value_0658.stride(0), local_value_0658.stride(2), local_value_0658.stride(1), local_value_0658.stride(3), HAS_SEQ_IDX=local_value_1339 is not None, BLOCK_SIZE_M=max(local_value_1655.next_power_of_2(local_value_0513), 16), BLOCK_SIZE_DSTATE=max(local_value_1655.next_power_of_2(local_value_0759), 16))
    local_value_1650.cumsum(local_value_0658[..., 1:], dim=-1, out=local_value_0658[..., 1:])
    return local_value_0658

class ComponentUnit0065(local_value_1650.autograd.Function):

    @staticmethod
    def forward(local_value_0551, B, local_value_1699, local_value_0764, local_value_0573, local_value_1405=True):
        local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
        local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
        assert local_value_1348 <= local_value_1078 * local_value_0513
        local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
        assert B.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
        assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
        assert local_value_0573.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
        if B.stride(-1) != 1:
            B = B.contiguous()
        if local_value_1699.stride(-1) != 1 and local_value_1699.stride(1) != 1:
            local_value_1699 = local_value_1699.contiguous()
        local_value_1400 = execute_step_0329(B, local_value_1699, local_value_0764, local_value_0573, local_value_1405=local_value_1405)
        local_value_0551.save_for_backward(B, local_value_1699, local_value_0764, local_value_0573)
        return local_value_1400

    @staticmethod
    def backward(local_value_0551, local_value_0760):
        B, local_value_1699, local_value_0764, local_value_0573 = local_value_0551.saved_tensors
        local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
        local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
        local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
        assert local_value_0760.shape == (local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759)
        if local_value_0760.stride(-1) != 1:
            local_value_0760 = local_value_0760.contiguous()
        local_value_0806, local_value_0672, local_value_0658 = execute_step_0327(B, local_value_1699, local_value_0764, local_value_0573, local_value_0760)
        local_value_0582 = execute_step_0323(local_value_1699, local_value_0764, local_value_0573, local_value_0760, local_value_1089=local_value_1089)
        local_value_0582 = local_value_0582.to(B.dtype)
        return (local_value_0582, local_value_0806, local_value_0672, local_value_0658, None)

def execute_step_0516(B, local_value_1699, local_value_0764, local_value_0573, local_value_1405=True):
    return ComponentUnit0065.apply(B, local_value_1699, local_value_0764, local_value_0573, local_value_1405)

def execute_step_0517(B, local_value_1699, local_value_0764, local_value_0573):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0759 = B.shape[-1]
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    assert local_value_1348 <= local_value_1078 * local_value_0513
    assert local_value_1699.shape == (local_value_0434, local_value_1348, local_value_1090, local_value_0925)
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    local_value_1089 = B.shape[2]
    assert local_value_1090 % local_value_1089 == 0
    assert B.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    B = repeat(B, 'b l g d -> b l (g h) d', h=local_value_1090 // local_value_1089)
    assert local_value_0573.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    if local_value_1348 < local_value_1078 * local_value_0513:
        local_value_1699 = local_value_0117.pad(local_value_1699, (0, 0, 0, 0, 0, local_value_1078 * local_value_0513 - local_value_1348))
        B = local_value_0117.pad(B, (0, 0, 0, 0, 0, local_value_1078 * local_value_0513 - local_value_1348))
    local_value_1699 = local_value_1249(local_value_1699, 'b (c l) h p -> b c l h p', l=local_value_0513)
    B = local_value_1249(B, 'b (c l) ... -> b c l ...', l=local_value_0513)
    local_value_0686 = local_value_1650.exp(local_value_0573[:, :, :, -1:] - local_value_0573)
    return local_value_1650.einsum('bclhn,bhcl,bhcl,bclhp->bchpn', B.to(local_value_1699.dtype), local_value_0686.to(local_value_1699.dtype), local_value_0764.to(local_value_1699.dtype), local_value_1699)
