import torch as local_value_1650
import triton as local_value_1655
import triton.language as local_value_1631

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_N': 32}), local_value_1655.Config({'BLOCK_N': 64}), local_value_1655.Config({'BLOCK_N': 128}), local_value_1655.Config({'BLOCK_N': 256}), local_value_1655.Config({'BLOCK_N': 512}), local_value_1655.Config({'BLOCK_N': 1024})], key=['local_value_1079'])
@local_value_1655.jit
def execute_step_0392(local_value_0261, local_value_0267, local_value_0198, local_value_1603, local_value_1606, local_value_1567, local_value_1079, BLOCK_N: local_value_1631.constexpr):
    local_value_1286 = local_value_1631.program_id(0)
    local_value_1387 = local_value_1631.program_id(1) * BLOCK_N
    local_value_0261 += local_value_1286 * local_value_1603
    local_value_0267 += local_value_1286 * local_value_1606
    local_value_0198 += local_value_1286 * local_value_1567
    local_value_0527 = local_value_1387 + local_value_1631.arange(0, BLOCK_N)
    local_value_1699 = local_value_1631.load(local_value_0261 + local_value_0527, mask=local_value_0527 < local_value_1079, other=0.0).to(local_value_1631.float32)
    y = local_value_1631.load(local_value_0267 + local_value_0527, mask=local_value_0527 < local_value_1079, other=0.0).to(local_value_1631.float32)
    out = local_value_1699 * local_value_1631.sigmoid(local_value_1699) * y
    local_value_1631.store(local_value_0198 + local_value_0527, out, mask=local_value_0527 < local_value_1079)

def execute_step_0391(local_value_1734, out=None):
    if local_value_1734.stride(-1) != 1:
        local_value_1734 = local_value_1734.contiguous()
    local_value_0436 = local_value_1734.shape[:-1]
    local_value_1734 = local_value_1734.reshape(-1, local_value_1734.shape[-1])
    local_value_1699, y = local_value_1734.chunk(2, dim=-1)
    if out is None:
        out = local_value_1650.empty_like(local_value_1699)
    else:
        out = out.reshape(-1, out.shape[-1])
        assert out.shape == local_value_1699.shape
    assert out.stride(-1) == 1
    local_value_0175, N = local_value_1699.shape
    local_value_0899 = lambda local_value_0177: (local_value_0175, local_value_1655.cdiv(N, local_value_0177['BLOCK_N']))
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0392[local_value_0899](local_value_1699, y, out, local_value_1699.stride(0), y.stride(0), out.stride(0), N)
    return out.reshape(*local_value_0436, out.shape[-1])

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_N': 32}), local_value_1655.Config({'BLOCK_N': 64}), local_value_1655.Config({'BLOCK_N': 128}), local_value_1655.Config({'BLOCK_N': 256}), local_value_1655.Config({'BLOCK_N': 512}), local_value_1655.Config({'BLOCK_N': 1024})], key=['local_value_1079'])
@local_value_1655.heuristics({'RECOMPUTE_OUTPUT': lambda local_value_0416: local_value_0416['local_value_0198'] is not None})
@local_value_1655.jit
def execute_step_0390(local_value_0261, local_value_0267, local_value_0092, local_value_0198, local_value_0101, local_value_0103, local_value_1603, local_value_1606, local_value_1511, local_value_1567, local_value_1547, local_value_1550, local_value_1079, BLOCK_N: local_value_1631.constexpr, RECOMPUTE_OUTPUT: local_value_1631.constexpr):
    local_value_1286 = local_value_1631.program_id(0)
    local_value_1387 = local_value_1631.program_id(1) * BLOCK_N
    local_value_0261 += local_value_1286 * local_value_1603
    local_value_0267 += local_value_1286 * local_value_1606
    local_value_0092 += local_value_1286 * local_value_1511
    if RECOMPUTE_OUTPUT:
        local_value_0198 += local_value_1286 * local_value_1567
    local_value_0101 += local_value_1286 * local_value_1547
    local_value_0103 += local_value_1286 * local_value_1550
    local_value_0527 = local_value_1387 + local_value_1631.arange(0, BLOCK_N)
    local_value_1699 = local_value_1631.load(local_value_0261 + local_value_0527, mask=local_value_0527 < local_value_1079, other=0.0).to(local_value_1631.float32)
    y = local_value_1631.load(local_value_0267 + local_value_0527, mask=local_value_0527 < local_value_1079, other=0.0).to(local_value_1631.float32)
    local_value_0723 = local_value_1631.load(local_value_0092 + local_value_0527, mask=local_value_0527 < local_value_1079, other=0.0).to(local_value_1631.float32)
    local_value_1728 = local_value_1631.sigmoid(local_value_1699)
    local_value_0806 = local_value_1728 * (1 + local_value_1699 * (1 - local_value_1728)) * y * local_value_0723
    local_value_0813 = local_value_1699 * local_value_1728 * local_value_0723
    local_value_1631.store(local_value_0101 + local_value_0527, local_value_0806, mask=local_value_0527 < local_value_1079)
    local_value_1631.store(local_value_0103 + local_value_0527, local_value_0813, mask=local_value_0527 < local_value_1079)
    if RECOMPUTE_OUTPUT:
        out = local_value_1699 * local_value_1728 * y
        local_value_1631.store(local_value_0198 + local_value_0527, out, mask=local_value_0527 < local_value_1079)

def execute_step_0389(local_value_1734, local_value_0723, local_value_0812=None, local_value_1250=False, out=None):
    if local_value_1734.stride(-1) != 1:
        local_value_1734 = local_value_1734.contiguous()
    if local_value_0723.stride(-1) != 1:
        local_value_0723 = local_value_0723.contiguous()
    local_value_0436 = local_value_1734.shape[:-1]
    local_value_1734 = local_value_1734.reshape(-1, local_value_1734.shape[-1])
    local_value_1699, y = local_value_1734.chunk(2, dim=-1)
    local_value_0723 = local_value_0723.reshape(-1, local_value_0723.shape[-1])
    assert local_value_0723.shape == local_value_1699.shape
    if local_value_0812 is None:
        local_value_0812 = local_value_1650.empty_like(local_value_1734)
    else:
        local_value_0812 = local_value_0812.reshape(-1, local_value_0812.shape[-1])
        assert local_value_0812.shape == local_value_1734.shape
    local_value_0806, local_value_0813 = local_value_0812.chunk(2, dim=-1)
    assert local_value_0806.stride(-1) == 1
    assert local_value_0813.stride(-1) == 1
    if local_value_1250:
        if out is None:
            out = local_value_1650.empty_like(local_value_1699)
        else:
            out = out.reshape(-1, out.shape[-1])
            assert out.shape == local_value_1699.shape
        assert out.stride(-1) == 1
    local_value_0175, N = local_value_1699.shape
    local_value_0899 = lambda local_value_0177: (local_value_0175, local_value_1655.cdiv(N, local_value_0177['BLOCK_N']))
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0390[local_value_0899](local_value_1699, y, local_value_0723, out if local_value_1250 else None, local_value_0806, local_value_0813, local_value_1699.stride(0), y.stride(0), local_value_0723.stride(0), out.stride(0) if local_value_1250 else 0, local_value_0806.stride(0), local_value_0813.stride(0), N)
    if not local_value_1250:
        return local_value_0812.reshape(*local_value_0436, local_value_0812.shape[-1])
    else:
        return (local_value_0812.reshape(*local_value_0436, local_value_0812.shape[-1]), out.reshape(*local_value_0436, out.shape[-1]))
