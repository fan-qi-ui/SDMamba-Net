import math as local_value_1039
from packaging import version
import torch as local_value_1650
import torch.nn.functional as local_value_0117
import triton as local_value_1655
import triton.language as local_value_1631
from einops import rearrange as local_value_1249, repeat
try:
    from .engine_unit_022 import execute_step_0293, execute_step_0291
except:
    from engine_unit_022 import execute_step_0293, execute_step_0291
local_value_0241 = version.parse(local_value_1655.__version__) >= version.parse('2.2.0')

def execute_step_0965(local_value_1075):
    return lambda local_value_1076: [local_value_1076[name].zero_() for name in local_value_1075 if local_value_1076[name] is not None]

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 64}, num_stages=3, num_warps=8), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 64}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=2), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=2), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=2)], key=['local_value_0513', 'local_value_0923', 'local_value_0759', 'local_value_0153'])
@local_value_1655.jit
def execute_step_0320(local_value_0484, local_value_1720, local_value_1754, local_value_1162, local_value_1167, local_value_0789, local_value_0574, local_value_1346, local_value_0056, local_value_1226, local_value_0108, local_value_0513, local_value_0923, local_value_0759, local_value_0434, local_value_1348, local_value_1092, local_value_1438, local_value_1439, local_value_1443, local_value_1441, local_value_1440, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1607, local_value_1612, local_value_1610, local_value_1609, local_value_1562, local_value_1568, local_value_1566, local_value_1565, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1586, local_value_1587, local_value_1418, local_value_1422, local_value_1421, local_value_1419, local_value_1592, local_value_1593, local_value_1597, local_value_1596, local_value_1595, local_value_1424, local_value_0153: local_value_1631.constexpr, local_value_0128: local_value_1631.constexpr, local_value_0106: local_value_1631.constexpr, HAS_Z: local_value_1631.constexpr, HAS_SEQ_IDX: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr, BLOCK_SIZE_DSTATE: local_value_1631.constexpr, IS_TRITON_22: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1111 = local_value_1631.cdiv(local_value_0923, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_0484 += local_value_1204 * local_value_1438 + local_value_1206 * local_value_1439 + local_value_1209 // local_value_1092 * local_value_1443
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + local_value_1209 * local_value_1602
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + local_value_1209 * local_value_1536
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + local_value_1209 * local_value_1447
    local_value_0056 += local_value_1204 * local_value_1418 + local_value_1206 * local_value_0513 * local_value_1422 + local_value_1209 // local_value_1092 * local_value_1421
    local_value_1226 += local_value_1204 * local_value_1592 + local_value_1206 * local_value_1593 + local_value_1209 * local_value_1597
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586 + local_value_1206 * local_value_0513 * local_value_1587
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0569 = local_value_1631.load(local_value_0574 + local_value_1123 * local_value_1446, mask=local_value_1123 < local_value_0513, other=0.0).to(local_value_1631.float32)
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    if HAS_SEQ_IDX:
        local_value_1345 = local_value_1631.load(local_value_1346 - local_value_1587, mask=local_value_1206 >= 1, other=0)
        local_value_1342 = local_value_1631.load(local_value_1346 + local_value_1123 * local_value_1587, mask=local_value_1123 < local_value_0514, other=-1)
    local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
    if IS_TRITON_22 or local_value_1206 > -1:
        local_value_1122 = local_value_1631.arange(0, BLOCK_SIZE_DSTATE if BLOCK_SIZE_DSTATE <= 128 else BLOCK_SIZE_K)
        local_value_0057 = local_value_0056 + (local_value_1123[:, None] * local_value_1422 + local_value_1122[None, :] * local_value_1419)
        local_value_1227 = local_value_1226 + (local_value_1124[None, :] * local_value_1596 + local_value_1122[:, None] * local_value_1595)
        if not HAS_SEQ_IDX:
            local_value_1304 = local_value_1631.exp(local_value_0569)
        else:
            local_value_1304 = local_value_1631.where(local_value_1342 == local_value_1345, local_value_1631.exp(local_value_0569), 0.0)
        if BLOCK_SIZE_DSTATE <= 128:
            local_value_0044 = local_value_1631.load(local_value_0057, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1122[None, :] < local_value_0759), other=0.0)
            local_value_1225 = local_value_1631.load(local_value_1227, mask=(local_value_1122[:, None] < local_value_0759) & (local_value_1124[None, :] < local_value_0923), other=0.0)
            local_value_1225 = local_value_1225.to(local_value_0056.dtype.element_ty)
            local_value_0409 = local_value_1631.dot(local_value_0044, local_value_1225) * local_value_1304[:, None]
        else:
            for k in range(0, local_value_0759, BLOCK_SIZE_K):
                local_value_0044 = local_value_1631.load(local_value_0057, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1122[None, :] < local_value_0759 - k), other=0.0)
                local_value_1225 = local_value_1631.load(local_value_1227, mask=(local_value_1122[:, None] < local_value_0759 - k) & (local_value_1124[None, :] < local_value_0923), other=0.0)
                local_value_1225 = local_value_1225.to(local_value_0056.dtype.element_ty)
                local_value_0409 += local_value_1631.dot(local_value_0044, local_value_1225)
                local_value_0057 += BLOCK_SIZE_K
                local_value_1227 += BLOCK_SIZE_K
            local_value_0409 *= local_value_1304[:, None]
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_0485 = local_value_0484 + (local_value_1123[:, None] * local_value_1441 + local_value_1121[None, :] * local_value_1440)
    local_value_1722 = local_value_1720 + (local_value_1121[:, None] * local_value_1604 + local_value_1124[None, :] * local_value_1601)
    local_value_0790 = local_value_0789 + local_value_1121 * local_value_1534
    local_value_0575 = local_value_0574 + local_value_1121 * local_value_1446
    local_value_0159 = local_value_0514 if not local_value_0153 else min((local_value_1210 + 1) * BLOCK_SIZE_M, local_value_0514)
    for k in range(0, local_value_0159, BLOCK_SIZE_K):
        local_value_0483 = local_value_1631.load(local_value_0485, mask=(local_value_1123[:, None] < local_value_0513) & (local_value_1121[None, :] < local_value_0513 - k), other=0.0).to(local_value_1631.float32)
        local_value_0567 = local_value_1631.load(local_value_0575, mask=local_value_1121 < local_value_0513 - k, other=0.0).to(local_value_1631.float32)
        local_value_0483 *= local_value_1631.exp(local_value_0569[:, None] - local_value_0567[None, :])
        local_value_0775 = local_value_1631.load(local_value_0790, mask=local_value_1121 < local_value_0513 - k, other=0.0).to(local_value_1631.float32)
        local_value_0483 *= local_value_0775
        if local_value_0153:
            mask = local_value_1123[:, None] >= k + local_value_1121[None, :]
            local_value_0483 = local_value_1631.where(mask, local_value_0483, 0.0)
        local_value_0483 = local_value_0483.to(local_value_1720.dtype.element_ty)
        local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1121[:, None] < local_value_0514 - k) & (local_value_1124[None, :] < local_value_0923), other=0.0)
        local_value_0409 += local_value_1631.dot(local_value_0483, local_value_1699)
        local_value_0485 += BLOCK_SIZE_K * local_value_1440
        local_value_1722 += BLOCK_SIZE_K * local_value_1604
        local_value_0790 += BLOCK_SIZE_K * local_value_1534
        local_value_0575 += BLOCK_SIZE_K * local_value_1446
    local_value_1125 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1126 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    if local_value_0128:
        if local_value_0106:
            D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424 + local_value_1124, mask=local_value_1124 < local_value_0923, other=0.0).to(local_value_1631.float32)
        else:
            D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424).to(local_value_1631.float32)
        local_value_1723 = local_value_1631.load(local_value_1720 + (local_value_1123[:, None] * local_value_1604 + local_value_1124[None, :] * local_value_1601), mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
        local_value_0409 += local_value_1723 * D
    if HAS_Z:
        local_value_1167 += local_value_1204 * local_value_1562 + local_value_1206 * local_value_0513 * local_value_1568 + local_value_1209 * local_value_1566
        local_value_1168 = local_value_1167 + (local_value_1568 * local_value_1125[:, None] + local_value_1126[None, :])
        local_value_1631.store(local_value_1168, local_value_0409, mask=(local_value_1125[:, None] < local_value_0514) & (local_value_1126[None, :] < local_value_0923))
        local_value_1754 += local_value_1204 * local_value_1607 + local_value_1206 * local_value_0513 * local_value_1612 + local_value_1209 * local_value_1610
        local_value_1755 = local_value_1754 + (local_value_1612 * local_value_1125[:, None] + local_value_1609 * local_value_1126[None, :])
        local_value_1753 = local_value_1631.load(local_value_1755, mask=(local_value_1125[:, None] < local_value_0514) & (local_value_1126[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
        local_value_0409 *= local_value_1753 * local_value_1631.sigmoid(local_value_1753)
    local_value_1162 += local_value_1204 * local_value_1562 + local_value_1206 * local_value_0513 * local_value_1568 + local_value_1209 * local_value_1566
    local_value_1163 = local_value_1162 + (local_value_1568 * local_value_1125[:, None] + local_value_1126[None, :] * local_value_1565)
    local_value_1631.store(local_value_1163, local_value_0409, mask=(local_value_1125[:, None] < local_value_0514) & (local_value_1126[None, :] < local_value_0923))

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_N': 64}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_N': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_N': 64}, num_stages=4, num_warps=8), local_value_1655.Config({'BLOCK_SIZE_N': 32}, num_stages=4, num_warps=8)], key=['local_value_0513', 'local_value_0923', 'local_value_0759'])
@local_value_1655.jit
def execute_step_0321(local_value_0484, local_value_1720, local_value_1754, local_value_1162, local_value_1167, local_value_0789, local_value_0574, local_value_1346, local_value_0056, local_value_0033, local_value_1226, local_value_0108, local_value_0513, local_value_0923, local_value_0759, local_value_0434, local_value_1348, local_value_1092, local_value_1438, local_value_1439, local_value_1443, local_value_1441, local_value_1440, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1607, local_value_1612, local_value_1610, local_value_1609, local_value_1562, local_value_1568, local_value_1566, local_value_1565, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1586, local_value_1587, local_value_1418, local_value_1422, local_value_1421, local_value_1419, local_value_1413, local_value_1417, local_value_1416, local_value_1414, local_value_1592, local_value_1593, local_value_1597, local_value_1596, local_value_1595, local_value_1424, local_value_0128: local_value_1631.constexpr, local_value_0106: local_value_1631.constexpr, HAS_Z: local_value_1631.constexpr, HAS_SEQ_IDX: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_DSTATE: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1211 = local_value_1631.program_id(axis=0)
    local_value_0484 += local_value_1204 * local_value_1438 + local_value_1206 * local_value_1439 + local_value_1209 // local_value_1092 * local_value_1443
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + local_value_1209 * local_value_1602
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + local_value_1209 * local_value_1536
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + local_value_1209 * local_value_1447
    local_value_0056 += local_value_1204 * local_value_1418 + local_value_1206 * local_value_0513 * local_value_1422 + local_value_1209 // local_value_1092 * local_value_1421
    local_value_0033 += local_value_1204 * local_value_1413 + local_value_1206 * local_value_0513 * local_value_1417 + local_value_1209 // local_value_1092 * local_value_1416
    local_value_1226 += local_value_1204 * local_value_1592 + local_value_1206 * local_value_1593 + local_value_1209 * local_value_1597
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586 + local_value_1206 * local_value_0513 * local_value_1587
    local_value_1162 += local_value_1204 * local_value_1562 + local_value_1206 * local_value_0513 * local_value_1568 + local_value_1209 * local_value_1566
    local_value_1123 = local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1122 = local_value_1631.arange(0, BLOCK_SIZE_DSTATE)
    local_value_0057 = local_value_0056 + (local_value_1123[:, None] * local_value_1422 + local_value_1122[None, :] * local_value_1419)
    local_value_0034 = local_value_0033 + (local_value_1123[None, :] * local_value_1417 + local_value_1122[:, None] * local_value_1414)
    local_value_1227 = local_value_1226 + (local_value_1124[None, :] * local_value_1596 + local_value_1122[:, None] * local_value_1595)
    local_value_1111 = local_value_1631.cdiv(local_value_0923, BLOCK_SIZE_N)
    local_value_0485 = local_value_0484 + (local_value_1123[:, None] * local_value_1441 + local_value_1123[None, :] * local_value_1440)
    local_value_1722 = local_value_1720 + (local_value_1123[:, None] * local_value_1604 + local_value_1124[None, :] * local_value_1601)
    local_value_0790 = local_value_0789 + local_value_1123 * local_value_1534
    local_value_1163 = local_value_1162 + (local_value_1123[:, None] * local_value_1568 + local_value_1124[None, :] * local_value_1565)
    local_value_1225 = local_value_1631.load(local_value_1227, mask=(local_value_1122[:, None] < local_value_0759) & (local_value_1124[None, :] < local_value_0923), other=0.0)
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    for local_value_1388 in range(0, local_value_0514, BLOCK_SIZE_M):
        local_value_1388 = local_value_1631.multiple_of(local_value_1388, BLOCK_SIZE_M)
        local_value_0569 = local_value_1631.load(local_value_0574 + (local_value_1388 + local_value_1123) * local_value_1446, mask=local_value_1123 < local_value_0513 - local_value_1388, other=0.0).to(local_value_1631.float32)
        if HAS_SEQ_IDX:
            local_value_1345 = local_value_1631.load(local_value_1346 + local_value_1388 - local_value_1587, mask=local_value_1206 >= 1, other=0)
            local_value_1342 = local_value_1631.load(local_value_1346 + (local_value_1388 + local_value_1123) * local_value_1587, mask=local_value_1123 < local_value_0514 - local_value_1388, other=-1)
        if not HAS_SEQ_IDX:
            local_value_1304 = local_value_1631.exp(local_value_0569)
        else:
            local_value_1304 = local_value_1631.where(local_value_1342 == local_value_1345, local_value_1631.exp(local_value_0569), 0.0)
        local_value_0044 = local_value_1631.load(local_value_0057, mask=(local_value_1123[:, None] < local_value_0514 - local_value_1388) & (local_value_1122[None, :] < local_value_0759), other=0.0)
        local_value_0409 = local_value_1631.dot(local_value_0044, local_value_1225.to(local_value_0056.dtype.element_ty)) * local_value_1304[:, None]
        local_value_0777 = local_value_1631.load(local_value_0790, mask=local_value_1123 < local_value_0513 - local_value_1388, other=0.0).to(local_value_1631.float32)
        local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1123[:, None] < local_value_0514 - local_value_1388) & (local_value_1124[None, :] < local_value_0923), other=0.0)
        if local_value_0128:
            if local_value_0106:
                D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424 + local_value_1124, mask=local_value_1124 < local_value_0923, other=0.0).to(local_value_1631.float32)
            else:
                D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424).to(local_value_1631.float32)
            local_value_0409 += local_value_1699.to(local_value_1631.float32) * D
        local_value_1631.store(local_value_1163, local_value_0409, mask=(local_value_1123[:, None] < local_value_0514 - local_value_1388) & (local_value_1124[None, :] < local_value_0923))
        if local_value_1388 + BLOCK_SIZE_M < local_value_0514:
            B = local_value_1631.load(local_value_0034, mask=(local_value_1123[None, :] < local_value_0514 - local_value_1388) & (local_value_1122[:, None] < local_value_0759), other=0.0)
            local_value_0568 = local_value_1631.load(local_value_0574 + (local_value_1388 + BLOCK_SIZE_M) * local_value_1446).to(local_value_1631.float32)
            local_value_1302 = local_value_1631.exp(local_value_0568 - local_value_0569) * local_value_0777
            B = B.to(local_value_1720.dtype.element_ty)
            local_value_1632 = local_value_1631.dot(B, local_value_1699)
            local_value_1225 += local_value_1632.to(local_value_1225.dtype)
        local_value_0057 += BLOCK_SIZE_M * local_value_1422
        local_value_0034 += BLOCK_SIZE_M * local_value_1417
        local_value_0485 += BLOCK_SIZE_M * local_value_1441 + BLOCK_SIZE_M * local_value_1440
        local_value_1722 += BLOCK_SIZE_M * local_value_1604
        local_value_0790 += BLOCK_SIZE_M * local_value_1534
        local_value_1163 += BLOCK_SIZE_M * local_value_1568

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 32}), local_value_1655.Config({'BLOCK_SIZE_M': 64}), local_value_1655.Config({'BLOCK_SIZE_M': 128}), local_value_1655.Config({'BLOCK_SIZE_M': 256})], key=['local_value_0513', 'local_value_0923'])
@local_value_1655.jit
def execute_step_0316(local_value_0726, local_value_1162, local_value_1754, local_value_1720, local_value_0108, local_value_1179, local_value_0817, local_value_0731, local_value_0591, local_value_0661, local_value_0513, local_value_0923, local_value_0434, local_value_1348, local_value_1504, local_value_1512, local_value_1510, local_value_1509, local_value_1562, local_value_1568, local_value_1566, local_value_1565, local_value_1607, local_value_1612, local_value_1610, local_value_1609, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1424, local_value_1571, local_value_1574, local_value_1573, local_value_1572, local_value_1551, local_value_1555, local_value_1553, local_value_1552, local_value_1513, local_value_1516, local_value_1515, local_value_1514, local_value_1449, local_value_1450, local_value_1453, local_value_1451, local_value_1452, local_value_1475, local_value_1476, local_value_1480, local_value_1477, local_value_0128: local_value_1631.constexpr, local_value_0106: local_value_1631.constexpr, local_value_0129: local_value_1631.constexpr, RECOMPUTE_OUTPUT: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1210 = local_value_1631.program_id(axis=0)
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1206 * local_value_0513 * local_value_1512 + local_value_1209 * local_value_1510
    local_value_0731 += local_value_1204 * local_value_1513 + local_value_1206 * local_value_0513 * local_value_1516 + local_value_1209 * local_value_1515
    local_value_1162 += local_value_1204 * local_value_1562 + local_value_1206 * local_value_0513 * local_value_1568 + local_value_1209 * local_value_1566
    local_value_1754 += local_value_1204 * local_value_1607 + local_value_1206 * local_value_0513 * local_value_1612 + local_value_1209 * local_value_1610
    local_value_0817 += local_value_1204 * local_value_1551 + local_value_1206 * local_value_0513 * local_value_1555 + local_value_1209 * local_value_1553
    if RECOMPUTE_OUTPUT:
        local_value_1179 += local_value_1204 * local_value_1571 + local_value_1206 * local_value_0513 * local_value_1574 + local_value_1209 * local_value_1573
    if local_value_0129:
        local_value_0661 += local_value_1204 * local_value_1475 + local_value_1206 * local_value_1476 + local_value_1209 * local_value_1480
    if local_value_0128:
        local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + local_value_1209 * local_value_1602
        local_value_0591 += local_value_1204 * local_value_1449 + local_value_1206 * local_value_1450 + local_value_1209 * local_value_1453 + local_value_1210 * local_value_1451
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0727 = local_value_0726 + (local_value_1123[:, None] * local_value_1512 + local_value_1124[None, :] * local_value_1509)
    local_value_0732 = local_value_0731 + (local_value_1123[:, None] * local_value_1516 + local_value_1124[None, :] * local_value_1514)
    local_value_1163 = local_value_1162 + (local_value_1123[:, None] * local_value_1568 + local_value_1124[None, :] * local_value_1565)
    local_value_1755 = local_value_1754 + (local_value_1123[:, None] * local_value_1612 + local_value_1124[None, :] * local_value_1609)
    local_value_0818 = local_value_0817 + (local_value_1123[:, None] * local_value_1555 + local_value_1124[None, :] * local_value_1552)
    if RECOMPUTE_OUTPUT:
        local_value_1180 = local_value_1179 + (local_value_1123[:, None] * local_value_1574 + local_value_1124[None, :] * local_value_1572)
    if local_value_0128:
        local_value_1722 = local_value_1720 + (local_value_1123[:, None] * local_value_1604 + local_value_1124[None, :] * local_value_1601)
        if local_value_0106:
            local_value_0592 = local_value_0591 + local_value_1124 * local_value_1452
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0723 = local_value_1631.load(local_value_0727, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
    out = local_value_1631.load(local_value_1163, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
    local_value_1753 = local_value_1631.load(local_value_1755, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
    local_value_1758 = local_value_1631.sigmoid(local_value_1753)
    if RECOMPUTE_OUTPUT:
        local_value_1178 = out * local_value_1753 * local_value_1758
        local_value_1631.store(local_value_1180, local_value_1178, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923))
    local_value_0816 = local_value_0723 * out * local_value_1758 * (1 + local_value_1753 * (1 - local_value_1758))
    local_value_1631.store(local_value_0818, local_value_0816, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923))
    local_value_0723 *= local_value_1753 * local_value_1758
    local_value_1631.store(local_value_0732, local_value_0723, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923))
    if local_value_0128:
        local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
        if local_value_0106:
            local_value_0589 = local_value_1631.sum(local_value_0723 * local_value_1699, axis=0)
            local_value_1631.store(local_value_0592, local_value_0589, mask=local_value_1124 < local_value_0923)
            D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424 + local_value_1124, mask=local_value_1124 < local_value_0923, other=0.0).to(local_value_1631.float32)
        else:
            local_value_0589 = local_value_1631.sum(local_value_0723 * local_value_1699)
            local_value_1631.store(local_value_0591, local_value_0589)
            D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424).to(local_value_1631.float32)
        out -= local_value_1699 * D
    if local_value_0129:
        local_value_0655 = local_value_1631.sum(local_value_0723 * out, axis=1)
        local_value_1631.store(local_value_0661 + local_value_1123 * local_value_1477, local_value_0655, mask=local_value_1123 < local_value_0513)

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 64}, num_stages=3, num_warps=8), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=2), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=2), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=2)], key=['local_value_0923', 'local_value_0759', 'local_value_0513'])
@local_value_1655.jit
def execute_step_0312(local_value_0726, local_value_0468, local_value_0740, local_value_0574, local_value_1346, local_value_0923, local_value_0759, local_value_0513, local_value_0434, local_value_1348, local_value_1078, local_value_1092, local_value_1504, local_value_1512, local_value_1510, local_value_1509, local_value_1434, local_value_1437, local_value_1436, local_value_1435, local_value_1517, local_value_1518, local_value_1521, local_value_1520, local_value_1519, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1586, local_value_1587, HAS_SEQ_IDX: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1111 = local_value_1631.cdiv(local_value_0759, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_0468 += local_value_1204 * local_value_1434 + local_value_1206 * local_value_0513 * local_value_1437 + local_value_1209 // local_value_1092 * local_value_1436
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1206 * local_value_0513 * local_value_1512 + local_value_1209 * local_value_1510
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + local_value_1209 * local_value_1447
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586 + local_value_1206 * local_value_0513 * local_value_1587
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_0727 = local_value_0726 + (local_value_1123[:, None] * local_value_1509 + local_value_1121[None, :] * local_value_1512)
    local_value_0469 = local_value_0468 + (local_value_1124[None, :] * local_value_1435 + local_value_1121[:, None] * local_value_1437)
    local_value_0575 = local_value_0574 + local_value_1121 * local_value_1446
    if HAS_SEQ_IDX:
        local_value_1347 = local_value_1346 + local_value_1121 * local_value_1587
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
    if HAS_SEQ_IDX:
        local_value_1345 = local_value_1631.load(local_value_1346 - local_value_1587, mask=local_value_1206 >= 1, other=0)
    for k in range(0, local_value_0514, BLOCK_SIZE_K):
        local_value_0723 = local_value_1631.load(local_value_0727, mask=(local_value_1123[:, None] < local_value_0923) & (local_value_1121[None, :] < local_value_0514 - k), other=0.0).to(local_value_1631.float32)
        local_value_0567 = local_value_1631.load(local_value_0575, mask=local_value_1121 < local_value_0513 - k, other=0.0).to(local_value_1631.float32)
        if not HAS_SEQ_IDX:
            local_value_1303 = local_value_1631.exp(local_value_0567)
        else:
            local_value_1340 = local_value_1631.load(local_value_1347, mask=local_value_1121 < local_value_0514 - k, other=-1)
            local_value_1303 = local_value_1631.where(local_value_1340 == local_value_1345, local_value_1631.exp(local_value_0567), 0.0)
        local_value_0723 = (local_value_0723 * local_value_1303).to(local_value_0726.dtype.element_ty)
        c = local_value_1631.load(local_value_0469, mask=(local_value_1121[:, None] < local_value_0514 - k) & (local_value_1124[None, :] < local_value_0759), other=0.0)
        local_value_0409 += local_value_1631.dot(local_value_0723, c)
        local_value_0727 += BLOCK_SIZE_K * local_value_1512
        local_value_0469 += BLOCK_SIZE_K * local_value_1437
        local_value_0575 += BLOCK_SIZE_K * local_value_1446
        if HAS_SEQ_IDX:
            local_value_1347 += BLOCK_SIZE_K * local_value_1587
    out = local_value_0409.to(local_value_0740.dtype.element_ty)
    local_value_0740 += local_value_1204 * local_value_1517 + local_value_1206 * local_value_1518 + local_value_1209 * local_value_1521
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0741 = local_value_0740 + (local_value_1123[:, None] * local_value_1520 + local_value_1124[None, :] * local_value_1519)
    local_value_1631.store(local_value_0741, out, mask=(local_value_1123[:, None] < local_value_0923) & (local_value_1124[None, :] < local_value_0759))

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 128}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661']))], key=['local_value_0513', 'local_value_0759', 'local_value_0923'])
@local_value_1655.jit
def execute_step_0300(local_value_0726, local_value_1226, local_value_0056, local_value_0574, local_value_1346, local_value_0648, local_value_0661, local_value_0513, local_value_0759, local_value_0923, local_value_0434, local_value_1348, local_value_1090, local_value_1093, local_value_1089, local_value_1504, local_value_1512, local_value_1510, local_value_1509, local_value_1575, local_value_1576, local_value_1579, local_value_1578, local_value_1577, local_value_1418, local_value_1422, local_value_1421, local_value_1419, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1586, local_value_1587, local_value_1462, local_value_1465, local_value_1466, local_value_1464, local_value_1463, local_value_1475, local_value_1476, local_value_1480, local_value_1477, HAS_DDA_CS: local_value_1631.constexpr, HAS_SEQ_IDX: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1213 = local_value_1631.program_id(axis=2)
    local_value_1212 = local_value_1213 // local_value_1089
    local_value_1208 = local_value_1213 - local_value_1212 * local_value_1089
    local_value_1111 = local_value_1631.cdiv(local_value_0759, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1206 * local_value_0513 * local_value_1512 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1510
    local_value_0648 += local_value_1204 * local_value_1462 + local_value_1206 * local_value_0513 * local_value_1465 + local_value_1208 * local_value_1464 + local_value_1212 * local_value_1466
    local_value_1226 += local_value_1204 * local_value_1575 + local_value_1206 * local_value_1576 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1579
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1447
    if HAS_DDA_CS:
        local_value_0056 += local_value_1204 * local_value_1418 + local_value_1206 * local_value_0513 * local_value_1422 + local_value_1208 * local_value_1421
        local_value_0661 += local_value_1204 * local_value_1475 + local_value_1206 * local_value_1476 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1480
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586 + local_value_1206 * local_value_0513 * local_value_1587
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_0727 = local_value_0726 + (local_value_1123[:, None] * local_value_1512 + local_value_1121[None, :] * local_value_1509)
    local_value_1227 = local_value_1226 + (local_value_1124[None, :] * local_value_1577 + local_value_1121[:, None] * local_value_1578)
    local_value_0575 = local_value_0574 + local_value_1123 * local_value_1446
    if HAS_DDA_CS:
        local_value_0057 = local_value_0056 + (local_value_1123[:, None] * local_value_1422 + local_value_1124[None, :] * local_value_1419)
        local_value_0662 = local_value_0661 + local_value_1123 * local_value_1477
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
    if HAS_DDA_CS:
        c = local_value_1631.load(local_value_0057, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0759), other=0.0).to(local_value_1631.float32)
    if HAS_SEQ_IDX:
        local_value_1345 = local_value_1631.load(local_value_1346 - local_value_1587, mask=local_value_1206 >= 1, other=0)
        local_value_1342 = local_value_1631.load(local_value_1346 + local_value_1123 * local_value_1587, mask=local_value_1123 < local_value_0514, other=-1)
    local_value_1091 = min(local_value_1093, local_value_1090 // local_value_1089 - local_value_1212 * local_value_1093)
    for h in range(local_value_1091):
        local_value_0723 = local_value_1631.load(local_value_0727, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1121[None, :] < local_value_0923), other=0.0)
        local_value_1225 = local_value_1631.load(local_value_1227, mask=(local_value_1121[:, None] < local_value_0923) & (local_value_1124[None, :] < local_value_0759), other=0.0)
        local_value_1225 = local_value_1225.to(local_value_0727.dtype.element_ty)
        local_value_0647 = local_value_1631.dot(local_value_0723, local_value_1225)
        local_value_0569 = local_value_1631.load(local_value_0575, mask=local_value_1123 < local_value_0514, other=0.0).to(local_value_1631.float32)
        if not HAS_SEQ_IDX:
            local_value_1302 = local_value_1631.exp(local_value_0569)
        else:
            local_value_1302 = local_value_1631.where(local_value_1342 == local_value_1345, local_value_1631.exp(local_value_0569), 0.0)
        local_value_0647 *= local_value_1302[:, None]
        if HAS_DDA_CS:
            local_value_0655 = local_value_1631.sum(local_value_0647 * c, axis=1)
            local_value_1631.atomic_add(local_value_0662, local_value_0655, mask=local_value_1123 < local_value_0513)
        local_value_0409 += local_value_0647
        local_value_0727 += local_value_1510
        local_value_1227 += local_value_1579
        local_value_0575 += local_value_1447
        if HAS_DDA_CS:
            local_value_0662 += local_value_1480
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0649 = local_value_0648 + (local_value_1123[:, None] * local_value_1465 + local_value_1124[None, :] * local_value_1463)
    local_value_1631.store(local_value_0649, local_value_0409, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0759))

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 64}, num_stages=3, num_warps=8, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680']))], key=['local_value_0513', 'local_value_0923'])
@local_value_1655.jit
def execute_step_0314(local_value_1720, local_value_0484, local_value_0726, local_value_0789, local_value_0574, local_value_0108, local_value_0810, local_value_0680, local_value_0513, local_value_0923, local_value_0434, local_value_1348, local_value_1092, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1438, local_value_1439, local_value_1443, local_value_1441, local_value_1440, local_value_1504, local_value_1512, local_value_1510, local_value_1509, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1424, local_value_1544, local_value_1548, local_value_1546, local_value_1545, local_value_1488, local_value_1490, local_value_1492, local_value_1491, local_value_0128: local_value_1631.constexpr, local_value_0106: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1111 = local_value_1631.cdiv(local_value_0923, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + local_value_1209 * local_value_1602
    local_value_0484 += local_value_1204 * local_value_1438 + local_value_1206 * local_value_1439 + local_value_1209 // local_value_1092 * local_value_1443
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1206 * local_value_0513 * local_value_1512 + local_value_1209 * local_value_1510
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + local_value_1209 * local_value_1536
    local_value_0680 += local_value_1204 * local_value_1488 + local_value_1206 * local_value_1490 + local_value_1209 * local_value_1492
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + local_value_1209 * local_value_1447
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_0485 = local_value_0484 + (local_value_1123[:, None] * local_value_1441 + local_value_1121[None, :] * local_value_1440)
    local_value_0727 = local_value_0726 + (local_value_1121[:, None] * local_value_1512 + local_value_1124[None, :] * local_value_1509)
    local_value_0575 = local_value_0574 + local_value_1121 * local_value_1446
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0569 = local_value_1631.load(local_value_0574 + local_value_1123 * local_value_1446, mask=local_value_1123 < local_value_0514, other=0.0).to(local_value_1631.float32)
    local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
    local_value_0159 = local_value_0514
    for k in range(0, local_value_0159, BLOCK_SIZE_K):
        local_value_0483 = local_value_1631.load(local_value_0485, mask=(local_value_1123[:, None] < local_value_0513) & (local_value_1121[None, :] < local_value_0159 - k), other=0.0)
        local_value_0723 = local_value_1631.load(local_value_0727, mask=(local_value_1121[:, None] < local_value_0159 - k) & (local_value_1124[None, :] < local_value_0923), other=0.0)
        local_value_0567 = local_value_1631.load(local_value_0575, mask=local_value_1121 < local_value_0159 - k, other=0.0).to(local_value_1631.float32)
        local_value_0483 *= local_value_1631.exp(local_value_0567[None, :] - local_value_0569[:, None])
        mask = k + local_value_1121[None, :] >= local_value_1123[:, None]
        local_value_0483 = local_value_1631.where(mask, local_value_0483, 0.0)
        local_value_0483 = local_value_0483.to(local_value_0726.dtype.element_ty)
        local_value_0409 += local_value_1631.dot(local_value_0483, local_value_0723)
        local_value_0485 += BLOCK_SIZE_K * local_value_1440
        local_value_0727 += BLOCK_SIZE_K * local_value_1512
        local_value_0575 += BLOCK_SIZE_K * local_value_1446
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0790 = local_value_0789 + local_value_1123 * local_value_1534
    local_value_0777 = local_value_1631.load(local_value_0790, mask=local_value_1123 < local_value_0514, other=0.0).to(local_value_1631.float32)
    local_value_0806 = local_value_0409 * local_value_0777[:, None]
    local_value_0810 += local_value_1204 * local_value_1544 + local_value_1206 * local_value_0513 * local_value_1548 + local_value_1209 * local_value_1546
    local_value_0811 = local_value_0810 + (local_value_1123[:, None] * local_value_1548 + local_value_1124[None, :] * local_value_1545)
    if local_value_0128:
        local_value_0729 = local_value_0726 + (local_value_1123[:, None] * local_value_1512 + local_value_1124[None, :] * local_value_1509)
        local_value_0728 = local_value_1631.load(local_value_0729, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
        if local_value_0106:
            D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424 + local_value_1124, mask=local_value_1124 < local_value_0923, other=0.0).to(local_value_1631.float32)
        else:
            D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424).to(local_value_1631.float32)
        local_value_0806 += local_value_0728 * D
    local_value_1631.store(local_value_0811, local_value_0806, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923))
    local_value_1722 = local_value_1720 + (local_value_1123[:, None] * local_value_1604 + local_value_1124[None, :] * local_value_1601)
    local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
    local_value_0672 = local_value_1631.sum(local_value_0409 * local_value_1699, axis=1)
    local_value_0681 = local_value_0680 + local_value_1123 * local_value_1491
    local_value_1631.atomic_add(local_value_0681, local_value_0672, mask=local_value_1123 < local_value_0513)

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 128}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4)], key=['local_value_0513', 'local_value_0923'])
@local_value_1655.jit
def execute_step_0302(local_value_1720, local_value_0726, local_value_0484, local_value_0789, local_value_0574, local_value_1346, local_value_0651, local_value_0661, local_value_0513, local_value_0923, local_value_0434, local_value_1348, local_value_1090, local_value_1093, local_value_1089, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1504, local_value_1512, local_value_1510, local_value_1509, local_value_1438, local_value_1439, local_value_1443, local_value_1441, local_value_1442, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1586, local_value_1587, local_value_1467, local_value_1468, local_value_1472, local_value_1471, local_value_1469, local_value_1470, local_value_1475, local_value_1476, local_value_1480, local_value_1478, local_value_1479, HAS_DDA_CS: local_value_1631.constexpr, HAS_SEQ_IDX: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1213 = local_value_1631.program_id(axis=2)
    local_value_1212 = local_value_1213 // local_value_1089
    local_value_1208 = local_value_1213 - local_value_1212 * local_value_1089
    local_value_1111 = local_value_1631.cdiv(local_value_0513, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1602
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1206 * local_value_0513 * local_value_1512 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1510
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1536
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1447
    if HAS_DDA_CS:
        local_value_0484 += local_value_1204 * local_value_1438 + local_value_1206 * local_value_1439 + local_value_1208 * local_value_1443
        local_value_0661 += local_value_1204 * local_value_1475 + local_value_1206 * local_value_1476 + (local_value_1208 * (local_value_1090 // local_value_1089) + local_value_1212 * local_value_1093) * local_value_1480 + local_value_1210 * local_value_1478
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586 + local_value_1206 * local_value_0513 * local_value_1587
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_0727 = local_value_0726 + (local_value_1123[:, None] * local_value_1512 + local_value_1121[None, :] * local_value_1509)
    local_value_1722 = local_value_1720 + (local_value_1124[None, :] * local_value_1604 + local_value_1121[:, None] * local_value_1601)
    local_value_0790 = local_value_0789 + local_value_1124 * local_value_1534
    if HAS_DDA_CS:
        local_value_0485 = local_value_0484 + (local_value_1123[:, None] * local_value_1441 + local_value_1124[None, :] * local_value_1442)
        local_value_0662 = local_value_0661 + local_value_1124 * local_value_1479
    if local_value_1211 * BLOCK_SIZE_N >= (local_value_1210 + 1) * BLOCK_SIZE_M:
        local_value_0651 += local_value_1204 * local_value_1467 + local_value_1206 * local_value_1468 + local_value_1208 * local_value_1471 + local_value_1212 * local_value_1472
        local_value_0652 = local_value_0651 + (local_value_1123[:, None] * local_value_1469 + local_value_1124[None, :] * local_value_1470)
        local_value_1631.store(local_value_0652, local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_0651.dtype.element_ty), mask=(local_value_1123[:, None] < local_value_0513) & (local_value_1124[None, :] < local_value_0513))
        return
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0515 = min(local_value_0514, (local_value_1210 + 1) * BLOCK_SIZE_M)
    local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
    if HAS_DDA_CS:
        local_value_0483 = local_value_1631.load(local_value_0485, mask=(local_value_1123[:, None] < local_value_0513) & (local_value_1124[None, :] < local_value_0513), other=0.0).to(local_value_1631.float32)
    local_value_1091 = min(local_value_1093, local_value_1090 // local_value_1089 - local_value_1212 * local_value_1093)
    for h in range(local_value_1091):
        local_value_0723 = local_value_1631.load(local_value_0727, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1121[None, :] < local_value_0923), other=0.0)
        local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1121[:, None] < local_value_0923) & (local_value_1124[None, :] < local_value_0515), other=0.0)
        local_value_0650 = local_value_1631.dot(local_value_0723, local_value_1699)
        local_value_0780 = local_value_1631.load(local_value_0790, mask=local_value_1124 < local_value_0513, other=0.0).to(local_value_1631.float32)
        local_value_0650 *= local_value_0780
        local_value_0569 = local_value_1631.load(local_value_0574 + local_value_1123 * local_value_1446, mask=local_value_1123 < local_value_0514, other=0.0).to(local_value_1631.float32)
        local_value_0570 = local_value_1631.load(local_value_0574 + local_value_1124 * local_value_1446, mask=local_value_1124 < local_value_0514, other=0.0).to(local_value_1631.float32)
        local_value_0650 *= local_value_1631.exp(local_value_0569[:, None] - local_value_0570[None, :])
        if HAS_DDA_CS:
            local_value_1631.static_assert(not HAS_SEQ_IDX, 'HAS_SEQ_IDX not supported with HAS_DDA_CS yet')
            local_value_0655 = local_value_0650 * local_value_0483
            mask = local_value_1123[:, None] >= local_value_1124[None, :] + 1
            local_value_0655 = local_value_1631.where(mask, local_value_0655, 0.0)
            local_value_0655 = local_value_1631.cumsum(local_value_0655, axis=1)
            local_value_0655 = local_value_1631.where(mask, local_value_0655, 0.0)
            local_value_0655 = local_value_1631.sum(local_value_0655, axis=0)
            local_value_1631.store(local_value_0662 + local_value_1479, local_value_0655, mask=local_value_1124 < local_value_0513 - 1)
            local_value_1631.store(local_value_0661, 0.0)
        local_value_0409 += local_value_0650
        local_value_0727 += local_value_1510
        local_value_1722 += local_value_1602
        local_value_0790 += local_value_1536
        local_value_0574 += local_value_1447
        if HAS_DDA_CS:
            local_value_0661 += local_value_1480
            local_value_0662 += local_value_1480
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    if HAS_SEQ_IDX:
        local_value_1342 = local_value_1631.load(local_value_1346 + local_value_1123 * local_value_1587, mask=local_value_1123 < local_value_0514, other=-1)
        local_value_1343 = local_value_1631.load(local_value_1346 + local_value_1124 * local_value_1587, mask=local_value_1124 < local_value_0514, other=-2)
        local_value_0409 = local_value_1631.where(local_value_1342[:, None] == local_value_1343[None, :], local_value_0409, 0.0)
    mask = local_value_1123[:, None] >= local_value_1124[None, :]
    local_value_0409 = local_value_1631.where(mask, local_value_0409, 0.0)
    local_value_0651 += local_value_1204 * local_value_1467 + local_value_1206 * local_value_1468 + local_value_1208 * local_value_1471 + local_value_1212 * local_value_1472
    local_value_0652 = local_value_0651 + (local_value_1123[:, None] * local_value_1469 + local_value_1124[None, :] * local_value_1470)
    local_value_1631.store(local_value_0652, local_value_0409, mask=(local_value_1123[:, None] < local_value_0513) & (local_value_1124[None, :] < local_value_0513))

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 32}), local_value_1655.Config({'BLOCK_SIZE_M': 64}), local_value_1655.Config({'BLOCK_SIZE_M': 128}), local_value_1655.Config({'BLOCK_SIZE_M': 256})], key=['local_value_0513', 'local_value_0923'])
@local_value_1655.jit
def execute_step_0310(local_value_0726, local_value_1162, local_value_0789, local_value_0680, local_value_1720, local_value_0108, local_value_0661, local_value_0591, local_value_0513, local_value_0923, local_value_0434, local_value_1348, local_value_1504, local_value_1512, local_value_1510, local_value_1509, local_value_1562, local_value_1568, local_value_1566, local_value_1565, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1488, local_value_1490, local_value_1492, local_value_1491, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1424, local_value_1475, local_value_1476, local_value_1480, local_value_1477, local_value_1449, local_value_1450, local_value_1453, local_value_1451, local_value_1452, local_value_0128: local_value_1631.constexpr, local_value_0106: local_value_1631.constexpr, local_value_0229: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1210 = local_value_1631.program_id(axis=0)
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1206 * local_value_0513 * local_value_1512 + local_value_1209 * local_value_1510
    local_value_1162 += local_value_1204 * local_value_1562 + local_value_1206 * local_value_0513 * local_value_1568 + local_value_1209 * local_value_1566
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + local_value_1209 * local_value_1536
    local_value_0680 += local_value_1204 * local_value_1488 + local_value_1206 * local_value_1490 + local_value_1209 * local_value_1492
    local_value_0661 += local_value_1204 * local_value_1475 + local_value_1206 * local_value_1476 + local_value_1209 * local_value_1480
    if local_value_0128:
        local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + local_value_1209 * local_value_1602
        local_value_0591 += local_value_1204 * local_value_1449 + local_value_1206 * local_value_1450 + local_value_1209 * local_value_1453 + local_value_1210 * local_value_1451
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0727 = local_value_0726 + (local_value_1123[:, None] * local_value_1512 + local_value_1124[None, :] * local_value_1509)
    local_value_1163 = local_value_1162 + (local_value_1123[:, None] * local_value_1568 + local_value_1124[None, :] * local_value_1565)
    if local_value_0128:
        local_value_1722 = local_value_1720 + (local_value_1123[:, None] * local_value_1604 + local_value_1124[None, :] * local_value_1601)
        if local_value_0106:
            local_value_0592 = local_value_0591 + local_value_1124 * local_value_1452
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0723 = local_value_1631.load(local_value_0727, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
    out = local_value_1631.load(local_value_1163, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
    if local_value_0128:
        local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
        if local_value_0106:
            local_value_0589 = local_value_1631.sum(local_value_0723 * local_value_1699, axis=0)
            local_value_1631.store(local_value_0592, local_value_0589, mask=local_value_1124 < local_value_0923)
            D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424 + local_value_1124, mask=local_value_1124 < local_value_0923, other=0.0).to(local_value_1631.float32)
        else:
            local_value_0589 = local_value_1631.sum(local_value_0723 * local_value_1699)
            local_value_1631.store(local_value_0591, local_value_0589)
            D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424).to(local_value_1631.float32)
        out -= local_value_1699 * D
    local_value_0655 = local_value_1631.sum(local_value_0723 * out, axis=1)
    if local_value_0229:
        local_value_0764 = local_value_1631.load(local_value_0789 + local_value_1123 * local_value_1534, mask=local_value_1123 < local_value_0513, other=0.0).to(local_value_1631.float32)
        local_value_0672 = local_value_1631.load(local_value_0680 + local_value_1123 * local_value_1491, mask=local_value_1123 < local_value_0513, other=0.0).to(local_value_1631.float32)
        local_value_0655 -= local_value_0764 * local_value_0672
    local_value_1631.store(local_value_0661 + local_value_1123 * local_value_1477, local_value_0655, mask=local_value_1123 < local_value_0513)

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 16}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 32}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 16}, num_stages=4, num_warps=8), local_value_1655.Config({'BLOCK_SIZE_M': 32}, num_stages=4, num_warps=8), local_value_1655.Config({'BLOCK_SIZE_M': 64}, num_stages=4, num_warps=8), local_value_1655.Config({'BLOCK_SIZE_M': 128}, num_stages=4, num_warps=8)], key=['local_value_0513', 'local_value_0923'])
@local_value_1655.jit
def execute_step_0307(local_value_1720, local_value_0726, local_value_0789, local_value_0574, local_value_0484, local_value_0668, local_value_0513, local_value_0923, local_value_0434, local_value_1348, local_value_1092, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1504, local_value_1512, local_value_1510, local_value_1509, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1438, local_value_1439, local_value_1443, local_value_1441, local_value_1442, local_value_1483, local_value_1484, local_value_1487, local_value_1485, local_value_1486, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1111 = local_value_1631.cdiv(local_value_0513, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + local_value_1209 * local_value_1602
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1206 * local_value_0513 * local_value_1512 + local_value_1209 * local_value_1510
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + local_value_1209 * local_value_1536
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + local_value_1209 * local_value_1447
    local_value_0484 += local_value_1204 * local_value_1438 + local_value_1206 * local_value_1439 + local_value_1209 // local_value_1092 * local_value_1443
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_0727 = local_value_0726 + (local_value_1123[:, None] * local_value_1512 + local_value_1121[None, :] * local_value_1509)
    local_value_1722 = local_value_1720 + (local_value_1124[None, :] * local_value_1604 + local_value_1121[:, None] * local_value_1601)
    local_value_0790 = local_value_0789 + local_value_1124 * local_value_1534
    local_value_0485 = local_value_0484 + (local_value_1123[:, None] * local_value_1441 + local_value_1124[None, :] * local_value_1442)
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0515 = min(local_value_0514, (local_value_1210 + 1) * BLOCK_SIZE_M)
    local_value_0723 = local_value_1631.load(local_value_0727, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1121[None, :] < local_value_0923), other=0.0)
    local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1121[:, None] < local_value_0923) & (local_value_1124[None, :] < local_value_0515), other=0.0)
    local_value_0409 = local_value_1631.dot(local_value_0723, local_value_1699)
    local_value_0483 = local_value_1631.load(local_value_0485, mask=(local_value_1123[:, None] < local_value_0513) & (local_value_1124[None, :] < local_value_0513), other=0.0).to(local_value_1631.float32)
    local_value_0409 *= local_value_0483
    local_value_0780 = local_value_1631.load(local_value_0790, mask=local_value_1124 < local_value_0513, other=0.0).to(local_value_1631.float32)
    local_value_0409 *= local_value_0780
    local_value_0569 = local_value_1631.load(local_value_0574 + local_value_1123 * local_value_1446, mask=local_value_1123 < local_value_0513, other=0.0).to(local_value_1631.float32)
    local_value_0570 = local_value_1631.load(local_value_0574 + local_value_1124 * local_value_1446, mask=local_value_1124 < local_value_0513, other=0.0).to(local_value_1631.float32)
    local_value_0409 *= local_value_1631.exp(local_value_0569[:, None] - local_value_0570[None, :])
    mask = local_value_1123[:, None] >= local_value_1124[None, :] + 1
    local_value_0409 = local_value_1631.where(mask, local_value_0409, 0.0)
    local_value_0409 = local_value_1631.cumsum(local_value_0409, axis=1)
    local_value_0409 = local_value_1631.where(mask, local_value_0409, 0.0)
    local_value_0655 = local_value_1631.sum(local_value_0409, axis=0)
    local_value_0668 += local_value_1204 * local_value_1483 + local_value_1206 * local_value_1484 + local_value_1209 * local_value_1487 + local_value_1210 * local_value_1485
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0669 = local_value_0668 + local_value_1124 * local_value_1486
    local_value_1631.store(local_value_0669 + local_value_1486, local_value_0655, mask=local_value_1124 < local_value_0513 - 1)
    local_value_1631.store(local_value_0668, 0.0)

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 128}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 128}, num_stages=3, num_warps=4)], key=['local_value_0513', 'local_value_0923'])
@local_value_1655.jit
def execute_step_0306(local_value_1720, local_value_0726, local_value_0789, local_value_0574, local_value_0484, local_value_0661, local_value_0513, local_value_0923, local_value_0434, local_value_1348, local_value_1092, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1504, local_value_1512, local_value_1510, local_value_1509, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1438, local_value_1439, local_value_1443, local_value_1441, local_value_1442, local_value_1475, local_value_1476, local_value_1480, local_value_1478, local_value_1479, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1210 = local_value_1631.program_id(axis=0)
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + local_value_1209 * local_value_1602
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1206 * local_value_0513 * local_value_1512 + local_value_1209 * local_value_1510
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + local_value_1209 * local_value_1536
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + local_value_1209 * local_value_1447
    local_value_0484 += local_value_1204 * local_value_1438 + local_value_1206 * local_value_1439 + local_value_1209 // local_value_1092 * local_value_1443
    local_value_0661 += local_value_1204 * local_value_1475 + local_value_1206 * local_value_1476 + local_value_1209 * local_value_1480 + local_value_1210 * local_value_1478
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_0727 = local_value_0726 + (local_value_1123[:, None] * local_value_1512 + local_value_1121[None, :] * local_value_1509)
    local_value_1722 = local_value_1720 + (local_value_1124[None, :] * local_value_1604 + local_value_1121[:, None] * local_value_1601)
    local_value_0790 = local_value_0789 + local_value_1124 * local_value_1534
    local_value_0485 = local_value_0484 + (local_value_1123[:, None] * local_value_1441 + local_value_1124[None, :] * local_value_1442)
    local_value_0669 = local_value_0661 + local_value_1124 * local_value_1479
    local_value_1631.store(local_value_0661, 0.0)
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_1292 = local_value_1631.zeros((BLOCK_SIZE_M,), dtype=local_value_1631.float32)
    local_value_0723 = local_value_1631.load(local_value_0727, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1121[None, :] < local_value_0923), other=0.0)
    local_value_0569 = local_value_1631.load(local_value_0574 + local_value_1123 * local_value_1446, mask=local_value_1123 < local_value_0513, other=0.0).to(local_value_1631.float32)
    local_value_1022, local_value_0926 = (0, (local_value_1210 + 1) * BLOCK_SIZE_M)
    for local_value_1389 in range(local_value_1022, local_value_0926, BLOCK_SIZE_N):
        local_value_1389 = local_value_1631.multiple_of(local_value_1389, BLOCK_SIZE_N)
        local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1121[:, None] < local_value_0923) & (local_value_1124[None, :] < local_value_0514 - local_value_1389), other=0.0)
        local_value_0409 = local_value_1631.dot(local_value_0723, local_value_1699)
        local_value_0780 = local_value_1631.load(local_value_0790, mask=local_value_1124 < local_value_0513 - local_value_1389, other=0.0).to(local_value_1631.float32)
        local_value_0409 *= local_value_0780
        local_value_0483 = local_value_1631.load(local_value_0485, mask=(local_value_1123[:, None] < local_value_0513) & (local_value_1124[None, :] < local_value_0513 - local_value_1389), other=0.0).to(local_value_1631.float32)
        local_value_0409 *= local_value_0483
        local_value_0570 = local_value_1631.load(local_value_0574 + local_value_1389 + local_value_1124 * local_value_1446, mask=local_value_1124 < local_value_0513 - local_value_1389, other=0.0).to(local_value_1631.float32)
        local_value_0409 *= local_value_1631.exp(local_value_0569[:, None] - local_value_0570[None, :])
        mask = local_value_1123[:, None] >= local_value_1389 + local_value_1124[None, :] + 1
        local_value_0409 = local_value_1631.where(mask, local_value_0409, 0.0)
        local_value_1293 = local_value_1292 + local_value_1631.sum(local_value_0409, axis=1)
        local_value_0409 = local_value_1292[:, None] + local_value_1631.cumsum(local_value_0409, axis=1)
        local_value_1292 = local_value_1293
        local_value_0409 = local_value_1631.where(mask, local_value_0409, 0.0)
        local_value_0655 = local_value_1631.sum(local_value_0409, axis=0)
        local_value_1631.store(local_value_0669 + local_value_1479, local_value_0655, mask=local_value_1124 < local_value_0513 - local_value_1389 - 1)
        local_value_1722 += BLOCK_SIZE_N * local_value_1604
        local_value_0790 += BLOCK_SIZE_N * local_value_1534
        local_value_0485 += BLOCK_SIZE_N * local_value_1442
        local_value_0669 += BLOCK_SIZE_N * local_value_1479
    for local_value_1389 in range(local_value_0926, local_value_0513, BLOCK_SIZE_N):
        local_value_1631.store(local_value_0669 + local_value_1479, local_value_1631.zeros((BLOCK_SIZE_N,), dtype=local_value_1631.float32), mask=local_value_1124 < local_value_0513 - local_value_1389 - 1)
        local_value_0669 += BLOCK_SIZE_N * local_value_1479

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 128}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661'])), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 32}, num_stages=3, num_warps=4, pre_hook=execute_step_0965(['local_value_0661']))], key=['local_value_0513', 'local_value_0759', 'local_value_0923'])
@local_value_1655.jit
def execute_step_0304(local_value_0726, local_value_1226, local_value_0056, local_value_0574, local_value_1346, local_value_0661, local_value_0513, local_value_0759, local_value_0923, local_value_0434, local_value_1348, local_value_1078, local_value_1092, local_value_1504, local_value_1512, local_value_1510, local_value_1509, local_value_1575, local_value_1576, local_value_1579, local_value_1578, local_value_1577, local_value_1418, local_value_1422, local_value_1421, local_value_1419, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1586, local_value_1587, local_value_1475, local_value_1476, local_value_1480, local_value_1477, HAS_SEQ_IDX: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1111 = local_value_1631.cdiv(local_value_0759, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1206 * local_value_0513 * local_value_1512 + local_value_1209 * local_value_1510
    local_value_1226 += local_value_1204 * local_value_1575 + local_value_1206 * local_value_1576 + local_value_1209 * local_value_1579
    local_value_0056 += local_value_1204 * local_value_1418 + local_value_1206 * local_value_0513 * local_value_1422 + local_value_1209 // local_value_1092 * local_value_1421
    local_value_0661 += local_value_1204 * local_value_1475 + local_value_1206 * local_value_1476 + local_value_1209 * local_value_1480
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + local_value_1209 * local_value_1447
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586 + local_value_1206 * local_value_0513 * local_value_1587
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_0727 = local_value_0726 + (local_value_1123[:, None] * local_value_1512 + local_value_1121[None, :] * local_value_1509)
    local_value_1227 = local_value_1226 + (local_value_1124[None, :] * local_value_1577 + local_value_1121[:, None] * local_value_1578)
    local_value_0057 = local_value_0056 + (local_value_1123[:, None] * local_value_1422 + local_value_1124[None, :] * local_value_1419)
    local_value_0575 = local_value_0574 + local_value_1123 * local_value_1446
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0723 = local_value_1631.load(local_value_0727, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1121[None, :] < local_value_0923), other=0.0)
    local_value_1225 = local_value_1631.load(local_value_1227, mask=(local_value_1121[:, None] < local_value_0923) & (local_value_1124[None, :] < local_value_0759), other=0.0)
    local_value_1225 = local_value_1225.to(local_value_0727.dtype.element_ty)
    local_value_0409 = local_value_1631.dot(local_value_0723, local_value_1225)
    c = local_value_1631.load(local_value_0057, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0759), other=0.0).to(local_value_1631.float32)
    local_value_0655 = local_value_1631.sum(local_value_0409 * c, axis=1)
    local_value_0569 = local_value_1631.load(local_value_0575, mask=local_value_1123 < local_value_0514, other=0.0).to(local_value_1631.float32)
    if not HAS_SEQ_IDX:
        local_value_1302 = local_value_1631.exp(local_value_0569)
    if HAS_SEQ_IDX:
        local_value_1345 = local_value_1631.load(local_value_1346 - local_value_1587, mask=local_value_1206 >= 1, other=0)
        local_value_1342 = local_value_1631.load(local_value_1346 + local_value_1123 * local_value_1587, mask=local_value_1123 < local_value_0514, other=-1)
        local_value_1302 = local_value_1631.where(local_value_1342 == local_value_1345, local_value_1631.exp(local_value_0569), 0.0)
    local_value_0655 *= local_value_1302
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0662 = local_value_0661 + local_value_1123 * local_value_1477
    local_value_1631.atomic_add(local_value_0662, local_value_0655, mask=local_value_1123 < local_value_0513)

def execute_step_0319(local_value_0483, local_value_1699, local_value_0764, local_value_0573, local_value_0044, local_value_1400, D=None, local_value_1753=None, local_value_1339=None):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = local_value_0044.shape
    assert local_value_1090 % local_value_1089 == 0
    assert local_value_0044.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    assert local_value_0483.shape == (local_value_0434, local_value_1078, local_value_1089, local_value_0513, local_value_0513)
    if local_value_1753 is not None:
        assert local_value_1753.shape == local_value_1699.shape
    if D is not None:
        assert D.shape == (local_value_1090, local_value_0925) or D.shape == (local_value_1090,)
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0573.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_1400.shape == (local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759)
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    out = local_value_1650.empty(local_value_0434, local_value_1348, local_value_1090, local_value_0925, device=local_value_1699.device, dtype=local_value_1699.dtype)
    if local_value_1753 is not None:
        local_value_1166 = local_value_1650.empty(local_value_0434, local_value_1348, local_value_1090, local_value_0925, device=local_value_1699.device, dtype=local_value_1699.dtype)
        assert local_value_1166.stride() == out.stride()
    else:
        local_value_1166 = None
    local_value_0899 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0925, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1090)
    local_value_1759 = (local_value_1753.stride(0), local_value_1753.stride(1), local_value_1753.stride(2), local_value_1753.stride(3)) if local_value_1753 is not None else (0, 0, 0, 0)
    execute_step_0320[local_value_0899](local_value_0483, local_value_1699, local_value_1753, out, local_value_1166, local_value_0764, local_value_0573, local_value_1339, local_value_0044, local_value_1400, D, int(local_value_0513), int(local_value_0925), int(local_value_0759), int(local_value_0434), int(local_value_1348), int(local_value_1090 // local_value_1089), local_value_0483.stride(0), local_value_0483.stride(1), local_value_0483.stride(2), local_value_0483.stride(3), local_value_0483.stride(4), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), local_value_1759[0], local_value_1759[1], local_value_1759[2], local_value_1759[3], out.stride(0), out.stride(1), out.stride(2), out.stride(3), local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), local_value_0044.stride(0), local_value_0044.stride(1), local_value_0044.stride(2), local_value_0044.stride(3), local_value_1400.stride(0), local_value_1400.stride(1), local_value_1400.stride(2), local_value_1400.stride(3), local_value_1400.stride(4), D.stride(0) if D is not None else 0, True, D is not None, D.dim() == 2 if D is not None else True, BLOCK_SIZE_DSTATE=max(local_value_1655.next_power_of_2(int(local_value_0759)), 16), HAS_Z=local_value_1753 is not None, HAS_SEQ_IDX=local_value_1339 is not None, IS_TRITON_22=local_value_0241)
    return (out, local_value_1166)

def execute_step_0322(local_value_0483, local_value_1699, local_value_0764, local_value_0573, local_value_0044, B, local_value_1400, D=None, local_value_1753=None, local_value_1339=None):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = local_value_0044.shape
    assert local_value_1090 % local_value_1089 == 0
    assert local_value_0044.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    assert B.shape == local_value_0044.shape
    assert local_value_0483.shape == (local_value_0434, local_value_1078, local_value_1089, local_value_0513, local_value_0513)
    if local_value_1753 is not None:
        assert local_value_1753.shape == local_value_1699.shape
    if D is not None:
        assert D.shape == (local_value_1090, local_value_0925) or D.shape == (local_value_1090,)
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0573.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_1400.shape == (local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759)
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    out = local_value_1650.empty(local_value_0434, local_value_1348, local_value_1090, local_value_0925, device=local_value_1699.device, dtype=local_value_1699.dtype)
    if local_value_1753 is not None:
        local_value_1166 = local_value_1650.empty(local_value_0434, local_value_1348, local_value_1090, local_value_0925, device=local_value_1699.device, dtype=local_value_1699.dtype)
        assert local_value_1166.stride() == out.stride()
    else:
        local_value_1166 = None
    local_value_0899 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0925, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1090)
    local_value_1759 = (local_value_1753.stride(0), local_value_1753.stride(1), local_value_1753.stride(2), local_value_1753.stride(3)) if local_value_1753 is not None else (0, 0, 0, 0)
    execute_step_0321[local_value_0899](local_value_0483, local_value_1699, local_value_1753, out, local_value_1166, local_value_0764, local_value_0573, local_value_1339, local_value_0044, B, local_value_1400, D, int(local_value_0513), int(local_value_0925), int(local_value_0759), int(local_value_0434), int(local_value_1348), int(local_value_1090 // local_value_1089), local_value_0483.stride(0), local_value_0483.stride(1), local_value_0483.stride(2), local_value_0483.stride(3), local_value_0483.stride(4), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), local_value_1759[0], local_value_1759[1], local_value_1759[2], local_value_1759[3], out.stride(0), out.stride(1), out.stride(2), out.stride(3), local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), local_value_0044.stride(0), local_value_0044.stride(1), local_value_0044.stride(2), local_value_0044.stride(3), B.stride(0), B.stride(1), B.stride(2), B.stride(3), local_value_1400.stride(0), local_value_1400.stride(1), local_value_1400.stride(2), local_value_1400.stride(3), local_value_1400.stride(4), D.stride(0) if D is not None else 0, D is not None, D.dim() == 2 if D is not None else True, BLOCK_SIZE_DSTATE=max(local_value_1655.next_power_of_2(int(local_value_0759)), 16), BLOCK_SIZE_M=128, HAS_Z=local_value_1753 is not None, HAS_SEQ_IDX=local_value_1339 is not None)
    return (out, local_value_1166)

def execute_step_0315(local_value_1699, local_value_1753, out, local_value_0723, local_value_0513, local_value_0915=True, D=None, local_value_0816=None, local_value_1250=False):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    assert local_value_1753.shape == local_value_1699.shape
    assert out.shape == local_value_1699.shape
    assert local_value_0723.shape == out.shape
    local_value_1078 = local_value_1039.ceil(local_value_1348 / local_value_0513)
    if D is not None:
        assert D.shape == (local_value_1090, local_value_0925) or D.shape == (local_value_1090,)
        assert D.stride(-1) == 1
    if local_value_0915:
        local_value_0658 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_0513, device=local_value_1699.device, dtype=local_value_1650.float32)
    if D is not None:
        local_value_0031 = 32
        local_value_0589 = local_value_1650.empty(local_value_1655.cdiv(local_value_0513, local_value_0031), local_value_0434, local_value_1078, local_value_1090, local_value_0925 if D.dim() == 2 else 1, device=D.device, dtype=local_value_1650.float32)
    else:
        local_value_0589 = None
    if local_value_0816 is not None:
        assert local_value_0816.shape == local_value_1753.shape
    else:
        local_value_0816 = local_value_1650.empty_like(local_value_1753)
    if local_value_1250:
        local_value_1178 = local_value_1650.empty_like(local_value_1699)
    local_value_0730 = local_value_1650.empty_like(local_value_0723)
    local_value_0593 = (local_value_0589.stride(0), local_value_0589.stride(1), local_value_0589.stride(2), local_value_0589.stride(3), local_value_0589.stride(4)) if D is not None else (0, 0, 0, 0, 0)
    local_value_0908 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']), local_value_0434 * local_value_1078, local_value_1090)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0316[local_value_0908](local_value_0723, out, local_value_1753, local_value_1699, D, local_value_1178 if local_value_1250 else None, local_value_0816, local_value_0730, local_value_0589, local_value_0658 if local_value_0915 else None, int(local_value_0513), int(local_value_0925), int(local_value_0434), int(local_value_1348), local_value_0723.stride(0), local_value_0723.stride(1), local_value_0723.stride(2), local_value_0723.stride(3), out.stride(0), out.stride(1), out.stride(2), out.stride(3), local_value_1753.stride(0), local_value_1753.stride(1), local_value_1753.stride(2), local_value_1753.stride(3), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), D.stride(0) if D is not None else 0, *((local_value_1178.stride(0), local_value_1178.stride(1), local_value_1178.stride(2), local_value_1178.stride(3)) if local_value_1250 else (0, 0, 0, 0)), local_value_0816.stride(0), local_value_0816.stride(1), local_value_0816.stride(2), local_value_0816.stride(3), local_value_0730.stride(0), local_value_0730.stride(1), local_value_0730.stride(2), local_value_0730.stride(3), local_value_0593[1], local_value_0593[2], local_value_0593[3], local_value_0593[0], local_value_0593[4], *((local_value_0658.stride(0), local_value_0658.stride(2), local_value_0658.stride(1), local_value_0658.stride(3)) if local_value_0915 else (0, 0, 0, 0)), D is not None, D.dim() == 2 if D is not None else True, local_value_0915, BLOCK_SIZE_N=max(local_value_1655.next_power_of_2(local_value_0925), 16), RECOMPUTE_OUTPUT=local_value_1250)
    if D is not None:
        local_value_0030 = execute_step_0316.best_config.kwargs['BLOCK_SIZE_M']
        local_value_1073 = (local_value_0513 + local_value_0030 - 1) // local_value_0030
        local_value_0589 = local_value_0589[:local_value_1073].sum(dim=(0, 1, 2)).to(dtype=D.dtype)
        if D.dim() == 1:
            local_value_0589 = local_value_1249(local_value_0589, 'h 1 -> h')
    local_value_1278 = (local_value_0816, local_value_0730, local_value_0589, local_value_0658) if local_value_0915 else (local_value_0816, local_value_0730, local_value_0589)
    return local_value_1278 if not local_value_1250 else (*local_value_1278, local_value_1178)

def execute_step_0311(local_value_0044, local_value_0573, local_value_0723, local_value_1339=None, dtype=None):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_0723.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0573.shape
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = local_value_0044.shape
    assert local_value_1090 % local_value_1089 == 0
    assert local_value_0044.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    assert local_value_0573.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    dtype = local_value_0044.dtype if dtype is None else dtype
    local_value_0739 = local_value_1650.empty(local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759, device=local_value_0044.device, dtype=dtype)
    local_value_0906 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0925, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0759, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1090)
    with local_value_1650.cuda.device(local_value_0044.device.index):
        execute_step_0312[local_value_0906](local_value_0723, local_value_0044, local_value_0739, local_value_0573, local_value_1339, int(local_value_0925), int(local_value_0759), int(local_value_0513), int(local_value_0434), int(local_value_1348), int(local_value_1078), int(local_value_1090 // local_value_1089), local_value_0723.stride(0), local_value_0723.stride(1), local_value_0723.stride(2), local_value_0723.stride(3), local_value_0044.stride(0), local_value_0044.stride(1), local_value_0044.stride(2), local_value_0044.stride(3), local_value_0739.stride(0), local_value_0739.stride(1), local_value_0739.stride(2), local_value_0739.stride(3), local_value_0739.stride(4), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), HAS_SEQ_IDX=local_value_1339 is not None)
    return local_value_0739

def execute_step_0299(local_value_1225, local_value_0573, local_value_0723, local_value_1339=None, local_value_0044=None, local_value_1089=1):
    local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759 = local_value_1225.shape
    local_value_0272, local_value_1348, local_value_0272, local_value_0272 = local_value_0723.shape
    local_value_0272, local_value_0272, local_value_0272, local_value_0513 = local_value_0573.shape
    assert local_value_1225.shape == (local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759)
    assert local_value_0573.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0723.shape == (local_value_0434, local_value_1348, local_value_1090, local_value_0925)
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    if local_value_0044 is not None:
        assert local_value_0044.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
        local_value_0061 = (local_value_0044.stride(0), local_value_0044.stride(1), local_value_0044.stride(2), local_value_0044.stride(3))
        local_value_0659 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_0513, device=local_value_0723.device, dtype=local_value_1650.float32)
        local_value_0660 = (local_value_0659.stride(0), local_value_0659.stride(2), local_value_0659.stride(1), local_value_0659.stride(3))
    else:
        local_value_0061 = (0, 0, 0, 0)
        local_value_0659 = None
        local_value_0660 = (0, 0, 0, 0)
    local_value_1092 = local_value_1090 // local_value_1089
    local_value_1355 = local_value_1650.cuda.get_device_properties(local_value_0723.device).multi_processor_count
    local_value_1093 = max(min(local_value_1039.ceil(local_value_0434 * local_value_1078 * local_value_1090 / local_value_1355), local_value_1092), 1)
    local_value_1107 = local_value_1655.cdiv(local_value_1092, local_value_1093)
    local_value_0585 = local_value_1650.empty(local_value_0434, local_value_1348, local_value_1107, local_value_1089, local_value_0759, device=local_value_0723.device, dtype=local_value_1650.float32)
    local_value_0902 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0759, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1107 * local_value_1089)
    with local_value_1650.cuda.device(local_value_0723.device.index):
        execute_step_0300[local_value_0902](local_value_0723, local_value_1225, local_value_0044, local_value_0573, local_value_1339, local_value_0585, local_value_0659, int(local_value_0513), int(local_value_0759), int(local_value_0925), int(local_value_0434), int(local_value_1348), int(local_value_1090), int(local_value_1093), int(local_value_1089), local_value_0723.stride(0), local_value_0723.stride(1), local_value_0723.stride(2), local_value_0723.stride(3), local_value_1225.stride(0), local_value_1225.stride(1), local_value_1225.stride(2), local_value_1225.stride(3), local_value_1225.stride(4), *local_value_0061, local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), local_value_0585.stride(0), local_value_0585.stride(1), local_value_0585.stride(2), local_value_0585.stride(3), local_value_0585.stride(4), *local_value_0660, HAS_DDA_CS=local_value_0659 is not None, HAS_SEQ_IDX=local_value_1339 is not None, BLOCK_SIZE_K=max(local_value_1655.next_power_of_2(local_value_0925), 16))
    local_value_0585 = local_value_0585.sum(2)
    return local_value_0585 if local_value_0044 is None else (local_value_0585, local_value_0659)

def execute_step_0301(local_value_1699, local_value_0764, local_value_0573, local_value_0723, local_value_1339=None, local_value_0047=None, local_value_1089=1):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0573.shape == local_value_0764.shape
    assert local_value_0723.shape == local_value_1699.shape
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    if local_value_0047 is not None:
        assert local_value_0047.shape == (local_value_0434, local_value_1078, local_value_1089, local_value_0513, local_value_0513)
        local_value_0048 = (local_value_0047.stride(0), local_value_0047.stride(1), local_value_0047.stride(2), local_value_0047.stride(3), local_value_0047.stride(4))
        local_value_0028 = 16
        local_value_0658 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_1655.cdiv(local_value_0513, local_value_0028), local_value_0513, device=local_value_1699.device, dtype=local_value_1650.float32)
        local_value_0663 = (local_value_0658.stride(0), local_value_0658.stride(2), local_value_0658.stride(1), local_value_0658.stride(3), local_value_0658.stride(4))
    else:
        local_value_0048 = (0, 0, 0, 0, 0)
        local_value_0658 = None
        local_value_0663 = (0, 0, 0, 0, 0)
    local_value_1092 = local_value_1090 // local_value_1089
    local_value_1355 = local_value_1650.cuda.get_device_properties(local_value_1699.device).multi_processor_count
    local_value_1093 = max(min(local_value_1039.ceil(local_value_0434 * local_value_1078 * local_value_1090 / local_value_1355), local_value_1092), 1)
    local_value_1107 = local_value_1655.cdiv(local_value_1092, local_value_1093)
    local_value_0650 = local_value_1650.empty(local_value_0434, local_value_1078, local_value_1107, local_value_1089, local_value_0513, local_value_0513, device=local_value_1699.device, dtype=local_value_1650.float32)
    local_value_0903 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1107 * local_value_1089)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0302[local_value_0903](local_value_1699, local_value_0723, local_value_0047, local_value_0764, local_value_0573, local_value_1339, local_value_0650, local_value_0658, int(local_value_0513), int(local_value_0925), int(local_value_0434), int(local_value_1348), int(local_value_1090), int(local_value_1093), int(local_value_1089), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), local_value_0723.stride(0), local_value_0723.stride(1), local_value_0723.stride(2), local_value_0723.stride(3), *local_value_0048, local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), local_value_0650.stride(0), local_value_0650.stride(1), local_value_0650.stride(2), local_value_0650.stride(3), local_value_0650.stride(4), local_value_0650.stride(5), *local_value_0663, HAS_DDA_CS=local_value_0658 is not None, HAS_SEQ_IDX=local_value_1339 is not None, BLOCK_SIZE_K=max(local_value_1655.next_power_of_2(local_value_0925), 16))
    local_value_0650 = local_value_0650.sum(2)
    if local_value_0658 is not None:
        local_value_0027 = execute_step_0302.best_config.kwargs['BLOCK_SIZE_M']
        local_value_1073 = (local_value_0513 + local_value_0027 - 1) // local_value_0027
        local_value_0658 = local_value_0658[:, :, :, :local_value_1073].sum(dim=3)
    return local_value_0650 if local_value_0047 is None else (local_value_0650, local_value_0658)

def execute_step_0313(local_value_0483, local_value_1699, local_value_0764, local_value_0573, local_value_0723, D=None):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    local_value_1089 = local_value_0483.shape[2]
    assert local_value_1090 % local_value_1089 == 0
    assert local_value_0483.shape == (local_value_0434, local_value_1078, local_value_1089, local_value_0513, local_value_0513)
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0573.shape == local_value_0764.shape
    assert local_value_0723.shape == local_value_1699.shape
    local_value_0806 = local_value_1650.empty_like(local_value_1699)
    local_value_0672 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_0513, device=local_value_0723.device, dtype=local_value_1650.float32)
    local_value_0907 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0925, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1090)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0314[local_value_0907](local_value_1699, local_value_0483, local_value_0723, local_value_0764, local_value_0573, D, local_value_0806, local_value_0672, int(local_value_0513), int(local_value_0925), int(local_value_0434), int(local_value_1348), int(local_value_1090 // local_value_1089), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), local_value_0483.stride(0), local_value_0483.stride(1), local_value_0483.stride(2), local_value_0483.stride(-1), local_value_0483.stride(-2), local_value_0723.stride(0), local_value_0723.stride(1), local_value_0723.stride(2), local_value_0723.stride(3), local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), D.stride(0) if D is not None else 0, local_value_0806.stride(0), local_value_0806.stride(1), local_value_0806.stride(2), local_value_0806.stride(3), local_value_0672.stride(0), local_value_0672.stride(2), local_value_0672.stride(1), local_value_0672.stride(3), D is not None, D.dim() == 2 if D is not None else True)
    return (local_value_0806, local_value_0672.to(dtype=local_value_0764.dtype))

def execute_step_0309(local_value_1699, local_value_0764, out, local_value_0723, local_value_0672, D=None, local_value_1615=True):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0672.shape == local_value_0764.shape
    assert out.shape == local_value_1699.shape
    assert local_value_0723.shape == local_value_1699.shape
    if D is not None:
        assert D.shape == (local_value_1090, local_value_0925) or D.shape == (local_value_1090,)
    local_value_0658 = local_value_1650.empty_like(local_value_0764)
    local_value_0905 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']), local_value_0434 * local_value_1078, local_value_1090)
    if D is not None:
        local_value_0031 = 32
        local_value_0589 = local_value_1650.empty(local_value_1655.cdiv(local_value_0513, local_value_0031), local_value_0434, local_value_1078, local_value_1090, local_value_0925 if D.dim() == 2 else 1, device=D.device, dtype=local_value_1650.float32)
    else:
        local_value_0589 = None
    local_value_0593 = (local_value_0589.stride(0), local_value_0589.stride(1), local_value_0589.stride(2), local_value_0589.stride(3), local_value_0589.stride(4)) if D is not None else (0, 0, 0, 0, 0)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0310[local_value_0905](local_value_0723, out, local_value_0764, local_value_0672, local_value_1699, D, local_value_0658, local_value_0589, int(local_value_0513), int(local_value_0925), int(local_value_0434), int(local_value_1348), local_value_0723.stride(0), local_value_0723.stride(1), local_value_0723.stride(2), local_value_0723.stride(3), out.stride(0), out.stride(1), out.stride(2), out.stride(3), local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0672.stride(0), local_value_0672.stride(2), local_value_0672.stride(1), local_value_0672.stride(3), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), D.stride(0) if D is not None else 0, local_value_0658.stride(0), local_value_0658.stride(2), local_value_0658.stride(1), local_value_0658.stride(3), local_value_0593[1], local_value_0593[2], local_value_0593[3], local_value_0593[0], local_value_0593[4], D is not None, D.dim() == 2 if D is not None else True, local_value_1615, BLOCK_SIZE_N=max(local_value_1655.next_power_of_2(local_value_0925), 16))
    if D is not None:
        local_value_0030 = execute_step_0310.best_config.kwargs['BLOCK_SIZE_M']
        local_value_1073 = (local_value_0513 + local_value_0030 - 1) // local_value_0030
        local_value_0589 = local_value_0589[:local_value_1073].sum(dim=(0, 1, 2)).to(dtype=D.dtype)
        if D.dim() == 1:
            local_value_0589 = local_value_1249(local_value_0589, 'h 1 -> h')
    return (local_value_0658, local_value_0589)

def execute_step_0308(local_value_1699, local_value_0764, local_value_0573, local_value_0723, local_value_0483):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0723.shape == local_value_1699.shape
    assert local_value_0573.shape == local_value_0764.shape
    local_value_1089 = local_value_0483.shape[2]
    assert local_value_1090 % local_value_1089 == 0
    assert local_value_0483.shape == (local_value_0434, local_value_1078, local_value_1089, local_value_0513, local_value_0513)
    local_value_0028 = 16
    local_value_0658 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_1655.cdiv(local_value_0513, local_value_0028), local_value_0513, device=local_value_1699.device, dtype=local_value_1650.float32)
    local_value_0905 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']), local_value_0434 * local_value_1078, local_value_1090)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0307[local_value_0905](local_value_1699, local_value_0723, local_value_0764, local_value_0573, local_value_0483, local_value_0658, int(local_value_0513), int(local_value_0925), int(local_value_0434), int(local_value_1348), int(local_value_1090 // local_value_1089), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), local_value_0723.stride(0), local_value_0723.stride(1), local_value_0723.stride(2), local_value_0723.stride(3), local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), local_value_0483.stride(0), local_value_0483.stride(1), local_value_0483.stride(2), local_value_0483.stride(3), local_value_0483.stride(4), local_value_0658.stride(0), local_value_0658.stride(2), local_value_0658.stride(1), local_value_0658.stride(3), local_value_0658.stride(4), BLOCK_SIZE_K=max(local_value_1655.next_power_of_2(local_value_0925), 16), BLOCK_SIZE_N=max(local_value_1655.next_power_of_2(local_value_0513), 16))
    local_value_0027 = execute_step_0307.best_config.kwargs['BLOCK_SIZE_M']
    local_value_1073 = (local_value_0513 + local_value_0027 - 1) // local_value_0027
    local_value_0658 = local_value_0658[:, :, :, :local_value_1073].sum(dim=3)
    return local_value_0658

def execute_step_0305(local_value_1699, local_value_0764, local_value_0573, local_value_0723, local_value_0483):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0723.shape == local_value_1699.shape
    assert local_value_0573.shape == local_value_0764.shape
    local_value_1089 = local_value_0483.shape[2]
    assert local_value_1090 % local_value_1089 == 0
    assert local_value_0483.shape == (local_value_0434, local_value_1078, local_value_1089, local_value_0513, local_value_0513)
    local_value_0028 = 32
    local_value_0658 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_1655.cdiv(local_value_0513, local_value_0028), local_value_0513, device=local_value_1699.device, dtype=local_value_1650.float32)
    local_value_0905 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']), local_value_0434 * local_value_1078, local_value_1090)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0306[local_value_0905](local_value_1699, local_value_0723, local_value_0764, local_value_0573, local_value_0483, local_value_0658, int(local_value_0513), int(local_value_0925), int(local_value_0434), int(local_value_1348), int(local_value_1090 // local_value_1089), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), local_value_0723.stride(0), local_value_0723.stride(1), local_value_0723.stride(2), local_value_0723.stride(3), local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), local_value_0483.stride(0), local_value_0483.stride(1), local_value_0483.stride(2), local_value_0483.stride(3), local_value_0483.stride(4), local_value_0658.stride(0), local_value_0658.stride(2), local_value_0658.stride(1), local_value_0658.stride(3), local_value_0658.stride(4), BLOCK_SIZE_K=max(local_value_1655.next_power_of_2(local_value_0925), 16))
    local_value_0027 = execute_step_0306.best_config.kwargs['BLOCK_SIZE_M']
    local_value_1073 = (local_value_0513 + local_value_0027 - 1) // local_value_0027
    local_value_0658 = local_value_0658[:, :, :, :local_value_1073].sum(dim=3)
    return local_value_0658

def execute_step_0303(local_value_1225, local_value_0044, local_value_0723, local_value_0573, local_value_1339=None):
    local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759 = local_value_1225.shape
    local_value_0272, local_value_1348, local_value_0272, local_value_0272 = local_value_0723.shape
    local_value_0272, local_value_0272, local_value_0272, local_value_0513 = local_value_0573.shape
    assert local_value_1225.shape == (local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759)
    assert local_value_0573.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0723.shape == (local_value_0434, local_value_1348, local_value_1090, local_value_0925)
    local_value_1089 = local_value_0044.shape[2]
    assert local_value_1090 % local_value_1089 == 0
    assert local_value_0044.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    local_value_0659 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_0513, device=local_value_0723.device, dtype=local_value_1650.float32)
    local_value_0904 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0759, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1090)
    with local_value_1650.cuda.device(local_value_0723.device.index):
        execute_step_0304[local_value_0904](local_value_0723, local_value_1225, local_value_0044, local_value_0573, local_value_1339, local_value_0659, int(local_value_0513), int(local_value_0759), int(local_value_0925), int(local_value_0434), int(local_value_1348), int(local_value_1078), int(local_value_1090 // local_value_1089), local_value_0723.stride(0), local_value_0723.stride(1), local_value_0723.stride(2), local_value_0723.stride(3), local_value_1225.stride(0), local_value_1225.stride(1), local_value_1225.stride(2), local_value_1225.stride(3), local_value_1225.stride(4), local_value_0044.stride(0), local_value_0044.stride(1), local_value_0044.stride(2), local_value_0044.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), local_value_0659.stride(0), local_value_0659.stride(2), local_value_0659.stride(1), local_value_0659.stride(3), HAS_SEQ_IDX=local_value_1339 is not None, BLOCK_SIZE_K=max(local_value_1655.next_power_of_2(local_value_0925), 16))
    return local_value_0659

class ComponentUnit0064(local_value_1650.autograd.Function):

    @staticmethod
    def forward(local_value_0551, B, local_value_0044, local_value_1699, local_value_0764, local_value_0573, local_value_1225, D=None, local_value_1753=None):
        local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
        local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
        assert B.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
        local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
        assert local_value_1348 == local_value_1078 * local_value_0513
        assert local_value_0044.shape == B.shape
        if local_value_1753 is not None:
            assert local_value_1753.shape == local_value_1699.shape
        if D is not None:
            assert D.shape == (local_value_1090, local_value_0925) or D.shape == (local_value_1090,)
        assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
        assert local_value_0573.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
        assert local_value_1225.shape == (local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759)
        if B.stride(-1) != 1:
            B = B.contiguous()
        if local_value_0044.stride(-1) != 1:
            local_value_0044 = local_value_0044.contiguous()
        if local_value_1699.stride(-1) != 1 and local_value_1699.stride(1) != 1:
            local_value_1699 = local_value_1699.contiguous()
        if local_value_1753 is not None and local_value_1753.stride(-1) != 1 and (local_value_1753.stride(1) != 1):
            local_value_1753 = local_value_1753.contiguous()
        if D is not None and D.stride(-1) != 1:
            D = D.contiguous()
        local_value_0047 = execute_step_0293(local_value_0044, B, local_value_0513)
        out, local_value_1166 = execute_step_0319(local_value_0047, local_value_1699, local_value_0764, local_value_0573, local_value_0044, local_value_1225, D=D, local_value_1753=local_value_1753)
        local_value_0551.save_for_backward(out if local_value_1753 is None else local_value_1166, B, local_value_0044, local_value_0047, local_value_1699, local_value_0764, local_value_0573, local_value_1225, D, local_value_1753)
        return out

    @staticmethod
    def backward(local_value_0551, local_value_0723):
        if local_value_0723.stride(-1) != 1:
            local_value_0723 = local_value_0723.contiguous()
        out, B, local_value_0044, local_value_0047, local_value_1699, local_value_0764, local_value_0573, local_value_1225, D, local_value_1753 = local_value_0551.saved_tensors
        local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
        local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
        local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
        assert local_value_0723.shape == (local_value_0434, local_value_1348, local_value_1090, local_value_0925)
        if local_value_1753 is not None:
            local_value_0816, local_value_0723, local_value_0589, local_value_0658 = execute_step_0315(local_value_1699, local_value_1753, out, local_value_0723, local_value_0513=local_value_0513, D=D)
        else:
            local_value_0816 = None
        local_value_0739 = execute_step_0311(local_value_0044, local_value_0573, local_value_0723, dtype=local_value_1225.dtype)
        local_value_0585 = execute_step_0299(local_value_1225, local_value_0573, local_value_0723, local_value_1089=local_value_1089)
        local_value_0585 = local_value_0585.to(local_value_0044.dtype)
        local_value_0586 = execute_step_0301(local_value_1699, local_value_0764, local_value_0573, local_value_0723, local_value_1089=local_value_1089)
        local_value_0586 = local_value_0586.to(local_value_0047.dtype)
        local_value_0582 = execute_step_0291(local_value_0044, local_value_0586)
        local_value_0585 = execute_step_0291(B, local_value_1249(local_value_0586, '... l s -> ... s l'), local_value_1268=local_value_0585)
        local_value_0806, local_value_0672 = execute_step_0313(local_value_0047, local_value_1699, local_value_0764, local_value_0573, local_value_0723, D=D)
        if local_value_1753 is not None:
            local_value_0658 -= local_value_0672 * local_value_0764
        else:
            local_value_0658, local_value_0589 = execute_step_0309(local_value_1699, local_value_0764, out, local_value_0723, local_value_0672, D=D)
        local_value_0658 = local_value_0658.to(local_value_0573.dtype)
        return (local_value_0582, local_value_0585, local_value_0806, local_value_0672, local_value_0658, local_value_0739, local_value_0589, local_value_0816)

def execute_step_0511(B, local_value_0044, local_value_1699, local_value_0764, local_value_0573, local_value_1225, D=None, local_value_1753=None):
    return ComponentUnit0064.apply(B, local_value_0044, local_value_1699, local_value_0764, local_value_0573, local_value_1225, D, local_value_1753)

def execute_step_0512(B, local_value_0044, local_value_1699, local_value_0764, local_value_0573, local_value_1225, D=None, local_value_1753=None):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
    assert B.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    assert local_value_1348 == local_value_1078 * local_value_0513
    assert local_value_0044.shape == B.shape
    B = repeat(B, 'b l g d -> b l (g h) d', h=local_value_1090 // local_value_1089)
    local_value_0044 = repeat(local_value_0044, 'b l g d -> b l (g h) d', h=local_value_1090 // local_value_1089)
    local_value_0047 = local_value_1650.einsum('bclhn,bcshn->bchls', local_value_1249(local_value_0044, 'b (c l) h n -> b c l h n', c=local_value_1078), local_value_1249(B, 'b (c s) h n -> b c s h n', c=local_value_1078))
    local_value_0793 = local_value_0573[:, :, :, :, None] - local_value_0573[:, :, :, None, :]
    local_value_0684 = local_value_1650.exp(local_value_0793)
    local_value_1310 = local_value_0047 * local_value_1249(local_value_0684, 'b h c l s -> b c h l s')
    local_value_0482 = local_value_1650.tril(local_value_1650.ones(local_value_0513, local_value_0513, device=local_value_1699.device, dtype=bool), diagonal=0)
    local_value_1310 = local_value_1310.masked_fill(~local_value_0482, 0)
    out = local_value_1650.einsum('bchls,bhcs,bcshp->bclhp', local_value_1310.to(local_value_1699.dtype), local_value_0764.to(local_value_1699.dtype), local_value_1249(local_value_1699, 'b (c s) h p -> b c s h p', c=local_value_1078))
    local_value_1392 = local_value_1650.exp(local_value_1249(local_value_0573, 'b h c l -> b c l h 1'))
    local_value_1161 = local_value_1650.einsum('bclhn,bchpn->bclhp', local_value_1249(local_value_0044, 'b (c l) h n -> b c l h n', c=local_value_1078), local_value_1225.to(local_value_0044.dtype)) * local_value_1392
    out = out + local_value_1161
    out = local_value_1249(out, 'b c l h p -> b (c l) h p')
    if D is not None:
        if D.dim() == 1:
            D = local_value_1249(D, 'h -> h 1')
        out = out + local_value_1699 * D
    return out if local_value_1753 is None else out * local_value_0117.silu(local_value_1753)
