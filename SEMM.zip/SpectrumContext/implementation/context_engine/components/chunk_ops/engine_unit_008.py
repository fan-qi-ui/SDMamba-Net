import math as local_value_1039
import torch as local_value_1650
import torch.nn.functional as local_value_0117
from torch.cuda.amp import custom_fwd as local_value_0559, custom_bwd as local_value_0558
import triton as local_value_1655
import triton.language as local_value_1631

def execute_step_1017(local_value_1699, weight, bias, local_value_1268=None, local_value_1701=None, local_value_1689=None, local_value_0442=None, eps=1e-06, dropout_p=0.0, local_value_1291=None, local_value_1223=False, local_value_0755=None, local_value_0756=None, local_value_1668=False):
    dtype = local_value_1699.dtype
    if local_value_1668:
        local_value_1699 = local_value_1699.float()
        weight = weight.float()
        bias = bias.float() if bias is not None else None
        local_value_1268 = local_value_1268.float() if local_value_1268 is not None else local_value_1268
        local_value_1701 = local_value_1701.float() if local_value_1701 is not None else None
        local_value_1689 = local_value_1689.float() if local_value_1689 is not None else None
        local_value_0442 = local_value_0442.float() if local_value_0442 is not None else None
    if local_value_1701 is not None:
        assert local_value_1291 is None, 'rowscale is not supported with parallel ComponentUnit0167'
    if local_value_1291 is not None:
        local_value_1699 = local_value_1699 * local_value_1291[..., None]
    if dropout_p > 0.0:
        if local_value_0755 is not None:
            local_value_1699 = local_value_1699.masked_fill(~local_value_0755, 0.0) / (1.0 - dropout_p)
        else:
            local_value_1699 = local_value_0117.dropout(local_value_1699, p=dropout_p)
        if local_value_1701 is not None:
            if local_value_0756 is not None:
                local_value_1701 = local_value_1701.masked_fill(~local_value_0756, 0.0) / (1.0 - dropout_p)
            else:
                local_value_1701 = local_value_0117.dropout(local_value_1701, p=dropout_p)
    if local_value_1701 is not None:
        local_value_1699 = local_value_1699 + local_value_1701
    if local_value_1268 is not None:
        local_value_1699 = (local_value_1699 + local_value_1268).to(local_value_1699.dtype)
    out = local_value_0117.layer_norm(local_value_1699.to(weight.dtype), local_value_1699.shape[-1:], weight=weight, bias=bias, eps=eps).to(dtype)
    if local_value_1689 is None:
        return out if not local_value_1223 else (out, local_value_1699)
    else:
        local_value_1140 = local_value_0117.layer_norm(local_value_1699.to(local_value_1689.dtype), local_value_1699.shape[-1:], weight=local_value_1689, bias=local_value_0442, eps=eps).to(dtype)
        return (out, local_value_1140) if not local_value_1223 else (out, local_value_1140, local_value_1699)

def execute_step_1282(local_value_1699, weight, bias, local_value_1268=None, local_value_1701=None, local_value_1689=None, local_value_0442=None, eps=1e-06, dropout_p=0.0, local_value_1291=None, local_value_1223=False, local_value_0755=None, local_value_0756=None, local_value_1668=False):
    dtype = local_value_1699.dtype
    if local_value_1668:
        local_value_1699 = local_value_1699.float()
        weight = weight.float()
        bias = bias.float() if bias is not None else None
        local_value_1268 = local_value_1268.float() if local_value_1268 is not None else local_value_1268
        local_value_1701 = local_value_1701.float() if local_value_1701 is not None else None
        local_value_1689 = local_value_1689.float() if local_value_1689 is not None else None
        local_value_0442 = local_value_0442.float() if local_value_0442 is not None else None
    if local_value_1701 is not None:
        assert local_value_1291 is None, 'rowscale is not supported with parallel ComponentUnit0167'
    if local_value_1291 is not None:
        local_value_1699 = local_value_1699 * local_value_1291[..., None]
    if dropout_p > 0.0:
        if local_value_0755 is not None:
            local_value_1699 = local_value_1699.masked_fill(~local_value_0755, 0.0) / (1.0 - dropout_p)
        else:
            local_value_1699 = local_value_0117.dropout(local_value_1699, p=dropout_p)
        if local_value_1701 is not None:
            if local_value_0756 is not None:
                local_value_1701 = local_value_1701.masked_fill(~local_value_0756, 0.0) / (1.0 - dropout_p)
            else:
                local_value_1701 = local_value_0117.dropout(local_value_1701, p=dropout_p)
    if local_value_1701 is not None:
        local_value_1699 = local_value_1699 + local_value_1701
    if local_value_1268 is not None:
        local_value_1699 = (local_value_1699 + local_value_1268).to(local_value_1699.dtype)
    local_value_1294 = 1 / local_value_1650.sqrt(local_value_1699.square().mean(dim=-1, keepdim=True) + eps)
    out = (local_value_1699 * local_value_1294 * weight + bias if bias is not None else local_value_1699 * local_value_1294 * weight).to(dtype)
    if local_value_1689 is None:
        return out if not local_value_1223 else (out, local_value_1699)
    else:
        local_value_1140 = (local_value_1699 * local_value_1294 * local_value_1689 + local_value_0442 if local_value_0442 is not None else local_value_1699 * local_value_1294 * local_value_1689).to(dtype)
        return (out, local_value_1140) if not local_value_1223 else (out, local_value_1140, local_value_1699)

@local_value_1655.autotune(configs=[local_value_1655.Config({}, num_warps=1), local_value_1655.Config({}, num_warps=2), local_value_1655.Config({}, num_warps=4), local_value_1655.Config({}, num_warps=8), local_value_1655.Config({}, num_warps=16), local_value_1655.Config({}, num_warps=32)], key=['N', 'HAS_RESIDUAL', 'local_value_0228', 'IS_RMS_NORM', 'local_value_0127'])
@local_value_1655.heuristics({'local_value_0143': lambda local_value_0416: local_value_0416['local_value_0262'] is not None})
@local_value_1655.heuristics({'local_value_0142': lambda local_value_0416: local_value_0416['local_value_0253'] is not None})
@local_value_1655.heuristics({'local_value_0126': lambda local_value_0416: local_value_0416['local_value_0015'] is not None})
@local_value_1655.jit
def execute_step_0358(local_value_0261, local_value_0267, W, B, local_value_0210, local_value_0262, local_value_0253, local_value_0015, local_value_0268, local_value_0211, local_value_0213, local_value_0217, local_value_0095, local_value_0185, local_value_0214, local_value_1603, local_value_1606, local_value_1584, local_value_1583, local_value_1598, local_value_1605, local_value_0175, N, eps, dropout_p, IS_RMS_NORM: local_value_1631.constexpr, BLOCK_N: local_value_1631.constexpr, HAS_RESIDUAL: local_value_1631.constexpr, local_value_0228: local_value_1631.constexpr, local_value_0127: local_value_1631.constexpr, local_value_0134: local_value_1631.constexpr, local_value_0227: local_value_1631.constexpr, local_value_0140: local_value_1631.constexpr, local_value_0143: local_value_1631.constexpr, local_value_0142: local_value_1631.constexpr, local_value_0126: local_value_1631.constexpr):
    local_value_1286 = local_value_1631.program_id(0)
    local_value_0261 += local_value_1286 * local_value_1603
    local_value_0267 += local_value_1286 * local_value_1606
    if HAS_RESIDUAL:
        local_value_0210 += local_value_1286 * local_value_1584
    if local_value_0228:
        local_value_0211 += local_value_1286 * local_value_1583
    if local_value_0143:
        local_value_0262 += local_value_1286 * local_value_1598
    if local_value_0142:
        local_value_0268 += local_value_1286 * local_value_1605
    local_value_0527 = local_value_1631.arange(0, BLOCK_N)
    local_value_1699 = local_value_1631.load(local_value_0261 + local_value_0527, mask=local_value_0527 < N, other=0.0).to(local_value_1631.float32)
    if local_value_0140:
        local_value_1291 = local_value_1631.load(local_value_0213 + local_value_1286).to(local_value_1631.float32)
        local_value_1699 *= local_value_1291
    if local_value_0134:
        local_value_1001 = local_value_1631.rand(local_value_1631.load(local_value_0217 + local_value_1286).to(local_value_1631.uint32), local_value_0527, n_rounds=7) > dropout_p
        local_value_1699 = local_value_1631.where(local_value_1001, local_value_1699 / (1.0 - dropout_p), 0.0)
        if local_value_0227:
            local_value_1631.store(local_value_0095 + local_value_1286 * N + local_value_0527, local_value_1001, mask=local_value_0527 < N)
    if local_value_0143:
        local_value_1701 = local_value_1631.load(local_value_0262 + local_value_0527, mask=local_value_0527 < N, other=0.0).to(local_value_1631.float32)
        if local_value_0140:
            local_value_1291 = local_value_1631.load(local_value_0213 + local_value_0175 + local_value_1286).to(local_value_1631.float32)
            local_value_1701 *= local_value_1291
        if local_value_0134:
            local_value_1001 = local_value_1631.rand(local_value_1631.load(local_value_0217 + local_value_0175 + local_value_1286).to(local_value_1631.uint32), local_value_0527, n_rounds=7) > dropout_p
            local_value_1701 = local_value_1631.where(local_value_1001, local_value_1701 / (1.0 - dropout_p), 0.0)
            if local_value_0227:
                local_value_1631.store(local_value_0095 + (local_value_0175 + local_value_1286) * N + local_value_0527, local_value_1001, mask=local_value_0527 < N)
        local_value_1699 += local_value_1701
    if HAS_RESIDUAL:
        local_value_1268 = local_value_1631.load(local_value_0210 + local_value_0527, mask=local_value_0527 < N, other=0.0).to(local_value_1631.float32)
        local_value_1699 += local_value_1268
    if local_value_0228:
        local_value_1631.store(local_value_0211 + local_value_0527, local_value_1699, mask=local_value_0527 < N)
    if not IS_RMS_NORM:
        local_value_1043 = local_value_1631.sum(local_value_1699, axis=0) / N
        local_value_1631.store(local_value_0185 + local_value_1286, local_value_1043)
        local_value_1730 = local_value_1631.where(local_value_0527 < N, local_value_1699 - local_value_1043, 0.0)
        local_value_1675 = local_value_1631.sum(local_value_1730 * local_value_1730, axis=0) / N
    else:
        local_value_1730 = local_value_1631.where(local_value_0527 < N, local_value_1699, 0.0)
        local_value_1675 = local_value_1631.sum(local_value_1730 * local_value_1730, axis=0) / N
    local_value_1294 = 1 / local_value_1631.sqrt(local_value_1675 + eps)
    local_value_1631.store(local_value_0214 + local_value_1286, local_value_1294)
    mask = local_value_0527 < N
    local_value_1683 = local_value_1631.load(W + local_value_0527, mask=mask).to(local_value_1631.float32)
    if local_value_0127:
        b = local_value_1631.load(B + local_value_0527, mask=mask).to(local_value_1631.float32)
    local_value_1712 = (local_value_1699 - local_value_1043) * local_value_1294 if not IS_RMS_NORM else local_value_1699 * local_value_1294
    y = local_value_1712 * local_value_1683 + b if local_value_0127 else local_value_1712 * local_value_1683
    local_value_1631.store(local_value_0267 + local_value_0527, y, mask=mask)
    if local_value_0142:
        local_value_1684 = local_value_1631.load(local_value_0253 + local_value_0527, mask=mask).to(local_value_1631.float32)
        if local_value_0126:
            local_value_0426 = local_value_1631.load(local_value_0015 + local_value_0527, mask=mask).to(local_value_1631.float32)
        local_value_1737 = local_value_1712 * local_value_1684 + local_value_0426 if local_value_0126 else local_value_1712 * local_value_1684
        local_value_1631.store(local_value_0268 + local_value_0527, local_value_1737, mask=mask)

def execute_step_0357(local_value_1699, weight, bias, eps, local_value_1268=None, local_value_1701=None, local_value_1689=None, local_value_0442=None, dropout_p=0.0, local_value_1291=None, local_value_1152=None, local_value_1269=None, local_value_0992=False, local_value_1275=False):
    if local_value_1268 is not None:
        local_value_1269 = local_value_1268.dtype
    local_value_0175, N = local_value_1699.shape
    assert local_value_1699.stride(-1) == 1
    if local_value_1268 is not None:
        assert local_value_1268.stride(-1) == 1
        assert local_value_1268.shape == (local_value_0175, N)
    assert weight.shape == (N,)
    assert weight.stride(-1) == 1
    if bias is not None:
        assert bias.stride(-1) == 1
        assert bias.shape == (N,)
    if local_value_1701 is not None:
        assert local_value_1701.shape == local_value_1699.shape
        assert local_value_1291 is None
        assert local_value_1701.stride(-1) == 1
    if local_value_1689 is not None:
        assert local_value_1689.shape == (N,)
        assert local_value_1689.stride(-1) == 1
    if local_value_0442 is not None:
        assert local_value_0442.shape == (N,)
        assert local_value_0442.stride(-1) == 1
    if local_value_1291 is not None:
        assert local_value_1291.is_contiguous()
        assert local_value_1291.shape == (local_value_0175,)
    y = local_value_1650.empty_like(local_value_1699, dtype=local_value_1699.dtype if local_value_1152 is None else local_value_1152)
    assert y.stride(-1) == 1
    if local_value_1689 is not None:
        local_value_1737 = local_value_1650.empty_like(y)
        assert local_value_1737.stride(-1) == 1
    else:
        local_value_1737 = None
    if local_value_1268 is not None or (local_value_1269 is not None and local_value_1269 != local_value_1699.dtype) or dropout_p > 0.0 or (local_value_1291 is not None) or (local_value_1701 is not None):
        local_value_1271 = local_value_1650.empty(local_value_0175, N, device=local_value_1699.device, dtype=local_value_1269 if local_value_1269 is not None else local_value_1699.dtype)
        assert local_value_1271.stride(-1) == 1
    else:
        local_value_1271 = None
    local_value_1043 = local_value_1650.empty((local_value_0175,), dtype=local_value_1650.float32, device=local_value_1699.device) if not local_value_0992 else None
    local_value_1294 = local_value_1650.empty((local_value_0175,), dtype=local_value_1650.float32, device=local_value_1699.device)
    if dropout_p > 0.0:
        local_value_1311 = local_value_1650.randint(2 ** 32, (local_value_0175 if local_value_1701 is None else 2 * local_value_0175,), device=local_value_1699.device, dtype=local_value_1650.int64)
    else:
        local_value_1311 = None
    if local_value_1275 and dropout_p > 0.0:
        local_value_0755 = local_value_1650.empty(local_value_0175 if local_value_1701 is None else 2 * local_value_0175, N, device=local_value_1699.device, dtype=local_value_1650.bool)
    else:
        local_value_0755 = None
    local_value_0176 = 65536 // local_value_1699.element_size()
    BLOCK_N = min(local_value_0176, local_value_1655.next_power_of_2(N))
    if N > BLOCK_N:
        raise RuntimeError("This layer norm doesn't support feature dim >= 64KB.")
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0358[local_value_0175,](local_value_1699, y, weight, bias, local_value_1268, local_value_1701, local_value_1689, local_value_0442, local_value_1737, local_value_1271, local_value_1291, local_value_1311, local_value_0755, local_value_1043, local_value_1294, local_value_1699.stride(0), y.stride(0), local_value_1268.stride(0) if local_value_1268 is not None else 0, local_value_1271.stride(0) if local_value_1271 is not None else 0, local_value_1701.stride(0) if local_value_1701 is not None else 0, local_value_1737.stride(0) if local_value_1737 is not None else 0, local_value_0175, N, eps, dropout_p, local_value_0992, BLOCK_N, local_value_1268 is not None, local_value_1271 is not None, bias is not None, dropout_p > 0.0, local_value_0755 is not None, local_value_1291 is not None)
    if local_value_0755 is not None and local_value_1701 is not None:
        local_value_0755, local_value_0756 = local_value_0755.tensor_split(2, dim=0)
    else:
        local_value_0756 = None
    return (y, local_value_1737, local_value_1043, local_value_1294, local_value_1271 if local_value_1271 is not None else local_value_1699, local_value_1311, local_value_0755, local_value_0756)

@local_value_1655.autotune(configs=[local_value_1655.Config({}, num_warps=1), local_value_1655.Config({}, num_warps=2), local_value_1655.Config({}, num_warps=4), local_value_1655.Config({}, num_warps=8), local_value_1655.Config({}, num_warps=16), local_value_1655.Config({}, num_warps=32)], key=['N', 'local_value_0133', 'local_value_0226', 'IS_RMS_NORM', 'local_value_0127', 'local_value_0134'])
@local_value_1655.heuristics({'local_value_0140': lambda local_value_0416: local_value_0416['local_value_0213'] is not None})
@local_value_1655.heuristics({'local_value_0137': lambda local_value_0416: local_value_0416['local_value_0104'] is not None})
@local_value_1655.heuristics({'local_value_0136': lambda local_value_0416: local_value_0416['local_value_0102'] is not None})
@local_value_1655.heuristics({'local_value_0126': lambda local_value_0416: local_value_0416['local_value_0086'] is not None})
@local_value_1655.heuristics({'RECOMPUTE_OUTPUT': lambda local_value_0416: local_value_0416['local_value_0267'] is not None})
@local_value_1655.jit
def execute_step_0356(local_value_0261, W, B, local_value_0267, local_value_0103, local_value_0101, local_value_0098, local_value_0085, local_value_0093, local_value_0253, local_value_0104, local_value_0102, local_value_0099, local_value_0086, local_value_0094, local_value_0213, local_value_0217, local_value_0185, local_value_0214, local_value_1603, local_value_1606, local_value_1550, local_value_1547, local_value_1523, local_value_1549, local_value_1543, local_value_1522, local_value_0175, N, eps, dropout_p, local_value_1290, IS_RMS_NORM: local_value_1631.constexpr, BLOCK_N: local_value_1631.constexpr, local_value_0133: local_value_1631.constexpr, local_value_0226: local_value_1631.constexpr, local_value_0127: local_value_1631.constexpr, local_value_0134: local_value_1631.constexpr, local_value_0140: local_value_1631.constexpr, local_value_0137: local_value_1631.constexpr, local_value_0136: local_value_1631.constexpr, local_value_0126: local_value_1631.constexpr, RECOMPUTE_OUTPUT: local_value_1631.constexpr):
    local_value_1287 = local_value_1631.program_id(0)
    local_value_1289 = local_value_1287 * local_value_1290
    local_value_0527 = local_value_1631.arange(0, BLOCK_N)
    mask = local_value_0527 < N
    local_value_0261 += local_value_1289 * local_value_1603
    if local_value_0133:
        local_value_0093 += local_value_1289 * local_value_1523
    if local_value_0226:
        local_value_0094 += local_value_1289 * local_value_1522
    local_value_0103 += local_value_1289 * local_value_1550
    local_value_0101 += local_value_1289 * local_value_1547
    if local_value_0137:
        local_value_0104 += local_value_1289 * local_value_1549
    if local_value_0136:
        local_value_0102 += local_value_1289 * local_value_1543
    if RECOMPUTE_OUTPUT:
        local_value_0267 += local_value_1289 * local_value_1606
    local_value_1683 = local_value_1631.load(W + local_value_0527, mask=mask).to(local_value_1631.float32)
    if RECOMPUTE_OUTPUT and local_value_0127:
        b = local_value_1631.load(B + local_value_0527, mask=mask, other=0.0).to(local_value_1631.float32)
    if local_value_0137:
        local_value_1684 = local_value_1631.load(local_value_0253 + local_value_0527, mask=mask).to(local_value_1631.float32)
    local_value_0803 = local_value_1631.zeros((BLOCK_N,), dtype=local_value_1631.float32)
    if local_value_0127:
        local_value_0641 = local_value_1631.zeros((BLOCK_N,), dtype=local_value_1631.float32)
    if local_value_0137:
        local_value_0804 = local_value_1631.zeros((BLOCK_N,), dtype=local_value_1631.float32)
        if local_value_0126:
            local_value_0642 = local_value_1631.zeros((BLOCK_N,), dtype=local_value_1631.float32)
    local_value_1288 = min((local_value_1287 + 1) * local_value_1290, local_value_0175)
    for local_value_1286 in range(local_value_1289, local_value_1288):
        local_value_1699 = local_value_1631.load(local_value_0261 + local_value_0527, mask=mask, other=0).to(local_value_1631.float32)
        local_value_0813 = local_value_1631.load(local_value_0103 + local_value_0527, mask=mask, other=0).to(local_value_1631.float32)
        if local_value_0137:
            local_value_0814 = local_value_1631.load(local_value_0104 + local_value_0527, mask=mask, other=0).to(local_value_1631.float32)
        if not IS_RMS_NORM:
            local_value_1043 = local_value_1631.load(local_value_0185 + local_value_1286)
        local_value_1294 = local_value_1631.load(local_value_0214 + local_value_1286)
        local_value_1732 = (local_value_1699 - local_value_1043) * local_value_1294 if not IS_RMS_NORM else local_value_1699 * local_value_1294
        local_value_1732 = local_value_1631.where(mask, local_value_1732, 0.0)
        if RECOMPUTE_OUTPUT:
            y = local_value_1732 * local_value_1683 + b if local_value_0127 else local_value_1732 * local_value_1683
            local_value_1631.store(local_value_0267 + local_value_0527, y, mask=mask)
        local_value_1687 = local_value_1683 * local_value_0813
        local_value_0803 += local_value_0813 * local_value_1732
        if local_value_0127:
            local_value_0641 += local_value_0813
        if local_value_0137:
            local_value_1687 += local_value_1684 * local_value_0814
            local_value_0804 += local_value_0814 * local_value_1732
            if local_value_0126:
                local_value_0642 += local_value_0814
        if not IS_RMS_NORM:
            local_value_0462 = local_value_1631.sum(local_value_1732 * local_value_1687, axis=0) / N
            local_value_0463 = local_value_1631.sum(local_value_1687, axis=0) / N
            local_value_0806 = (local_value_1687 - (local_value_1732 * local_value_0462 + local_value_0463)) * local_value_1294
        else:
            local_value_0462 = local_value_1631.sum(local_value_1732 * local_value_1687, axis=0) / N
            local_value_0806 = (local_value_1687 - local_value_1732 * local_value_0462) * local_value_1294
        if local_value_0133:
            local_value_0747 = local_value_1631.load(local_value_0093 + local_value_0527, mask=mask, other=0).to(local_value_1631.float32)
            local_value_0806 += local_value_0747
        if local_value_0226:
            local_value_1631.store(local_value_0094 + local_value_0527, local_value_0806, mask=mask)
        if local_value_0136:
            if local_value_0134:
                local_value_1001 = local_value_1631.rand(local_value_1631.load(local_value_0217 + local_value_0175 + local_value_1286).to(local_value_1631.uint32), local_value_0527, n_rounds=7) > dropout_p
                local_value_0807 = local_value_1631.where(local_value_1001, local_value_0806 / (1.0 - dropout_p), 0.0)
            else:
                local_value_0807 = local_value_0806
            local_value_1631.store(local_value_0102 + local_value_0527, local_value_0807, mask=mask)
        if local_value_0134:
            local_value_1001 = local_value_1631.rand(local_value_1631.load(local_value_0217 + local_value_1286).to(local_value_1631.uint32), local_value_0527, n_rounds=7) > dropout_p
            local_value_0806 = local_value_1631.where(local_value_1001, local_value_0806 / (1.0 - dropout_p), 0.0)
        if local_value_0140:
            local_value_1291 = local_value_1631.load(local_value_0213 + local_value_1286).to(local_value_1631.float32)
            local_value_0806 *= local_value_1291
        local_value_1631.store(local_value_0101 + local_value_0527, local_value_0806, mask=mask)
        local_value_0261 += local_value_1603
        if local_value_0133:
            local_value_0093 += local_value_1523
        if local_value_0226:
            local_value_0094 += local_value_1522
        if RECOMPUTE_OUTPUT:
            local_value_0267 += local_value_1606
        local_value_0103 += local_value_1550
        local_value_0101 += local_value_1547
        if local_value_0137:
            local_value_0104 += local_value_1549
        if local_value_0136:
            local_value_0102 += local_value_1543
    local_value_1631.store(local_value_0098 + local_value_1287 * N + local_value_0527, local_value_0803, mask=mask)
    if local_value_0127:
        local_value_1631.store(local_value_0085 + local_value_1287 * N + local_value_0527, local_value_0641, mask=mask)
    if local_value_0137:
        local_value_1631.store(local_value_0099 + local_value_1287 * N + local_value_0527, local_value_0804, mask=mask)
        if local_value_0126:
            local_value_1631.store(local_value_0086 + local_value_1287 * N + local_value_0527, local_value_0642, mask=mask)

def execute_step_0355(local_value_0813, local_value_1699, weight, bias, eps, local_value_1043, local_value_1294, local_value_0748=None, local_value_0814=None, local_value_1689=None, local_value_0442=None, local_value_1311=None, dropout_p=0.0, local_value_1291=None, local_value_0920=False, local_value_0921=False, local_value_0992=False, local_value_1709=None, local_value_1250=False):
    local_value_0175, N = local_value_1699.shape
    assert local_value_1699.stride(-1) == 1
    assert local_value_0813.stride(-1) == 1
    assert local_value_0813.shape == (local_value_0175, N)
    if local_value_0748 is not None:
        assert local_value_0748.stride(-1) == 1
        assert local_value_0748.shape == (local_value_0175, N)
    assert weight.shape == (N,)
    assert weight.stride(-1) == 1
    if bias is not None:
        assert bias.stride(-1) == 1
        assert bias.shape == (N,)
    if local_value_0814 is not None:
        assert local_value_1689 is not None
        assert local_value_0814.shape == local_value_0813.shape
        assert local_value_0814.stride(-1) == 1
    if local_value_1689 is not None:
        assert local_value_1689.shape == (N,)
        assert local_value_1689.stride(-1) == 1
    if local_value_0442 is not None:
        assert local_value_0442.shape == (N,)
        assert local_value_0442.stride(-1) == 1
    if local_value_1311 is not None:
        assert local_value_1311.is_contiguous()
        assert local_value_1311.shape == (local_value_0175 if not local_value_0921 else local_value_0175 * 2,)
    if local_value_1291 is not None:
        assert local_value_1291.is_contiguous()
        assert local_value_1291.shape == (local_value_0175,)
    local_value_0806 = local_value_1650.empty_like(local_value_1699) if local_value_1709 is None else local_value_1650.empty(local_value_0175, N, dtype=local_value_1709, device=local_value_1699.device)
    local_value_0749 = local_value_1650.empty_like(local_value_1699) if local_value_0920 and (local_value_0806.dtype != local_value_1699.dtype or dropout_p > 0.0 or local_value_1291 is not None or local_value_0921) else None
    local_value_0807 = local_value_1650.empty_like(local_value_0806) if local_value_0921 and dropout_p > 0.0 else None
    y = local_value_1650.empty(local_value_0175, N, dtype=local_value_0813.dtype, device=local_value_0813.device) if local_value_1250 else None
    if local_value_1250:
        assert local_value_1689 is None, 'recompute_output is not supported with parallel ComponentUnit0167'
    local_value_0176 = 65536 // local_value_1699.element_size()
    BLOCK_N = min(local_value_0176, local_value_1655.next_power_of_2(N))
    if N > BLOCK_N:
        raise RuntimeError("This layer norm doesn't support feature dim >= 64KB.")
    local_value_1355 = local_value_1650.cuda.get_device_properties(local_value_1699.device).multi_processor_count
    local_value_0336 = local_value_1650.empty((local_value_1355, N), dtype=local_value_1650.float32, device=weight.device)
    local_value_0333 = local_value_1650.empty((local_value_1355, N), dtype=local_value_1650.float32, device=bias.device) if bias is not None else None
    local_value_0337 = local_value_1650.empty_like(local_value_0336) if local_value_1689 is not None else None
    local_value_0334 = local_value_1650.empty_like(local_value_0333) if local_value_0442 is not None else None
    local_value_1290 = local_value_1039.ceil(local_value_0175 / local_value_1355)
    local_value_0899 = (local_value_1355,)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0356[local_value_0899](local_value_1699, weight, bias, y, local_value_0813, local_value_0806, local_value_0336, local_value_0333, local_value_0748, local_value_1689, local_value_0814, local_value_0807, local_value_0337, local_value_0334, local_value_0749, local_value_1291, local_value_1311, local_value_1043, local_value_1294, local_value_1699.stride(0), 0 if not local_value_1250 else y.stride(0), local_value_0813.stride(0), local_value_0806.stride(0), local_value_0748.stride(0) if local_value_0748 is not None else 0, local_value_0814.stride(0) if local_value_0814 is not None else 0, local_value_0807.stride(0) if local_value_0807 is not None else 0, local_value_0749.stride(0) if local_value_0749 is not None else 0, local_value_0175, N, eps, dropout_p, local_value_1290, local_value_0992, BLOCK_N, local_value_0748 is not None, local_value_0749 is not None, bias is not None, dropout_p > 0.0)
    local_value_0803 = local_value_0336.sum(0).to(weight.dtype)
    local_value_0641 = local_value_0333.sum(0).to(bias.dtype) if bias is not None else None
    local_value_0804 = local_value_0337.sum(0).to(local_value_1689.dtype) if local_value_1689 is not None else None
    local_value_0642 = local_value_0334.sum(0).to(local_value_0442.dtype) if local_value_0442 is not None else None
    if local_value_0920 and local_value_0806.dtype == local_value_1699.dtype and (dropout_p == 0.0) and (local_value_1291 is None):
        local_value_0749 = local_value_0806
    if local_value_0921 and dropout_p == 0.0:
        local_value_0807 = local_value_0806
    return (local_value_0806, local_value_0803, local_value_0641, local_value_0749, local_value_0807, local_value_0804, local_value_0642) if not local_value_1250 else (local_value_0806, local_value_0803, local_value_0641, local_value_0749, local_value_0807, local_value_0804, local_value_0642, y)

class ComponentUnit0170(local_value_1650.autograd.Function):

    @staticmethod
    def forward(local_value_0551, local_value_1699, weight, bias, local_value_1268=None, local_value_1701=None, local_value_1689=None, local_value_0442=None, eps=1e-06, dropout_p=0.0, local_value_1291=None, local_value_1223=False, local_value_1270=False, local_value_0992=False, local_value_1275=False):
        local_value_1727 = local_value_1699.shape
        local_value_1699 = local_value_1699.reshape(-1, local_value_1699.shape[-1])
        if local_value_1699.stride(-1) != 1:
            local_value_1699 = local_value_1699.contiguous()
        if local_value_1268 is not None:
            assert local_value_1268.shape == local_value_1727
            local_value_1268 = local_value_1268.reshape(-1, local_value_1268.shape[-1])
            if local_value_1268.stride(-1) != 1:
                local_value_1268 = local_value_1268.contiguous()
        if local_value_1701 is not None:
            assert local_value_1701.shape == local_value_1727
            assert local_value_1291 is None, 'rowscale is not supported with parallel ComponentUnit0167'
            local_value_1701 = local_value_1701.reshape(-1, local_value_1701.shape[-1])
            if local_value_1701.stride(-1) != 1:
                local_value_1701 = local_value_1701.contiguous()
        weight = weight.contiguous()
        if bias is not None:
            bias = bias.contiguous()
        if local_value_1689 is not None:
            local_value_1689 = local_value_1689.contiguous()
        if local_value_0442 is not None:
            local_value_0442 = local_value_0442.contiguous()
        if local_value_1291 is not None:
            local_value_1291 = local_value_1291.reshape(-1).contiguous()
        local_value_1269 = local_value_1268.dtype if local_value_1268 is not None else local_value_1650.float32 if local_value_1270 else None
        y, local_value_1737, local_value_1043, local_value_1294, local_value_1271, local_value_1311, local_value_0755, local_value_0756 = execute_step_0357(local_value_1699, weight, bias, eps, local_value_1268, local_value_1701, local_value_1689, local_value_0442, dropout_p=dropout_p, local_value_1291=local_value_1291, local_value_1269=local_value_1269, local_value_0992=local_value_0992, local_value_1275=local_value_1275)
        local_value_0551.save_for_backward(local_value_1271, weight, bias, local_value_1689, local_value_0442, local_value_1291, local_value_1311, local_value_1043, local_value_1294)
        local_value_0551.local_value_1727 = local_value_1727
        local_value_0551.eps = eps
        local_value_0551.dropout_p = dropout_p
        local_value_0551.local_value_0992 = local_value_0992
        local_value_0551.local_value_0920 = local_value_1268 is not None
        local_value_0551.local_value_0921 = local_value_1701 is not None
        local_value_0551.local_value_1223 = local_value_1223
        local_value_0551.local_value_1709 = local_value_1699.dtype
        y = y.reshape(local_value_1727)
        local_value_1737 = local_value_1737.reshape(local_value_1727) if local_value_1737 is not None else None
        local_value_1271 = local_value_1271.reshape(local_value_1727) if local_value_1271 is not None else None
        local_value_0755 = local_value_0755.reshape(local_value_1727) if local_value_0755 is not None else None
        local_value_0756 = local_value_0756.reshape(local_value_1727) if local_value_0756 is not None else None
        if not local_value_1275:
            if local_value_1689 is None:
                return y if not local_value_1223 else (y, local_value_1271)
            else:
                return (y, local_value_1737) if not local_value_1223 else (y, local_value_1737, local_value_1271)
        elif local_value_1689 is None:
            return (y, local_value_0755, local_value_0756) if not local_value_1223 else (y, local_value_1271, local_value_0755, local_value_0756)
        else:
            return (y, local_value_1737, local_value_0755, local_value_0756) if not local_value_1223 else (y, local_value_1737, local_value_1271, local_value_0755, local_value_0756)

    @staticmethod
    def backward(local_value_0551, local_value_0813, *local_value_0416):
        local_value_1699, weight, bias, local_value_1689, local_value_0442, local_value_1291, local_value_1311, local_value_1043, local_value_1294 = local_value_0551.saved_tensors
        local_value_0813 = local_value_0813.reshape(-1, local_value_0813.shape[-1])
        if local_value_0813.stride(-1) != 1:
            local_value_0813 = local_value_0813.contiguous()
        assert local_value_0813.shape == local_value_1699.shape
        if local_value_1689 is not None:
            local_value_0814, local_value_0416 = (local_value_0416[0], local_value_0416[1:])
            local_value_0814 = local_value_0814.reshape(-1, local_value_0814.shape[-1])
            if local_value_0814.stride(-1) != 1:
                local_value_0814 = local_value_0814.contiguous()
            assert local_value_0814.shape == local_value_1699.shape
        else:
            local_value_0814 = None
        if local_value_0551.local_value_1223:
            local_value_0748 = local_value_0416[0]
            local_value_0748 = local_value_0748.reshape(-1, local_value_0748.shape[-1])
            if local_value_0748.stride(-1) != 1:
                local_value_0748 = local_value_0748.contiguous()
            assert local_value_0748.shape == local_value_1699.shape
        else:
            local_value_0748 = None
        local_value_0806, local_value_0803, local_value_0641, local_value_0749, local_value_0807, local_value_0804, local_value_0642 = execute_step_0355(local_value_0813, local_value_1699, weight, bias, local_value_0551.eps, local_value_1043, local_value_1294, local_value_0748, local_value_0814, local_value_1689, local_value_0442, local_value_1311, local_value_0551.dropout_p, local_value_1291, local_value_0551.local_value_0920, local_value_0551.local_value_0921, local_value_0551.local_value_0992, local_value_1709=local_value_0551.local_value_1709)
        return (local_value_0806.reshape(local_value_0551.local_value_1727), local_value_0803, local_value_0641, local_value_0749.reshape(local_value_0551.local_value_1727) if local_value_0551.local_value_0920 else None, local_value_0807.reshape(local_value_0551.local_value_1727) if local_value_0807 is not None else None, local_value_0804, local_value_0642, None, None, None, None, None, None, None)

def execute_step_1015(local_value_1699, weight, bias, local_value_1268=None, local_value_1701=None, local_value_1689=None, local_value_0442=None, eps=1e-06, dropout_p=0.0, local_value_1291=None, local_value_1223=False, local_value_1270=False, local_value_0992=False, local_value_1275=False):
    return ComponentUnit0170.apply(local_value_1699, weight, bias, local_value_1268, local_value_1701, local_value_1689, local_value_0442, eps, dropout_p, local_value_1291, local_value_1223, local_value_1270, local_value_0992, local_value_1275)

def execute_step_1281(local_value_1699, weight, bias, local_value_1268=None, local_value_1701=None, local_value_1689=None, local_value_0442=None, eps=1e-06, dropout_p=0.0, local_value_1291=None, local_value_1223=False, local_value_1270=False, local_value_1275=False):
    return ComponentUnit0170.apply(local_value_1699, weight, bias, local_value_1268, local_value_1701, local_value_1689, local_value_0442, eps, dropout_p, local_value_1291, local_value_1223, local_value_1270, True, local_value_1275)

class ComponentUnit0212(local_value_1650.nn.Module):

    def __init__(local_value_1336, local_value_0930, eps=1e-05, dropout_p=0.0, device=None, dtype=None):
        local_value_0835 = {'device': device, 'dtype': dtype}
        super().__init__()
        local_value_1336.eps = eps
        if dropout_p > 0.0:
            local_value_1336.drop = local_value_1650.nn.Dropout(dropout_p)
        else:
            local_value_1336.drop = None
        local_value_1336.weight = local_value_1650.nn.Parameter(local_value_1650.empty(local_value_0930, **local_value_0835))
        local_value_1336.member_slot_0400('bias', None)
        local_value_1336.reset_parameters()

    def reset_parameters(local_value_1336):
        local_value_1650.nn.init.ones_(local_value_1336.weight)

    def forward(local_value_1336, local_value_1699, local_value_1268=None, local_value_1223=False, local_value_1270=False):
        return execute_step_1281(local_value_1699, local_value_1336.weight, local_value_1336.bias, local_value_1268=local_value_1268, eps=local_value_1336.eps, dropout_p=local_value_1336.drop.p if local_value_1336.drop is not None and local_value_1336.training else 0.0, local_value_1223=local_value_1223, local_value_1270=local_value_1270)

class ComponentUnit0171(local_value_1650.autograd.Function):

    @staticmethod
    @local_value_0559
    def forward(local_value_0551, local_value_1699, local_value_1102, local_value_1100, local_value_1021, local_value_1020, local_value_1268=None, eps=1e-06, local_value_1223=False, local_value_1270=False, local_value_0992=False):
        local_value_1727 = local_value_1699.shape
        local_value_1699 = local_value_1699.reshape(-1, local_value_1699.shape[-1])
        if local_value_1699.stride(-1) != 1:
            local_value_1699 = local_value_1699.contiguous()
        if local_value_1268 is not None:
            assert local_value_1268.shape == local_value_1727
            local_value_1268 = local_value_1268.reshape(-1, local_value_1268.shape[-1])
            if local_value_1268.stride(-1) != 1:
                local_value_1268 = local_value_1268.contiguous()
        local_value_1102 = local_value_1102.contiguous()
        if local_value_1100 is not None:
            local_value_1100 = local_value_1100.contiguous()
        local_value_1269 = local_value_1268.dtype if local_value_1268 is not None else local_value_1650.float32 if local_value_1270 else None
        y, local_value_0272, local_value_1043, local_value_1294, local_value_1271, *local_value_1273 = execute_step_0357(local_value_1699, local_value_1102, local_value_1100, eps, local_value_1268, local_value_1152=None if not local_value_1650.is_autocast_enabled() else local_value_1650.get_autocast_gpu_dtype(), local_value_1269=local_value_1269, local_value_0992=local_value_0992)
        y = y.reshape(local_value_1727)
        dtype = local_value_1650.get_autocast_gpu_dtype() if local_value_1650.is_autocast_enabled() else y.dtype
        local_value_1021 = local_value_1021.to(dtype)
        local_value_1020 = local_value_1020.to(dtype) if local_value_1020 is not None else None
        out = local_value_0117.linear(y.to(local_value_1021.dtype), local_value_1021, local_value_1020)
        local_value_0551.save_for_backward(local_value_1271, local_value_1102, local_value_1100, local_value_1021, local_value_1043, local_value_1294)
        local_value_0551.local_value_1727 = local_value_1727
        local_value_0551.eps = eps
        local_value_0551.local_value_0992 = local_value_0992
        local_value_0551.local_value_0920 = local_value_1268 is not None
        local_value_0551.local_value_1223 = local_value_1223
        local_value_0551.local_value_1709 = local_value_1699.dtype
        local_value_0551.member_slot_0334 = local_value_1020 is None
        return out if not local_value_1223 else (out, local_value_1271.reshape(local_value_1727))

    @staticmethod
    @local_value_0558
    def backward(local_value_0551, local_value_0723, *local_value_0416):
        local_value_1699, local_value_1102, local_value_1100, local_value_1021, local_value_1043, local_value_1294 = local_value_0551.saved_tensors
        local_value_0723 = local_value_0723.reshape(-1, local_value_0723.shape[-1])
        local_value_0813 = local_value_0117.linear(local_value_0723, local_value_1021.t())
        local_value_0718 = None if local_value_0551.member_slot_0334 else local_value_0723.sum(0)
        if local_value_0813.stride(-1) != 1:
            local_value_0813 = local_value_0813.contiguous()
        assert local_value_0813.shape == local_value_1699.shape
        if local_value_0551.local_value_1223:
            local_value_0748 = local_value_0416[0]
            local_value_0748 = local_value_0748.reshape(-1, local_value_0748.shape[-1])
            if local_value_0748.stride(-1) != 1:
                local_value_0748 = local_value_0748.contiguous()
            assert local_value_0748.shape == local_value_1699.shape
        else:
            local_value_0748 = None
        local_value_0806, local_value_0721, local_value_0720, local_value_0749, local_value_0272, local_value_0272, local_value_0272, y = execute_step_0355(local_value_0813, local_value_1699, local_value_1102, local_value_1100, local_value_0551.eps, local_value_1043, local_value_1294, local_value_0748=local_value_0748, local_value_0920=local_value_0551.local_value_0920, local_value_0992=local_value_0551.local_value_0992, local_value_1709=local_value_0551.local_value_1709, local_value_1250=True)
        local_value_0719 = local_value_1650.einsum('bo,bi->oi', local_value_0723, y)
        return (local_value_0806.reshape(local_value_0551.local_value_1727), local_value_0721, local_value_0720, local_value_0719, local_value_0718, local_value_0749.reshape(local_value_0551.local_value_1727) if local_value_0551.local_value_0920 else None, None, None, None, None)

def execute_step_1016(local_value_1699, local_value_1102, local_value_1100, local_value_1021, local_value_1020, local_value_1268=None, eps=1e-06, local_value_1223=False, local_value_1270=False, local_value_0992=False):
    return ComponentUnit0171.apply(local_value_1699, local_value_1102, local_value_1100, local_value_1021, local_value_1020, local_value_1268, eps, local_value_1223, local_value_1270, local_value_0992)
