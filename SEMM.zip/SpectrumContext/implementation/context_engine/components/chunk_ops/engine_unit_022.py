import math as local_value_1039
import torch as local_value_1650
import torch.nn.functional as local_value_0117
import triton as local_value_1655
import triton.language as local_value_1631
from einops import rearrange as local_value_1249, repeat

def execute_step_0965(local_value_1075):
    return lambda local_value_1076: [local_value_1076[name].zero_() for name in local_value_1075 if local_value_1076[name] is not None]

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 64}, num_stages=3, num_warps=8), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=2), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=2), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=2)], key=['local_value_0513', 'local_value_0156', 'local_value_0153'])
@local_value_1655.jit
def execute_step_0294(local_value_0403, local_value_0427, local_value_1162, local_value_1346, local_value_1348, local_value_0513, local_value_0156, local_value_1089, local_value_1425, local_value_1427, local_value_1426, local_value_1428, local_value_1429, local_value_1432, local_value_1431, local_value_1433, local_value_1562, local_value_1563, local_value_1566, local_value_1569, local_value_1570, local_value_1586, local_value_1587, local_value_0153: local_value_1631.constexpr, local_value_0722: local_value_1631.constexpr, HAS_SEQ_IDX: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr):
    local_value_1204 = local_value_1631.program_id(axis=1)
    local_value_1207 = local_value_1631.program_id(axis=2)
    local_value_1206 = local_value_1207 // local_value_1089
    local_value_1209 = local_value_1207 - local_value_1206 * local_value_1089
    local_value_1111 = local_value_1631.cdiv(local_value_0513, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    if local_value_0153:
        if local_value_1211 * BLOCK_SIZE_N >= (local_value_1210 + 1) * BLOCK_SIZE_M:
            return
    local_value_0403 += local_value_1204 * local_value_1425 + local_value_1206 * local_value_0513 * local_value_1427 + local_value_1209 * local_value_1426
    local_value_0427 += local_value_1204 * local_value_1429 + local_value_1206 * local_value_0513 * local_value_1432 + local_value_1209 * local_value_1431
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586 + local_value_1206 * local_value_0513 * local_value_1587
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_0404 = local_value_0403 + (local_value_1123[:, None] * local_value_1427 + local_value_1121[None, :] * local_value_1428)
    local_value_0428 = local_value_0427 + (local_value_1121[:, None] * local_value_1433 + local_value_1124[None, :] * local_value_1432)
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
    for k in range(0, local_value_1631.cdiv(local_value_0156, BLOCK_SIZE_K)):
        a = local_value_1631.load(local_value_0404, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1121[None, :] < local_value_0156 - k * BLOCK_SIZE_K), other=0.0).to(local_value_0722)
        b = local_value_1631.load(local_value_0428, mask=(local_value_1121[:, None] < local_value_0156 - k * BLOCK_SIZE_K) & (local_value_1124[None, :] < local_value_0514), other=0.0).to(local_value_0722)
        local_value_0409 += local_value_1631.dot(a, b)
        local_value_0404 += BLOCK_SIZE_K * local_value_1428
        local_value_0428 += BLOCK_SIZE_K * local_value_1433
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    if HAS_SEQ_IDX:
        local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
        local_value_1342 = local_value_1631.load(local_value_1346 + local_value_1123 * local_value_1587, mask=local_value_1123 < local_value_0514, other=-1)
        local_value_1343 = local_value_1631.load(local_value_1346 + local_value_1124 * local_value_1587, mask=local_value_1124 < local_value_0514, other=-2)
        local_value_0409 = local_value_1631.where(local_value_1342[:, None] == local_value_1343[None, :], local_value_0409, 0.0)
    out = local_value_0409.to(local_value_1162.dtype.element_ty)
    local_value_1162 += local_value_1204 * local_value_1562 + local_value_1206 * local_value_1563 + local_value_1209 * local_value_1566
    local_value_1163 = local_value_1162 + (local_value_1569 * local_value_1123[:, None] + local_value_1124[None, :] * local_value_1570)
    local_value_1631.store(local_value_1163, out, mask=(local_value_1123[:, None] < local_value_0513) & (local_value_1124[None, :] < local_value_0513))

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 256, 'local_value_0022': 64}, num_stages=3, num_warps=8), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 256, 'local_value_0022': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 128, 'local_value_0022': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64, 'local_value_0022': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128, 'local_value_0022': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32, 'local_value_0022': 32}, num_stages=4, num_warps=4), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32, 'local_value_0022': 32}, num_stages=5, num_warps=2), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64, 'local_value_0022': 32}, num_stages=5, num_warps=2), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64, 'local_value_0022': 32}, num_stages=4, num_warps=2)], key=['local_value_0513', 'local_value_0156'])
@local_value_1655.jit
def execute_step_0292(local_value_0403, local_value_0726, local_value_0643, local_value_1265, local_value_1348, local_value_0513, local_value_0156, local_value_1089, local_value_1425, local_value_1427, local_value_1426, local_value_1428, local_value_1504, local_value_1505, local_value_1510, local_value_1506, local_value_1507, local_value_1454, local_value_1460, local_value_1457, local_value_1458, local_value_1580, local_value_1585, local_value_1581, local_value_1582, local_value_0722: local_value_1631.constexpr, HAS_RESIDUAL: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, local_value_0022: local_value_1631.constexpr):
    local_value_1204 = local_value_1631.program_id(axis=1)
    local_value_1207 = local_value_1631.program_id(axis=2)
    local_value_1206 = local_value_1207 // local_value_1089
    local_value_1209 = local_value_1207 - local_value_1206 * local_value_1089
    local_value_1111 = local_value_1631.cdiv(local_value_0156, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_0403 += local_value_1204 * local_value_1425 + local_value_1206 * local_value_0513 * local_value_1427 + local_value_1209 * local_value_1426
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1206 * local_value_1505 + local_value_1209 * local_value_1510
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_1118 = local_value_1631.arange(0, local_value_0022)
    local_value_0727 = local_value_0726 + (local_value_1123[:, None] * local_value_1507 + local_value_1118[None, :] * local_value_1506)
    local_value_0404 = local_value_0403 + (local_value_1118[:, None] * local_value_1427 + local_value_1124[None, :] * local_value_1428)
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
    for local_value_0548 in range(0, local_value_1631.cdiv(local_value_0514, local_value_0022)):
        local_value_0723 = local_value_1631.load(local_value_0727, mask=(local_value_1123[:, None] < local_value_0513) & (local_value_1118[None, :] < local_value_0514 - local_value_0548 * local_value_0022), other=0.0).to(local_value_0722)
        a = local_value_1631.load(local_value_0404, mask=(local_value_1118[:, None] < local_value_0514 - local_value_0548 * local_value_0022) & (local_value_1124[None, :] < local_value_0156), other=0.0).to(local_value_0722)
        local_value_0409 += local_value_1631.dot(local_value_0723, a)
        local_value_0727 += local_value_0022 * local_value_1506
        local_value_0404 += local_value_0022 * local_value_1427
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    if HAS_RESIDUAL:
        local_value_1265 += local_value_1204 * local_value_1580 + local_value_1206 * local_value_0513 * local_value_1585 + local_value_1209 * local_value_1581
        local_value_1266 = local_value_1265 + (local_value_1123[:, None] * local_value_1585 + local_value_1124[None, :] * local_value_1582)
        local_value_1258 = local_value_1631.load(local_value_1266, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0156)).to(local_value_1631.float32)
        local_value_0409 += local_value_1258
    local_value_0641 = local_value_0409.to(local_value_0643.dtype.element_ty)
    local_value_0643 += local_value_1204 * local_value_1454 + local_value_1206 * local_value_0513 * local_value_1460 + local_value_1209 * local_value_1457
    local_value_0644 = local_value_0643 + (local_value_1123[:, None] * local_value_1460 + local_value_1124[None, :] * local_value_1458)
    local_value_1631.store(local_value_0644, local_value_0641, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0156))

def execute_step_0293(a, b, local_value_0513, local_value_1339=None, local_value_0479=False, local_value_1175=None):
    local_value_0917 = a.dim() == 4
    if not local_value_0917:
        local_value_0434, local_value_1348, k = a.shape
    else:
        local_value_0434, local_value_1348, local_value_1089, k = a.shape
    assert b.shape == a.shape
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    if a.stride(-1) != 1 and a.stride(1) != 1:
        a = a.contiguous()
    if b.stride(-1) != 1 and b.stride(1) != 1:
        b = b.contiguous()
    local_value_1078 = local_value_1039.ceil(local_value_1348 / local_value_0513)
    local_value_1152 = a.dtype if local_value_1175 is None else local_value_1175
    out = local_value_1650.empty((local_value_0434, local_value_1078, local_value_0513, local_value_0513) if not local_value_0917 else (local_value_0434, local_value_1078, local_value_1089, local_value_0513, local_value_0513), device=a.device, dtype=local_value_1152)
    local_value_0722 = local_value_1631.bfloat16 if a.dtype == local_value_1650.bfloat16 or b.dtype == local_value_1650.bfloat16 else local_value_1631.float16 if a.dtype == local_value_1650.float16 or b.dtype == local_value_1650.float16 else local_value_1631.float32
    local_value_0899 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_N']), local_value_0434, local_value_1078 if not local_value_0917 else local_value_1078 * local_value_1089)
    with local_value_1650.cuda.device(a.device.index):
        execute_step_0294[local_value_0899](a, b, out, local_value_1339, int(local_value_1348), int(local_value_0513), int(k), int(local_value_1089 if local_value_0917 else 1), a.stride(0), a.stride(1), 0 if not local_value_0917 else a.stride(2), a.stride(-1), b.stride(0), b.stride(1), 0 if not local_value_0917 else b.stride(2), b.stride(-1), out.stride(0), out.stride(1), 0 if not local_value_0917 else out.stride(2), out.stride(-2), out.stride(-1), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), local_value_0479, local_value_0722, HAS_SEQ_IDX=local_value_1339 is not None)
    return out

def execute_step_0291(a, local_value_0723, local_value_1268=None, out=None):
    local_value_0917 = a.dim() == 4
    if not local_value_0917:
        local_value_0434, local_value_1348, k = a.shape
    else:
        local_value_0434, local_value_1348, local_value_1089, k = a.shape
    local_value_1078, local_value_0513 = (local_value_0723.shape[1], local_value_0723.shape[-1])
    if a.stride(-1) != 1 and a.stride(-2) != 1:
        a = a.contiguous()
    if local_value_0723.stride(-1) != 1 and local_value_0723.stride(-2) != 1:
        local_value_0723 = local_value_0723.contiguous()
    if local_value_1268 is not None:
        assert local_value_1268.shape == (local_value_0434, local_value_1348, k) if not local_value_0917 else (local_value_0434, local_value_1348, local_value_1089, k)
        if local_value_1268.stride(-1) != 1 and local_value_1268.stride(1) != 1:
            local_value_1268 = local_value_1268.contiguous()
    if out is not None:
        assert out.shape == a.shape
        assert out.stride(-1) == 1 or out.stride(1) == 1
    else:
        out = local_value_1650.empty_like(a)
    local_value_0722 = local_value_1631.bfloat16 if a.dtype == local_value_1650.bfloat16 or local_value_0723.dtype == local_value_1650.bfloat16 else local_value_1631.float16 if a.dtype == local_value_1650.float16 or local_value_0723.dtype == local_value_1650.float16 else local_value_1631.float32
    local_value_0899 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(k, local_value_0177['BLOCK_SIZE_N']), local_value_0434, local_value_1078 if not local_value_0917 else local_value_1078 * local_value_1089)
    local_value_1272 = (local_value_1268.stride(0), local_value_1268.stride(1), 0 if not local_value_0917 else local_value_1268.stride(2), local_value_1268.stride(-1)) if local_value_1268 is not None else (0, 0, 0, 0)
    with local_value_1650.cuda.device(a.device.index):
        execute_step_0292[local_value_0899](a, local_value_0723, out, local_value_1268, int(local_value_1348), int(local_value_0513), int(k), int(local_value_1089 if local_value_0917 else 1), a.stride(0), a.stride(1), 0 if not local_value_0917 else a.stride(2), a.stride(-1), local_value_0723.stride(0), local_value_0723.stride(1), 0 if not local_value_0917 else local_value_0723.stride(2), local_value_0723.stride(-2), local_value_0723.stride(-1), out.stride(0), out.stride(1), 0 if not local_value_0917 else out.stride(2), out.stride(-1), local_value_1272[0], local_value_1272[1], local_value_1272[2], local_value_1272[3], local_value_0722, HAS_RESIDUAL=local_value_1268 is not None)
    return out
