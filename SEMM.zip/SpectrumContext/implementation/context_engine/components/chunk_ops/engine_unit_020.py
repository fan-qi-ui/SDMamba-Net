import math as local_value_1039
import torch as local_value_1650
import torch.nn.functional as local_value_0117
import triton as local_value_1655
import triton.language as local_value_1631
from einops import rearrange as local_value_1249, repeat

@local_value_1655.heuristics({'HAS_DT_BIAS': lambda local_value_0416: local_value_0416['local_value_0768'] is not None})
@local_value_1655.heuristics({'local_value_0128': lambda local_value_0416: local_value_0416['local_value_0108'] is not None})
@local_value_1655.heuristics({'HAS_Z': lambda local_value_0416: local_value_0416['local_value_1754'] is not None})
@local_value_1655.heuristics({'BLOCK_SIZE_DSTATE': lambda local_value_0416: local_value_1655.next_power_of_2(local_value_0416['local_value_0759'])})
@local_value_1655.jit
def execute_step_0384(local_value_1397, local_value_1720, local_value_0789, local_value_0768, local_value_0005, local_value_0033, local_value_0056, local_value_0108, local_value_1754, local_value_1162, local_value_0434, local_value_1090, dim, local_value_0759, local_value_1092, local_value_1588, local_value_1591, local_value_1589, local_value_1590, local_value_1599, local_value_1602, local_value_1600, local_value_1530, local_value_1536, local_value_1535, local_value_1532, local_value_1531, local_value_1412, local_value_1410, local_value_1411, local_value_1413, local_value_1415, local_value_1414, local_value_1418, local_value_1420, local_value_1419, local_value_1424, local_value_1423, local_value_1607, local_value_1610, local_value_1608, local_value_1562, local_value_1566, local_value_1564, local_value_0097: local_value_1631.constexpr, local_value_0239: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, HAS_DT_BIAS: local_value_1631.constexpr, local_value_0128: local_value_1631.constexpr, HAS_Z: local_value_1631.constexpr, BLOCK_SIZE_DSTATE: local_value_1631.constexpr):
    local_value_1210 = local_value_1631.program_id(axis=0)
    local_value_1204 = local_value_1631.program_id(axis=1)
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1397 += local_value_1204 * local_value_1588 + local_value_1209 * local_value_1591
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1209 * local_value_1602
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1209 * local_value_1536
    if HAS_DT_BIAS:
        local_value_0768 += local_value_1209 * local_value_1532
    local_value_0005 += local_value_1209 * local_value_1412
    local_value_0033 += local_value_1204 * local_value_1413 + local_value_1209 // local_value_1092 * local_value_1415
    local_value_0056 += local_value_1204 * local_value_1418 + local_value_1209 // local_value_1092 * local_value_1420
    if HAS_Z:
        local_value_1754 += local_value_1204 * local_value_1607 + local_value_1209 * local_value_1610
    local_value_1162 += local_value_1204 * local_value_1562 + local_value_1209 * local_value_1566
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1631.arange(0, BLOCK_SIZE_DSTATE)
    local_value_1398 = local_value_1397 + (local_value_1123[:, None] * local_value_1589 + local_value_1124[None, :] * local_value_1590)
    local_value_1722 = local_value_1720 + local_value_1123 * local_value_1600
    local_value_0790 = local_value_0789 + local_value_1123 * local_value_1535
    if HAS_DT_BIAS:
        local_value_0769 = local_value_0768 + local_value_1123 * local_value_1531
    if local_value_0128:
        local_value_0108 += local_value_1209 * local_value_1424
    local_value_0006 = local_value_0005 + (local_value_1123[:, None] * local_value_1410 + local_value_1124[None, :] * local_value_1411)
    local_value_0034 = local_value_0033 + local_value_1124 * local_value_1414
    local_value_0057 = local_value_0056 + local_value_1124 * local_value_1419
    if local_value_0128:
        local_value_0109 = local_value_0108 + local_value_1123 * local_value_1423
    if HAS_Z:
        local_value_1755 = local_value_1754 + local_value_1123 * local_value_1608
    local_value_1163 = local_value_1162 + local_value_1123 * local_value_1564
    local_value_1391 = local_value_1631.load(local_value_1398, mask=(local_value_1123[:, None] < dim) & (local_value_1124[None, :] < local_value_0759), other=0.0)
    local_value_1699 = local_value_1631.load(local_value_1722, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
    if not local_value_0239:
        local_value_0764 = local_value_1631.load(local_value_0790, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
        if HAS_DT_BIAS:
            local_value_0764 += local_value_1631.load(local_value_0769, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
        if local_value_0097:
            local_value_0764 = local_value_1631.where(local_value_0764 <= 20.0, local_value_1631.math.log1p(local_value_1631.exp(local_value_0764)), local_value_0764)
        local_value_0000 = local_value_1631.load(local_value_0006, mask=(local_value_1123[:, None] < dim) & (local_value_1124[None, :] < local_value_0759), other=0.0).to(local_value_1631.float32)
        local_value_0564 = local_value_1631.exp(local_value_0000 * local_value_0764[:, None])
    else:
        local_value_0764 = local_value_1631.load(local_value_0789).to(local_value_1631.float32)
        if HAS_DT_BIAS:
            local_value_0764 += local_value_1631.load(local_value_0768).to(local_value_1631.float32)
        if local_value_0097:
            local_value_0764 = local_value_1631.where(local_value_0764 <= 20.0, local_value_1631.math.log1p(local_value_1631.exp(local_value_0764)), local_value_0764)
        local_value_0000 = local_value_1631.load(local_value_0005).to(local_value_1631.float32)
        local_value_0564 = local_value_1631.exp(local_value_0000 * local_value_0764)
    B = local_value_1631.load(local_value_0034, mask=local_value_1124 < local_value_0759, other=0.0).to(local_value_1631.float32)
    local_value_0044 = local_value_1631.load(local_value_0057, mask=local_value_1124 < local_value_0759, other=0.0).to(local_value_1631.float32)
    if local_value_0128:
        D = local_value_1631.load(local_value_0109, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
    if HAS_Z:
        local_value_1753 = local_value_1631.load(local_value_1755, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
    if not local_value_0239:
        local_value_0582 = B[None, :] * local_value_0764[:, None]
    else:
        local_value_0582 = B * local_value_0764
    local_value_1391 = local_value_1391 * local_value_0564 + local_value_0582 * local_value_1699[:, None]
    local_value_1631.store(local_value_1398, local_value_1391, mask=(local_value_1123[:, None] < dim) & (local_value_1124[None, :] < local_value_0759))
    out = local_value_1631.sum(local_value_1391 * local_value_0044[None, :], axis=1)
    if local_value_0128:
        out += local_value_1699 * D
    if HAS_Z:
        out *= local_value_1753 * local_value_1631.sigmoid(local_value_1753)
    local_value_1631.store(local_value_1163, out, mask=local_value_1123 < dim)

def execute_step_1334(local_value_1391, local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, local_value_0767=None, local_value_0794=False):
    local_value_0918 = local_value_1391.dim() > 3
    if local_value_1391.dim() == 3:
        local_value_1391 = local_value_1391.unsqueeze(1)
    if local_value_1699.dim() == 2:
        local_value_1699 = local_value_1699.unsqueeze(1)
    if local_value_0764.dim() == 2:
        local_value_0764 = local_value_0764.unsqueeze(1)
    if local_value_0000.dim() == 2:
        local_value_0000 = local_value_0000.unsqueeze(0)
    if B.dim() == 2:
        B = B.unsqueeze(1)
    if local_value_0044.dim() == 2:
        local_value_0044 = local_value_0044.unsqueeze(1)
    if D is not None and D.dim() == 1:
        D = D.unsqueeze(0)
    if local_value_1753 is not None and local_value_1753.dim() == 2:
        local_value_1753 = local_value_1753.unsqueeze(1)
    if local_value_0767 is not None and local_value_0767.dim() == 1:
        local_value_0767 = local_value_0767.unsqueeze(0)
    local_value_0434, local_value_1090, dim, local_value_0759 = local_value_1391.shape
    assert local_value_1699.shape == (local_value_0434, local_value_1090, dim)
    assert local_value_0764.shape == local_value_1699.shape
    assert local_value_0000.shape == (local_value_1090, dim, local_value_0759)
    local_value_1089 = B.shape[1]
    assert local_value_1090 % local_value_1089 == 0, 'nheads must be divisible by ngroups'
    assert B.shape == (local_value_0434, local_value_1089, local_value_0759)
    assert local_value_0044.shape == B.shape
    if D is not None:
        assert D.shape == (local_value_1090, dim)
    if local_value_1753 is not None:
        assert local_value_1753.shape == local_value_1699.shape
    if local_value_0767 is not None:
        assert local_value_0767.shape == (local_value_1090, dim)
    out = local_value_1650.empty_like(local_value_1699)
    local_value_0899 = lambda local_value_0177: (local_value_1655.cdiv(dim, local_value_0177['BLOCK_SIZE_M']), local_value_0434, local_value_1090)
    local_value_1759 = (local_value_1753.stride(0), local_value_1753.stride(1), local_value_1753.stride(2)) if local_value_1753 is not None else (0, 0, 0)
    BLOCK_SIZE_M, num_warps = (32, 4) if local_value_0759 <= 16 else (16, 4) if local_value_0759 <= 32 else (8, 4) if local_value_0759 <= 64 else (4, 4) if local_value_0759 <= 128 else (4, 8)
    local_value_1628 = local_value_0000.stride(-1) == 0 and local_value_0000.stride(-2) == 0 and (local_value_0764.stride(-1) == 0) and (local_value_0767.stride(-1) == 0)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0384[local_value_0899](local_value_1391, local_value_1699, local_value_0764, local_value_0767, local_value_0000, B, local_value_0044, D, local_value_1753, out, local_value_0434, local_value_1090, dim, local_value_0759, local_value_1090 // local_value_1089, local_value_1391.stride(0), local_value_1391.stride(1), local_value_1391.stride(2), local_value_1391.stride(3), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_0764.stride(0), local_value_0764.stride(1), local_value_0764.stride(2), *((local_value_0767.stride(0), local_value_0767.stride(1)) if local_value_0767 is not None else 0), local_value_0000.stride(0), local_value_0000.stride(1), local_value_0000.stride(2), B.stride(0), B.stride(1), B.stride(2), local_value_0044.stride(0), local_value_0044.stride(1), local_value_0044.stride(2), *((D.stride(0), D.stride(1)) if D is not None else 0), local_value_1759[0], local_value_1759[1], local_value_1759[2], out.stride(0), out.stride(1), out.stride(2), local_value_0794, local_value_1628, BLOCK_SIZE_M, num_warps=num_warps)
    if not local_value_0918:
        out = out.squeeze(1)
    return out

def execute_step_1335(local_value_1391, local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, local_value_0767=None, local_value_0794=False):
    local_value_0918 = local_value_1391.dim() > 3
    if local_value_1391.dim() == 3:
        local_value_1391 = local_value_1391.unsqueeze(1)
    if local_value_1699.dim() == 2:
        local_value_1699 = local_value_1699.unsqueeze(1)
    if local_value_0764.dim() == 2:
        local_value_0764 = local_value_0764.unsqueeze(1)
    if local_value_0000.dim() == 2:
        local_value_0000 = local_value_0000.unsqueeze(0)
    if B.dim() == 2:
        B = B.unsqueeze(1)
    if local_value_0044.dim() == 2:
        local_value_0044 = local_value_0044.unsqueeze(1)
    if D is not None and D.dim() == 1:
        D = D.unsqueeze(0)
    if local_value_1753 is not None and local_value_1753.dim() == 2:
        local_value_1753 = local_value_1753.unsqueeze(1)
    if local_value_0767 is not None and local_value_0767.dim() == 1:
        local_value_0767 = local_value_0767.unsqueeze(0)
    local_value_0434, local_value_1090, dim, local_value_0759 = local_value_1391.shape
    assert local_value_1699.shape == (local_value_0434, local_value_1090, dim)
    assert local_value_0764.shape == local_value_1699.shape
    assert local_value_0000.shape == (local_value_1090, dim, local_value_0759)
    local_value_1089 = B.shape[1]
    assert local_value_1090 % local_value_1089 == 0, 'nheads must be divisible by ngroups'
    assert B.shape == (local_value_0434, local_value_1089, local_value_0759)
    assert local_value_0044.shape == B.shape
    if D is not None:
        assert D.shape == (local_value_1090, dim)
    if local_value_1753 is not None:
        assert local_value_1753.shape == local_value_1699.shape
    if local_value_0767 is not None:
        assert local_value_0767.shape == (local_value_1090, dim)
        local_value_0764 = local_value_0764 + local_value_0767
    local_value_0764 = local_value_0117.softplus(local_value_0764) if local_value_0794 else local_value_0764
    local_value_0564 = local_value_1650.exp(local_value_1249(local_value_0764, 'b h d -> b h d 1') * local_value_0000)
    B = repeat(B, 'b g n -> b (g h) n', h=local_value_1090 // local_value_1089)
    local_value_0044 = repeat(local_value_0044, 'b g n -> b (g h) n', h=local_value_1090 // local_value_1089)
    local_value_0582 = local_value_1249(local_value_0764, 'b h d -> b h d 1') * local_value_1249(B, 'b h n -> b h 1 n')
    local_value_1391.copy_(local_value_1391 * local_value_0564 + local_value_0582 * local_value_1249(local_value_1699, 'b h d -> b h d 1'))
    out = local_value_1650.einsum('bhdn,bhn->bhd', local_value_1391.to(local_value_0044.dtype), local_value_0044)
    if D is not None:
        out += (local_value_1699 * D).to(out.dtype)
    out = (out if local_value_1753 is None else out * local_value_0117.silu(local_value_1753)).to(local_value_1699.dtype)
    if not local_value_0918:
        out = out.squeeze(1)
    return out
