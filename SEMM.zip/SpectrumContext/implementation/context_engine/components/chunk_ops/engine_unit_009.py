import math as local_value_1039
import torch as local_value_1650
import torch.nn.functional as local_value_0117
import triton as local_value_1655
import triton.language as local_value_1631
from einops import rearrange as local_value_1249

def execute_step_1282(local_value_1699, weight, bias, local_value_1753=None, eps=1e-06, local_value_0910=None, local_value_1099=True, local_value_1668=True):
    dtype = local_value_1699.dtype
    N = local_value_1699.shape[-1]
    weight = weight.float()
    bias = bias.float() if bias is not None else None
    if local_value_1668:
        local_value_1699 = local_value_1699.float()
        local_value_1753 = local_value_1753.float() if local_value_1753 is not None else local_value_1753
    if local_value_1753 is not None and (not local_value_1099):
        local_value_1699 = local_value_1699 * local_value_0117.silu(local_value_1753)
    if local_value_0910 is None:
        local_value_1294 = 1 / local_value_1650.sqrt(local_value_1699.square().mean(dim=-1, keepdim=True) + eps)
        out = local_value_1699 * local_value_1294 * weight + bias if bias is not None else local_value_1699 * local_value_1294 * weight
    else:
        local_value_1710 = local_value_1249(local_value_1699, '... (g d) -> ... g d', d=local_value_0910)
        local_value_1294 = 1 / local_value_1650.sqrt(local_value_1710.square().mean(dim=-1, keepdim=True) + eps)
        out = local_value_1249(local_value_1710 * local_value_1294, '... g d -> ... (g d)') * weight
        if bias is not None:
            out = out + bias
    if local_value_1753 is not None and local_value_1099:
        out *= local_value_0117.silu(local_value_1753)
    return out.to(dtype)

@local_value_1655.heuristics({'local_value_0127': lambda local_value_0416: local_value_0416['B'] is not None})
@local_value_1655.heuristics({'HAS_Z': lambda local_value_0416: local_value_0416['local_value_0271'] is not None})
@local_value_1655.jit
def execute_step_0358(local_value_0261, local_value_0267, W, B, local_value_0271, local_value_0185, local_value_0214, local_value_1603, local_value_1606, local_value_1611, local_value_0175, N, eps, BLOCK_N: local_value_1631.constexpr, local_value_0127: local_value_1631.constexpr, HAS_Z: local_value_1631.constexpr, NORM_BEFORE_GATE: local_value_1631.constexpr, IS_RMS_NORM: local_value_1631.constexpr):
    local_value_1286 = local_value_1631.program_id(0)
    local_value_0909 = local_value_1631.program_id(1)
    local_value_0261 += local_value_1286 * local_value_1603 + local_value_0909 * N
    local_value_0267 += local_value_1286 * local_value_1606 + local_value_0909 * N
    if HAS_Z:
        local_value_0271 += local_value_1286 * local_value_1611 + local_value_0909 * N
    if not IS_RMS_NORM:
        local_value_0185 += local_value_0909 * local_value_0175
    local_value_0214 += local_value_0909 * local_value_0175
    W += local_value_0909 * N
    if local_value_0127:
        B += local_value_0909 * N
    local_value_0527 = local_value_1631.arange(0, BLOCK_N)
    local_value_1699 = local_value_1631.load(local_value_0261 + local_value_0527, mask=local_value_0527 < N, other=0.0).to(local_value_1631.float32)
    if HAS_Z and (not NORM_BEFORE_GATE):
        local_value_1753 = local_value_1631.load(local_value_0271 + local_value_0527, mask=local_value_0527 < N).to(local_value_1631.float32)
        local_value_1699 *= local_value_1753 * local_value_1631.sigmoid(local_value_1753)
    if not IS_RMS_NORM:
        local_value_1043 = local_value_1631.sum(local_value_1699, axis=0) / N
        local_value_1631.store(local_value_0185 + local_value_1286, local_value_1043)
        local_value_1730 = local_value_1631.where(local_value_0527 < N, local_value_1699 - local_value_1043, 0.0)
        local_value_1675 = local_value_1631.sum(local_value_1730 * local_value_1730, axis=0) / N
    else:
        local_value_1730 = local_value_1631.where(local_value_0527 < N, local_value_1699, 0.0)
        local_value_1675 = local_value_1631.sum(local_value_1730 * local_value_1730, axis=0) / N
    local_value_1294 = 1 / local_value_1631.sqrt(local_value_1675 + eps)
    local_value_1631.store(local_value_0214 + local_value_1286, local_value_1294)
    mask = local_value_0527 < N
    local_value_1683 = local_value_1631.load(W + local_value_0527, mask=mask).to(local_value_1631.float32)
    if local_value_0127:
        b = local_value_1631.load(B + local_value_0527, mask=mask).to(local_value_1631.float32)
    local_value_1712 = (local_value_1699 - local_value_1043) * local_value_1294 if not IS_RMS_NORM else local_value_1699 * local_value_1294
    y = local_value_1712 * local_value_1683 + b if local_value_0127 else local_value_1712 * local_value_1683
    if HAS_Z and NORM_BEFORE_GATE:
        local_value_1753 = local_value_1631.load(local_value_0271 + local_value_0527, mask=mask).to(local_value_1631.float32)
        y *= local_value_1753 * local_value_1631.sigmoid(local_value_1753)
    local_value_1631.store(local_value_0267 + local_value_0527, y, mask=mask)

def execute_step_0357(local_value_1699, weight, bias, eps, local_value_1753=None, out=None, local_value_0910=None, local_value_1099=True, local_value_0992=False):
    local_value_0175, N = local_value_1699.shape
    if local_value_0910 is None:
        local_value_0910 = N
    assert N % local_value_0910 == 0
    local_value_1089 = N // local_value_0910
    assert local_value_1699.stride(-1) == 1
    if local_value_1753 is not None:
        assert local_value_1753.stride(-1) == 1
        assert local_value_1753.shape == (local_value_0175, N)
    assert weight.shape == (N,)
    assert weight.stride(-1) == 1
    if bias is not None:
        assert bias.stride(-1) == 1
        assert bias.shape == (N,)
    if out is not None:
        assert out.shape == local_value_1699.shape
    else:
        out = local_value_1650.empty_like(local_value_1699)
    assert out.stride(-1) == 1
    local_value_1043 = local_value_1650.empty((local_value_1089 * local_value_0175,), dtype=local_value_1650.float32, device=local_value_1699.device) if not local_value_0992 else None
    local_value_1294 = local_value_1650.empty((local_value_1089 * local_value_0175,), dtype=local_value_1650.float32, device=local_value_1699.device)
    local_value_0176 = 65536 // local_value_1699.element_size()
    BLOCK_N = min(local_value_0176, local_value_1655.next_power_of_2(local_value_0910))
    if local_value_0910 > BLOCK_N:
        raise RuntimeError("This layer norm doesn't support feature dim >= 64KB.")
    num_warps = min(max(BLOCK_N // 256, 1), 8)
    local_value_0899 = (local_value_0175, local_value_1089)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0358[local_value_0899](local_value_1699, out, weight, bias, local_value_1753, local_value_1043, local_value_1294, local_value_1699.stride(0), out.stride(0), local_value_1753.stride(0) if local_value_1753 is not None else 0, local_value_0175, local_value_0910, eps, BLOCK_N=BLOCK_N, NORM_BEFORE_GATE=local_value_1099, IS_RMS_NORM=local_value_0992, num_warps=num_warps)
    return (out, local_value_1043, local_value_1294)

@local_value_1655.heuristics({'local_value_0127': lambda local_value_0416: local_value_0416['B'] is not None})
@local_value_1655.heuristics({'HAS_Z': lambda local_value_0416: local_value_0416['local_value_0271'] is not None})
@local_value_1655.heuristics({'RECOMPUTE_OUTPUT': lambda local_value_0416: local_value_0416['local_value_0267'] is not None})
@local_value_1655.jit
def execute_step_0356(local_value_0261, W, B, local_value_0271, local_value_0267, local_value_0103, local_value_0101, local_value_0098, local_value_0085, local_value_0105, local_value_0185, local_value_0214, local_value_1603, local_value_1611, local_value_1606, local_value_1550, local_value_1547, local_value_1554, local_value_1542, local_value_1459, local_value_0175, N, eps, local_value_1290, NORM_BEFORE_GATE: local_value_1631.constexpr, IS_RMS_NORM: local_value_1631.constexpr, local_value_0127: local_value_1631.constexpr, HAS_Z: local_value_1631.constexpr, RECOMPUTE_OUTPUT: local_value_1631.constexpr, BLOCK_N: local_value_1631.constexpr):
    local_value_1287 = local_value_1631.program_id(0)
    local_value_0909 = local_value_1631.program_id(1)
    local_value_1289 = local_value_1287 * local_value_1290
    local_value_0527 = local_value_1631.arange(0, BLOCK_N)
    mask = local_value_0527 < N
    local_value_0261 += local_value_1289 * local_value_1603 + local_value_0909 * N
    if HAS_Z:
        local_value_0271 += local_value_1289 * local_value_1611 + local_value_0909 * N
        local_value_0105 += local_value_1289 * local_value_1554 + local_value_0909 * N
    local_value_0103 += local_value_1289 * local_value_1550 + local_value_0909 * N
    local_value_0101 += local_value_1289 * local_value_1547 + local_value_0909 * N
    if RECOMPUTE_OUTPUT:
        local_value_0267 += local_value_1289 * local_value_1606 + local_value_0909 * N
    if not IS_RMS_NORM:
        local_value_0185 += local_value_0909 * local_value_0175
    local_value_0214 += local_value_0909 * local_value_0175
    W += local_value_0909 * N
    local_value_1683 = local_value_1631.load(W + local_value_0527, mask=mask).to(local_value_1631.float32)
    if (RECOMPUTE_OUTPUT or HAS_Z) and local_value_0127:
        B += local_value_0909 * N
        b = local_value_1631.load(B + local_value_0527, mask=mask, other=0.0).to(local_value_1631.float32)
    local_value_0803 = local_value_1631.zeros((BLOCK_N,), dtype=local_value_1631.float32)
    if local_value_0127:
        local_value_0641 = local_value_1631.zeros((BLOCK_N,), dtype=local_value_1631.float32)
    local_value_1288 = min((local_value_1287 + 1) * local_value_1290, local_value_0175)
    for local_value_1286 in range(local_value_1289, local_value_1288):
        local_value_1699 = local_value_1631.load(local_value_0261 + local_value_0527, mask=mask, other=0).to(local_value_1631.float32)
        local_value_0813 = local_value_1631.load(local_value_0103 + local_value_0527, mask=mask, other=0).to(local_value_1631.float32)
        if not IS_RMS_NORM:
            local_value_1043 = local_value_1631.load(local_value_0185 + local_value_1286)
        if HAS_Z and (not NORM_BEFORE_GATE):
            local_value_1753 = local_value_1631.load(local_value_0271 + local_value_0527, mask=mask, other=0.0).to(local_value_1631.float32)
            local_value_1718 = local_value_1699
            local_value_1699 = local_value_1718 * local_value_1753 * local_value_1631.sigmoid(local_value_1753)
        local_value_1294 = local_value_1631.load(local_value_0214 + local_value_1286)
        local_value_1732 = (local_value_1699 - local_value_1043) * local_value_1294 if not IS_RMS_NORM else local_value_1699 * local_value_1294
        local_value_1732 = local_value_1631.where(mask, local_value_1732, 0.0)
        if HAS_Z and NORM_BEFORE_GATE:
            local_value_1753 = local_value_1631.load(local_value_0271 + local_value_0527, mask=mask, other=0.0).to(local_value_1631.float32)
            local_value_1758 = local_value_1631.sigmoid(local_value_1753)
            y = local_value_1732 * local_value_1683 + b if local_value_0127 else local_value_1732 * local_value_1683
            if RECOMPUTE_OUTPUT:
                local_value_1631.store(local_value_0267 + local_value_0527, y * local_value_1753 * local_value_1758, mask=mask)
            local_value_0816 = local_value_0813 * y * local_value_1758 * (1 + local_value_1753 * (1 - local_value_1758))
            local_value_1631.store(local_value_0105 + local_value_0527, local_value_0816, mask=mask)
            local_value_0813 *= local_value_1753 * local_value_1758
        elif RECOMPUTE_OUTPUT:
            y = local_value_1732 * local_value_1683 + b if local_value_0127 else local_value_1732 * local_value_1683
            local_value_1631.store(local_value_0267 + local_value_0527, y, mask=mask)
        local_value_1687 = local_value_1683 * local_value_0813
        local_value_0462 = local_value_1631.sum(local_value_1732 * local_value_1687, axis=0) / N
        if not IS_RMS_NORM:
            local_value_0463 = local_value_1631.sum(local_value_1687, axis=0) / N
            local_value_0806 = (local_value_1687 - (local_value_1732 * local_value_0462 + local_value_0463)) * local_value_1294
        else:
            local_value_0806 = (local_value_1687 - local_value_1732 * local_value_0462) * local_value_1294
        local_value_0803 += local_value_0813 * local_value_1732
        if local_value_0127:
            local_value_0641 += local_value_0813
        if HAS_Z and (not NORM_BEFORE_GATE):
            local_value_1758 = local_value_1631.sigmoid(local_value_1753)
            local_value_0816 = local_value_0806 * local_value_1718 * local_value_1758 * (1 + local_value_1753 * (1 - local_value_1758))
            local_value_1631.store(local_value_0105 + local_value_0527, local_value_0816, mask=mask)
            local_value_0806 *= local_value_1753 * local_value_1758
        local_value_1631.store(local_value_0101 + local_value_0527, local_value_0806, mask=mask)
        local_value_0261 += local_value_1603
        if HAS_Z:
            local_value_0271 += local_value_1611
            local_value_0105 += local_value_1554
        if RECOMPUTE_OUTPUT:
            local_value_0267 += local_value_1606
        local_value_0103 += local_value_1550
        local_value_0101 += local_value_1547
    local_value_1631.store(local_value_0098 + local_value_1287 * local_value_1542 + local_value_0909 * N + local_value_0527, local_value_0803, mask=mask)
    if local_value_0127:
        local_value_1631.store(local_value_0085 + local_value_1287 * local_value_1459 + local_value_0909 * N + local_value_0527, local_value_0641, mask=mask)

def execute_step_0355(local_value_0813, local_value_1699, weight, bias, eps, local_value_1043, local_value_1294, local_value_1753=None, local_value_0910=None, local_value_1099=True, local_value_0992=False, local_value_1250=False, local_value_0816=None, out=None):
    local_value_0175, N = local_value_1699.shape
    if local_value_0910 is None:
        local_value_0910 = N
    assert N % local_value_0910 == 0
    local_value_1089 = N // local_value_0910
    assert local_value_1699.stride(-1) == 1
    assert local_value_0813.stride(-1) == 1
    assert local_value_0813.shape == (local_value_0175, N)
    if local_value_1753 is not None:
        assert local_value_1753.stride(-1) == 1
        assert local_value_1753.shape == (local_value_0175, N)
    assert weight.shape == (N,)
    assert weight.stride(-1) == 1
    if bias is not None:
        assert bias.stride(-1) == 1
        assert bias.shape == (N,)
    local_value_0806 = local_value_1650.empty_like(local_value_1699)
    if local_value_0816 is not None:
        assert local_value_1753 is not None
        assert local_value_0816.shape == local_value_1753.shape
        assert local_value_0816.stride(-1) == 1
    else:
        local_value_0816 = local_value_1650.empty_like(local_value_1753) if local_value_1753 is not None else None
    if local_value_1250:
        if out is None:
            out = local_value_1650.empty_like(local_value_1699)
        assert out.shape == local_value_1699.shape
    local_value_0176 = 65536 // local_value_1699.element_size()
    BLOCK_N = min(local_value_0176, local_value_1655.next_power_of_2(local_value_0910))
    if local_value_0910 > BLOCK_N:
        raise RuntimeError("This layer norm doesn't support feature dim >= 64KB.")
    num_warps = min(max(BLOCK_N // 256, 1), 8)
    local_value_1355 = local_value_1650.cuda.get_device_properties(local_value_1699.device).multi_processor_count
    local_value_1105 = local_value_1039.ceil(local_value_1355 * local_value_1039.ceil(4 / num_warps) / local_value_1089)
    local_value_0336 = local_value_1650.empty((local_value_1105, N), dtype=local_value_1650.float32, device=weight.device)
    local_value_0333 = local_value_1650.empty((local_value_1105, N), dtype=local_value_1650.float32, device=bias.device) if bias is not None else None
    local_value_1290 = local_value_1039.ceil(local_value_0175 / local_value_1105)
    local_value_0899 = (local_value_1105, local_value_1089)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0356[local_value_0899](local_value_1699, weight, bias, local_value_1753, out if local_value_1250 else None, local_value_0813, local_value_0806, local_value_0336, local_value_0333, local_value_0816, local_value_1043, local_value_1294, local_value_1699.stride(0), local_value_1753.stride(0) if local_value_1753 is not None else 0, 0 if not local_value_1250 else out.stride(0), local_value_0813.stride(0), local_value_0806.stride(0), local_value_0816.stride(0) if local_value_0816 is not None else 0, local_value_0336.stride(0), local_value_0333.stride(0) if local_value_0333 is not None else 0, local_value_0175, local_value_0910, eps, local_value_1290, BLOCK_N=BLOCK_N, NORM_BEFORE_GATE=local_value_1099, IS_RMS_NORM=local_value_0992, num_warps=num_warps)
    local_value_0803 = local_value_0336.sum(0).to(weight.dtype)
    local_value_0641 = local_value_0333.sum(0).to(bias.dtype) if bias is not None else None
    return (local_value_0806, local_value_0803, local_value_0641, local_value_0816) if not local_value_1250 else (local_value_0806, local_value_0803, local_value_0641, local_value_0816, out)

class ComponentUnit0170(local_value_1650.autograd.Function):

    @staticmethod
    def forward(local_value_0551, local_value_1699, weight, bias, local_value_1753=None, eps=1e-06, local_value_0910=None, local_value_1099=True, local_value_0992=False):
        local_value_1727 = local_value_1699.shape
        local_value_1699 = local_value_1699.reshape(-1, local_value_1699.shape[-1])
        if local_value_1699.stride(-1) != 1:
            local_value_1699 = local_value_1699.contiguous()
        if local_value_1753 is not None:
            assert local_value_1753.shape == local_value_1727
            local_value_1753 = local_value_1753.reshape(-1, local_value_1753.shape[-1])
            if local_value_1753.stride(-1) != 1:
                local_value_1753 = local_value_1753.contiguous()
        weight = weight.contiguous()
        if bias is not None:
            bias = bias.contiguous()
        y, local_value_1043, local_value_1294 = execute_step_0357(local_value_1699, weight, bias, eps, local_value_1753=local_value_1753, local_value_0910=local_value_0910, local_value_1099=local_value_1099, local_value_0992=local_value_0992)
        local_value_0551.save_for_backward(local_value_1699, weight, bias, local_value_1043, local_value_1294, local_value_1753)
        local_value_0551.local_value_1727 = local_value_1727
        local_value_0551.eps = eps
        local_value_0551.local_value_0910 = local_value_0910
        local_value_0551.local_value_1099 = local_value_1099
        local_value_0551.local_value_0992 = local_value_0992
        return y.reshape(local_value_1727)

    @staticmethod
    def backward(local_value_0551, local_value_0813):
        local_value_1699, weight, bias, local_value_1043, local_value_1294, local_value_1753 = local_value_0551.saved_tensors
        local_value_0813 = local_value_0813.reshape(-1, local_value_0813.shape[-1])
        if local_value_0813.stride(-1) != 1:
            local_value_0813 = local_value_0813.contiguous()
        assert local_value_0813.shape == local_value_1699.shape
        local_value_0806, local_value_0803, local_value_0641, local_value_0816 = execute_step_0355(local_value_0813, local_value_1699, weight, bias, local_value_0551.eps, local_value_1043, local_value_1294, local_value_1753, local_value_0551.local_value_0910, local_value_0551.local_value_1099, local_value_0551.local_value_0992)
        return (local_value_0806.reshape(local_value_0551.local_value_1727), local_value_0803, local_value_0641, local_value_0816.reshape(local_value_0551.local_value_1727) if local_value_0816 is not None else None, None, None, None, None)

def execute_step_1018(local_value_1699, weight, bias, local_value_1753=None, eps=1e-06, local_value_0910=None, local_value_1099=True, local_value_0992=False):
    return ComponentUnit0170.apply(local_value_1699, weight, bias, local_value_1753, eps, local_value_0910, local_value_1099, local_value_0992)

def execute_step_1284(local_value_1699, weight, bias, local_value_1753=None, eps=1e-06, local_value_0910=None, local_value_1099=True):
    return ComponentUnit0170.apply(local_value_1699, weight, bias, local_value_1753, eps, local_value_0910, local_value_1099, True)

class ComponentUnit0167(local_value_1650.nn.Module):

    def __init__(local_value_1336, local_value_0930, eps=1e-05, local_value_0910=None, local_value_1099=True, device=None, dtype=None):
        local_value_0835 = {'device': device, 'dtype': dtype}
        super().__init__()
        local_value_1336.eps = eps
        local_value_1336.weight = local_value_1650.nn.Parameter(local_value_1650.empty(local_value_0930, **local_value_0835))
        local_value_1336.bias = local_value_1650.nn.Parameter(local_value_1650.empty(local_value_0930, **local_value_0835))
        local_value_1336.local_value_0910 = local_value_0910
        local_value_1336.local_value_1099 = local_value_1099
        local_value_1336.reset_parameters()

    def reset_parameters(local_value_1336):
        local_value_1650.nn.init.ones_(local_value_1336.weight)
        local_value_1650.nn.init.zeros_(local_value_1336.bias)

    def forward(local_value_1336, local_value_1699, local_value_1753=None):
        return execute_step_1018(local_value_1699, local_value_1336.weight, local_value_1336.bias, local_value_1753=local_value_1753, local_value_0910=local_value_1336.local_value_0910, eps=local_value_1336.eps, local_value_1099=local_value_1336.local_value_1099)

class ComponentUnit0212(local_value_1650.nn.Module):

    def __init__(local_value_1336, local_value_0930, eps=1e-05, local_value_0910=None, local_value_1099=True, device=None, dtype=None):
        local_value_0835 = {'device': device, 'dtype': dtype}
        super().__init__()
        local_value_1336.eps = eps
        local_value_1336.weight = local_value_1650.nn.Parameter(local_value_1650.empty(local_value_0930, **local_value_0835))
        local_value_1336.member_slot_0400('bias', None)
        local_value_1336.local_value_0910 = local_value_0910
        local_value_1336.local_value_1099 = local_value_1099
        local_value_1336.reset_parameters()

    def reset_parameters(local_value_1336):
        local_value_1650.nn.init.ones_(local_value_1336.weight)

    def forward(local_value_1336, local_value_1699, local_value_1753=None):
        return execute_step_1284(local_value_1699, local_value_1336.weight, local_value_1336.bias, local_value_1753=local_value_1753, eps=local_value_1336.eps, local_value_0910=local_value_1336.local_value_0910, local_value_1099=local_value_1336.local_value_1099)
