from typing import Optional as local_value_0199
import math as local_value_1039
from packaging import version
import torch as local_value_1650
import torch.nn.functional as local_value_0117
from torch import Tensor as local_value_0242
from torch.cuda.amp import custom_bwd as local_value_0558, custom_fwd as local_value_0559
import triton as local_value_1655
import triton.language as local_value_1631
from einops import rearrange as local_value_1249, repeat
try:
    from causal_conv1d import causal_conv1d_fn as local_value_0481
    import causal_conv1d_cuda as local_value_0480
except ImportError:
    local_value_0481, local_value_0480 = (None, None)
try:
    from .engine_unit_022 import execute_step_0293, execute_step_0291
    from .engine_unit_024 import execute_step_0297, execute_step_0295
    from .engine_unit_024 import execute_step_0329, execute_step_0323
    from .engine_unit_024 import execute_step_0325
    from .engine_unit_024 import execute_step_0516, execute_step_0517
    from .engine_unit_027 import execute_step_0387, execute_step_0385
    from .engine_unit_027 import execute_step_1395, execute_step_1396
    from .engine_unit_023 import execute_step_0319, execute_step_0315, execute_step_0311
    from .engine_unit_023 import execute_step_0299, execute_step_0301
    from .engine_unit_023 import execute_step_0305
    from .engine_unit_023 import execute_step_0511, execute_step_0512
    from .engine_unit_023 import execute_step_0303
    from .engine_unit_009 import execute_step_1284, execute_step_0357, execute_step_0355
    from .engine_unit_007 import execute_step_0391, execute_step_0389
except:
    from engine_unit_022 import execute_step_0293, execute_step_0291
    from engine_unit_024 import execute_step_0297, execute_step_0295
    from engine_unit_024 import execute_step_0329, execute_step_0323
    from engine_unit_024 import execute_step_0325
    from engine_unit_024 import execute_step_0516, execute_step_0517
    from engine_unit_027 import execute_step_0387, execute_step_0385
    from engine_unit_027 import execute_step_1395, execute_step_1396
    from engine_unit_023 import execute_step_0319, execute_step_0315, execute_step_0311
    from engine_unit_023 import execute_step_0299, execute_step_0301
    from engine_unit_023 import execute_step_0305
    from engine_unit_023 import execute_step_0511, execute_step_0512
    from engine_unit_023 import execute_step_0303
    from engine_unit_009 import execute_step_1284, execute_step_0357, execute_step_0355
    from engine_unit_007 import execute_step_0391, execute_step_0389
local_value_0241 = version.parse(local_value_1655.__version__) >= version.parse('2.2.0')
if True:

    class ComponentUnit1619(local_value_1650.Tensor):

        @property
        def shape(local_value_1336):
            shape = super().shape
            return tuple([int(s) for s in shape])
    local_value_1647 = lambda *local_value_0416: tuple([ComponentUnit1619(local_value_1699) for local_value_1699 in local_value_0416]) if len(local_value_0416) > 1 else ComponentUnit1619(local_value_0416[0])

def execute_step_0965(local_value_1075):
    return lambda local_value_1076: [local_value_1076[name].zero_() for name in local_value_1075 if local_value_1076[name] is not None]

@local_value_1655.autotune(configs=[local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 64}, num_stages=3, num_warps=8, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 128, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 32, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 32, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=5, num_warps=4, pre_hook=execute_step_0965(['local_value_0680'])), local_value_1655.Config({'BLOCK_SIZE_M': 64, 'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 32}, num_stages=4, num_warps=4, pre_hook=execute_step_0965(['local_value_0680']))], key=['local_value_0513', 'local_value_0923', 'local_value_0759'])
@local_value_1655.jit
def execute_step_0318(local_value_1720, local_value_0484, local_value_0726, local_value_0789, local_value_0574, local_value_1346, local_value_0108, local_value_0427, local_value_0762, local_value_0810, local_value_0680, local_value_0591, local_value_0513, local_value_0923, local_value_0759, local_value_0434, local_value_1348, local_value_1092, local_value_1599, local_value_1604, local_value_1602, local_value_1601, local_value_1438, local_value_1439, local_value_1443, local_value_1441, local_value_1440, local_value_1504, local_value_1512, local_value_1510, local_value_1509, local_value_1530, local_value_1533, local_value_1536, local_value_1534, local_value_1444, local_value_1445, local_value_1447, local_value_1446, local_value_1586, local_value_1587, local_value_1424, local_value_1429, local_value_1432, local_value_1431, local_value_1430, local_value_1524, local_value_1525, local_value_1529, local_value_1528, local_value_1527, local_value_1544, local_value_1548, local_value_1546, local_value_1545, local_value_1488, local_value_1490, local_value_1492, local_value_1491, local_value_1449, local_value_1450, local_value_1453, local_value_1451, local_value_1452, local_value_0128: local_value_1631.constexpr, local_value_0106: local_value_1631.constexpr, HAS_SEQ_IDX: local_value_1631.constexpr, BLOCK_SIZE_M: local_value_1631.constexpr, BLOCK_SIZE_N: local_value_1631.constexpr, BLOCK_SIZE_K: local_value_1631.constexpr, BLOCK_SIZE_DSTATE: local_value_1631.constexpr, IS_TRITON_22: local_value_1631.constexpr):
    local_value_1205 = local_value_1631.program_id(axis=1)
    local_value_1206 = local_value_1205 // local_value_0434
    local_value_1204 = local_value_1205 - local_value_1206 * local_value_0434
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1111 = local_value_1631.cdiv(local_value_0923, BLOCK_SIZE_N)
    local_value_1210 = local_value_1631.program_id(axis=0) // local_value_1111
    local_value_1211 = local_value_1631.program_id(axis=0) % local_value_1111
    local_value_1720 += local_value_1204 * local_value_1599 + local_value_1206 * local_value_0513 * local_value_1604 + local_value_1209 * local_value_1602
    local_value_0484 += local_value_1204 * local_value_1438 + local_value_1206 * local_value_1439 + local_value_1209 // local_value_1092 * local_value_1443
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1206 * local_value_0513 * local_value_1512 + local_value_1209 * local_value_1510
    local_value_0789 += local_value_1204 * local_value_1530 + local_value_1206 * local_value_1533 + local_value_1209 * local_value_1536
    local_value_0680 += local_value_1204 * local_value_1488 + local_value_1206 * local_value_1490 + local_value_1209 * local_value_1492
    local_value_0574 += local_value_1204 * local_value_1444 + local_value_1206 * local_value_1445 + local_value_1209 * local_value_1447
    local_value_0427 += local_value_1204 * local_value_1429 + local_value_1206 * local_value_0513 * local_value_1432 + local_value_1209 // local_value_1092 * local_value_1431
    local_value_0762 += local_value_1204 * local_value_1524 + local_value_1206 * local_value_1525 + local_value_1209 * local_value_1529
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586 + local_value_1206 * local_value_0513 * local_value_1587
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0514 = min(local_value_0513, local_value_1348 - local_value_1206 * local_value_0513)
    local_value_0409 = local_value_1631.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=local_value_1631.float32)
    local_value_0569 = local_value_1631.load(local_value_0574 + local_value_1123 * local_value_1446, mask=local_value_1123 < local_value_0514, other=0.0).to(local_value_1631.float32)
    local_value_0568 = local_value_1631.load(local_value_0574 + (local_value_0513 - 1) * local_value_1446).to(local_value_1631.float32)
    if not HAS_SEQ_IDX:
        local_value_1302 = local_value_1631.exp(local_value_0568 - local_value_0569)
    else:
        local_value_1342 = local_value_1631.load(local_value_1346 + local_value_1123 * local_value_1587, mask=local_value_1123 < local_value_0514, other=-1)
        local_value_1341 = local_value_1631.load(local_value_1346 + (local_value_0514 - 1) * local_value_1587)
        local_value_1302 = local_value_1631.where(local_value_1342 == local_value_1341, local_value_1631.exp(local_value_0568 - local_value_0569), 0.0)
    local_value_1119 = local_value_1631.arange(0, BLOCK_SIZE_DSTATE if IS_TRITON_22 and BLOCK_SIZE_DSTATE <= 128 else BLOCK_SIZE_K)
    local_value_0428 = local_value_0427 + (local_value_1123[:, None] * local_value_1432 + local_value_1119[None, :] * local_value_1430)
    local_value_0763 = local_value_0762 + (local_value_1124[None, :] * local_value_1528 + local_value_1119[:, None] * local_value_1527)
    if IS_TRITON_22 and BLOCK_SIZE_DSTATE <= 128:
        b = local_value_1631.load(local_value_0428, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1119[None, :] < local_value_0759), other=0.0)
        local_value_0760 = local_value_1631.load(local_value_0763, mask=(local_value_1119[:, None] < local_value_0759) & (local_value_1124[None, :] < local_value_0923), other=0.0)
        local_value_0760 = local_value_0760.to(local_value_0427.dtype.element_ty)
        local_value_0409 = local_value_1631.dot(b, local_value_0760) * local_value_1302[:, None]
    else:
        for k in range(0, local_value_0759, BLOCK_SIZE_K):
            b = local_value_1631.load(local_value_0428, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1119[None, :] < local_value_0759 - k), other=0.0)
            local_value_0760 = local_value_1631.load(local_value_0763, mask=(local_value_1119[:, None] < local_value_0759 - k) & (local_value_1124[None, :] < local_value_0923), other=0.0)
            local_value_0760 = local_value_0760.to(local_value_0427.dtype.element_ty)
            local_value_0409 += local_value_1631.dot(b, local_value_0760)
            local_value_0428 += BLOCK_SIZE_K * local_value_1430
            local_value_0763 += BLOCK_SIZE_K * local_value_1527
        local_value_0409 *= local_value_1302[:, None]
    local_value_1121 = local_value_1631.arange(0, BLOCK_SIZE_K)
    local_value_0485 = local_value_0484 + (local_value_1123[:, None] * local_value_1441 + local_value_1121[None, :] * local_value_1440)
    local_value_0727 = local_value_0726 + (local_value_1121[:, None] * local_value_1512 + local_value_1124[None, :] * local_value_1509)
    local_value_0575 = local_value_0574 + local_value_1121 * local_value_1446
    local_value_0159 = local_value_0514
    local_value_0160 = local_value_1210 * BLOCK_SIZE_M
    local_value_0485 += local_value_0160 * local_value_1440
    local_value_0727 += local_value_0160 * local_value_1512
    local_value_0575 += local_value_0160 * local_value_1446
    for k in range(local_value_0160, local_value_0159, BLOCK_SIZE_K):
        k = local_value_1631.multiple_of(k, BLOCK_SIZE_K)
        local_value_0483 = local_value_1631.load(local_value_0485, mask=(local_value_1123[:, None] < local_value_0513) & (local_value_1121[None, :] < local_value_0159 - k), other=0.0)
        local_value_0723 = local_value_1631.load(local_value_0727, mask=(local_value_1121[:, None] < local_value_0159 - k) & (local_value_1124[None, :] < local_value_0923), other=0.0)
        local_value_0567 = local_value_1631.load(local_value_0575, mask=local_value_1121 < local_value_0159 - k, other=0.0).to(local_value_1631.float32)
        local_value_0483 *= local_value_1631.exp(local_value_0567[None, :] - local_value_0569[:, None])
        mask = k + local_value_1121[None, :] >= local_value_1123[:, None]
        local_value_0483 = local_value_1631.where(mask, local_value_0483, 0.0)
        local_value_0483 = local_value_0483.to(local_value_0726.dtype.element_ty)
        local_value_0409 += local_value_1631.dot(local_value_0483, local_value_0723)
        local_value_0485 += BLOCK_SIZE_K * local_value_1440
        local_value_0727 += BLOCK_SIZE_K * local_value_1512
        local_value_0575 += BLOCK_SIZE_K * local_value_1446
    local_value_1123 = local_value_1210 * BLOCK_SIZE_M + local_value_1631.arange(0, BLOCK_SIZE_M)
    local_value_1124 = local_value_1211 * BLOCK_SIZE_N + local_value_1631.arange(0, BLOCK_SIZE_N)
    local_value_0790 = local_value_0789 + local_value_1123 * local_value_1534
    local_value_0777 = local_value_1631.load(local_value_0790, mask=local_value_1123 < local_value_0514, other=0.0).to(local_value_1631.float32)
    local_value_0806 = local_value_0409 * local_value_0777[:, None]
    local_value_0810 += local_value_1204 * local_value_1544 + local_value_1206 * local_value_0513 * local_value_1548 + local_value_1209 * local_value_1546
    local_value_0811 = local_value_0810 + (local_value_1123[:, None] * local_value_1548 + local_value_1124[None, :] * local_value_1545)
    if local_value_0128:
        local_value_0729 = local_value_0726 + (local_value_1123[:, None] * local_value_1512 + local_value_1124[None, :] * local_value_1509)
        local_value_0728 = local_value_1631.load(local_value_0729, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
        if local_value_0106:
            D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424 + local_value_1124, mask=local_value_1124 < local_value_0923, other=0.0).to(local_value_1631.float32)
        else:
            D = local_value_1631.load(local_value_0108 + local_value_1209 * local_value_1424).to(local_value_1631.float32)
        local_value_0806 += local_value_0728 * D
    local_value_1631.store(local_value_0811, local_value_0806, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923))
    local_value_1722 = local_value_1720 + (local_value_1123[:, None] * local_value_1604 + local_value_1124[None, :] * local_value_1601)
    local_value_1699 = local_value_1631.load(local_value_1722, mask=(local_value_1123[:, None] < local_value_0514) & (local_value_1124[None, :] < local_value_0923), other=0.0).to(local_value_1631.float32)
    if local_value_0128:
        local_value_0591 += local_value_1204 * local_value_1449 + local_value_1206 * local_value_1450 + local_value_1209 * local_value_1453 + local_value_1210 * local_value_1451
        if local_value_0106:
            local_value_0592 = local_value_0591 + local_value_1124 * local_value_1452
            local_value_0589 = local_value_1631.sum(local_value_0728 * local_value_1699, axis=0)
            local_value_1631.store(local_value_0592, local_value_0589, mask=local_value_1124 < local_value_0923)
        else:
            local_value_0589 = local_value_1631.sum(local_value_0728 * local_value_1699)
            local_value_1631.store(local_value_0591, local_value_0589)
    local_value_0672 = local_value_1631.sum(local_value_0409 * local_value_1699, axis=1)
    local_value_0681 = local_value_0680 + local_value_1123 * local_value_1491
    local_value_1631.atomic_add(local_value_0681, local_value_0672, mask=local_value_1123 < local_value_0513)

def execute_step_0317(local_value_1699, local_value_0764, local_value_0573, B, local_value_0047, local_value_0723, local_value_0760, D=None, local_value_1339=None, local_value_0806=None):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1078, local_value_0513 = local_value_0764.shape
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
    assert local_value_1090 % local_value_1089 == 0
    assert B.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    assert local_value_0047.shape == (local_value_0434, local_value_1078, local_value_1089, local_value_0513, local_value_0513)
    assert local_value_0764.shape == (local_value_0434, local_value_1090, local_value_1078, local_value_0513)
    assert local_value_0573.shape == local_value_0764.shape
    assert local_value_0723.shape == local_value_1699.shape
    assert local_value_0760.shape == (local_value_0434, local_value_1078, local_value_1090, local_value_0925, local_value_0759)
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    if D is not None:
        assert D.shape == (local_value_1090, local_value_0925) or D.shape == (local_value_1090,)
        assert D.stride(-1) == 1
        local_value_0031 = 32
        local_value_0589 = local_value_1650.empty(local_value_1655.cdiv(local_value_0513, local_value_0031), local_value_0434, local_value_1078, local_value_1090, local_value_0925 if D.dim() == 2 else 1, device=D.device, dtype=local_value_1650.float32)
    else:
        local_value_0589 = None
    local_value_0593 = (local_value_0589.stride(0), local_value_0589.stride(1), local_value_0589.stride(2), local_value_0589.stride(3), local_value_0589.stride(4)) if D is not None else (0, 0, 0, 0, 0)
    if local_value_0806 is None:
        local_value_0806 = local_value_1650.empty_like(local_value_1699)
    else:
        assert local_value_0806.shape == local_value_1699.shape
    local_value_0672 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_0513, device=local_value_0723.device, dtype=local_value_1650.float32)
    local_value_0907 = lambda local_value_0177: (local_value_1655.cdiv(local_value_0513, local_value_0177['BLOCK_SIZE_M']) * local_value_1655.cdiv(local_value_0925, local_value_0177['BLOCK_SIZE_N']), local_value_0434 * local_value_1078, local_value_1090)
    with local_value_1650.cuda.device(local_value_1699.device.index):
        execute_step_0318[local_value_0907](local_value_1699, local_value_0047, local_value_0723, local_value_0764, local_value_0573, local_value_1339, D, B, local_value_0760, local_value_0806, local_value_0672, local_value_0589, int(local_value_0513), int(local_value_0925), int(local_value_0759), int(local_value_0434), int(local_value_1348), int(local_value_1090 // local_value_1089), local_value_1699.stride(0), local_value_1699.stride(1), local_value_1699.stride(2), local_value_1699.stride(3), local_value_0047.stride(0), local_value_0047.stride(1), local_value_0047.stride(2), local_value_0047.stride(-1), local_value_0047.stride(-2), local_value_0723.stride(0), local_value_0723.stride(1), local_value_0723.stride(2), local_value_0723.stride(3), local_value_0764.stride(0), local_value_0764.stride(2), local_value_0764.stride(1), local_value_0764.stride(3), local_value_0573.stride(0), local_value_0573.stride(2), local_value_0573.stride(1), local_value_0573.stride(3), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), D.stride(0) if D is not None else 0, B.stride(0), B.stride(1), B.stride(2), B.stride(3), local_value_0760.stride(0), local_value_0760.stride(1), local_value_0760.stride(2), local_value_0760.stride(3), local_value_0760.stride(4), local_value_0806.stride(0), local_value_0806.stride(1), local_value_0806.stride(2), local_value_0806.stride(3), local_value_0672.stride(0), local_value_0672.stride(2), local_value_0672.stride(1), local_value_0672.stride(3), local_value_0593[1], local_value_0593[2], local_value_0593[3], local_value_0593[0], local_value_0593[4], D is not None, D.dim() == 2 if D is not None else True, HAS_SEQ_IDX=local_value_1339 is not None, BLOCK_SIZE_DSTATE=max(local_value_1655.next_power_of_2(local_value_0759), 16), IS_TRITON_22=local_value_0241)
    if D is not None:
        local_value_0030 = execute_step_0318.best_config.kwargs['BLOCK_SIZE_M']
        local_value_1073 = (local_value_0513 + local_value_0030 - 1) // local_value_0030
        local_value_0589 = local_value_0589[:local_value_1073].sum(dim=(0, 1, 2)).to(dtype=D.dtype)
        if D.dim() == 1:
            local_value_0589 = local_value_1249(local_value_0589, 'h 1 -> h')
    return (local_value_0806, local_value_0672.to(dtype=local_value_0764.dtype), local_value_0589)

def execute_step_0368(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513, D=None, local_value_1753=None, local_value_0767=None, local_value_0970=None, local_value_1339=None, local_value_0794=False, local_value_0776=(0.0, float('inf'))):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
    assert local_value_1090 % local_value_1089 == 0
    assert B.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    assert local_value_1699.shape == (local_value_0434, local_value_1348, local_value_1090, local_value_0925)
    assert local_value_0764.shape == (local_value_0434, local_value_1348, local_value_1090)
    assert local_value_0000.shape == (local_value_1090,)
    assert local_value_0044.shape == B.shape
    if local_value_1753 is not None:
        assert local_value_1753.shape == local_value_1699.shape
    if D is not None:
        assert D.shape == (local_value_1090, local_value_0925) or D.shape == (local_value_1090,)
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    if B.stride(-1) != 1:
        B = B.contiguous()
    if local_value_0044.stride(-1) != 1:
        local_value_0044 = local_value_0044.contiguous()
    if local_value_1699.stride(-1) != 1 and local_value_1699.stride(1) != 1:
        local_value_1699 = local_value_1699.contiguous()
    if local_value_1753 is not None and local_value_1753.stride(-1) != 1 and (local_value_1753.stride(1) != 1):
        local_value_1753 = local_value_1753.contiguous()
    if D is not None and D.stride(-1) != 1:
        D = D.contiguous()
    if local_value_0970 is not None:
        assert local_value_0970.shape == (local_value_0434, local_value_1090, local_value_0925, local_value_0759)
    local_value_0573, local_value_0764 = execute_step_0297(local_value_0764, local_value_0000, local_value_0513, local_value_0767=local_value_0767, local_value_0794=local_value_0794, local_value_0776=local_value_0776)
    local_value_1400 = execute_step_0329(B, local_value_1699, local_value_0764, local_value_0573, local_value_1339=local_value_1339, local_value_1405=True)
    local_value_1400, local_value_0838 = execute_step_0387(local_value_1249(local_value_1400, '... p n -> ... (p n)'), local_value_0573[:, :, :, -1], local_value_0970=local_value_1249(local_value_0970, '... p n -> ... (p n)') if local_value_0970 is not None else None, local_value_1339=local_value_1339, local_value_0513=local_value_0513, local_value_1152=local_value_0044.dtype)
    local_value_1400, local_value_0838 = [local_value_1249(local_value_1618, '... (p n) -> ... p n', n=local_value_0759) for local_value_1618 in [local_value_1400, local_value_0838]]
    local_value_0047 = execute_step_0293(local_value_0044, B, local_value_0513, local_value_1339=local_value_1339, local_value_1175=local_value_1650.float32)
    out, local_value_1166 = execute_step_0319(local_value_0047, local_value_1699, local_value_0764, local_value_0573, local_value_0044, local_value_1400, D=D, local_value_1753=local_value_1753, local_value_1339=local_value_1339)
    return (out, local_value_1166, local_value_0764, local_value_0573, local_value_1400, local_value_0838)

def execute_step_0367(local_value_0723, local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, out, local_value_0513, D=None, local_value_1753=None, local_value_0767=None, local_value_0970=None, local_value_0700=None, local_value_1339=None, local_value_0794=False, local_value_0776=(0.0, float('inf')), local_value_0806=None, local_value_0672=None, local_value_0582=None, local_value_0585=None, local_value_0816=None, local_value_1250=False):
    if local_value_0723.stride(-1) != 1:
        local_value_0723 = local_value_0723.contiguous()
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_1078 = local_value_1039.ceil(local_value_1348 / local_value_0513)
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
    assert local_value_0723.shape == (local_value_0434, local_value_1348, local_value_1090, local_value_0925)
    assert local_value_0764.shape == (local_value_0434, local_value_1348, local_value_1090)
    assert local_value_0000.shape == (local_value_1090,)
    assert local_value_1090 % local_value_1089 == 0
    assert B.shape == (local_value_0434, local_value_1348, local_value_1089, local_value_0759)
    assert local_value_0044.shape == B.shape
    assert out.shape == local_value_1699.shape
    if local_value_0970 is not None:
        assert local_value_0970.shape == (local_value_0434, local_value_1090, local_value_0925, local_value_0759)
    if local_value_1339 is not None:
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    if local_value_0806 is not None:
        assert local_value_0806.shape == local_value_1699.shape
    if local_value_0582 is not None:
        assert local_value_0582.shape == B.shape
        local_value_0583 = local_value_0582
    else:
        local_value_0583 = local_value_1650.empty_like(B)
    if local_value_0585 is not None:
        assert local_value_0585.shape == local_value_0044.shape
        local_value_0587 = local_value_0585
    else:
        local_value_0587 = local_value_1650.empty_like(local_value_0044)
    if local_value_0816 is not None:
        assert local_value_1753 is not None
        assert local_value_0816.shape == local_value_1753.shape
    if local_value_0672 is not None:
        assert local_value_0672.shape == local_value_0764.shape
        local_value_0676 = local_value_0672
    else:
        local_value_0676 = local_value_1650.empty_like(local_value_0764)
    local_value_0771 = local_value_0764.clone()
    local_value_0573, local_value_0764 = execute_step_0297(local_value_0771, local_value_0000, local_value_0513, local_value_0767=local_value_0767, local_value_0794=local_value_0794, local_value_0776=local_value_0776)
    local_value_0047 = execute_step_0293(local_value_0044, B, local_value_0513, local_value_1339=local_value_1339, local_value_1175=local_value_1650.float32)
    local_value_1400 = execute_step_0329(B, local_value_1699, local_value_0764, local_value_0573, local_value_1339=local_value_1339, local_value_1405=True)
    local_value_1400, local_value_0272 = execute_step_0387(local_value_1249(local_value_1400, '... p n -> ... (p n)'), local_value_0573[:, :, :, -1], local_value_0970=local_value_1249(local_value_0970, '... p n -> ... (p n)') if local_value_0970 is not None else None, local_value_1339=local_value_1339, local_value_0513=local_value_0513)
    local_value_1400 = local_value_1249(local_value_1400, '... (p n) -> ... p n', n=local_value_0759)
    if local_value_1753 is not None:
        local_value_0816, local_value_0723, local_value_0589, *local_value_1273 = execute_step_0315(local_value_1699, local_value_1753, out, local_value_0723, local_value_0513=local_value_0513, local_value_0915=False, D=D, local_value_0816=local_value_0816, local_value_1250=local_value_1250)
        local_value_1178 = local_value_1273[0] if local_value_1250 else out
    else:
        local_value_0816 = None
        local_value_1178 = out
    local_value_0760 = execute_step_0311(local_value_0044, local_value_0573, local_value_0723, local_value_1339=local_value_1339, dtype=local_value_1400.dtype)
    local_value_0760, local_value_0654, local_value_0712, local_value_1400 = execute_step_0385(local_value_1249(local_value_1400, '... p n -> ... (p n)'), local_value_0573[:, :, :, -1], local_value_1249(local_value_0760, '... p n -> ... (p n)'), local_value_0700=local_value_1249(local_value_0700, '... p n -> ... (p n)') if local_value_0700 is not None else None, local_value_1339=local_value_1339, local_value_0919=local_value_0970 is not None, local_value_0761=local_value_1699.dtype, local_value_1404=local_value_1699.dtype, local_value_0513=local_value_0513)
    local_value_1400 = local_value_1249(local_value_1400, '... (p n) -> ... p n', n=local_value_0759)
    local_value_0760 = local_value_1249(local_value_0760, '... (p n) -> ... p n', n=local_value_0759)
    local_value_0712 = local_value_1249(local_value_0712, '... (p n) -> ... p n', n=local_value_0759) if local_value_0712 is not None else None
    local_value_0806, local_value_0672, local_value_0590 = execute_step_0317(local_value_1699, local_value_0764, local_value_0573, B, local_value_0047, local_value_0723, local_value_0760, D=D, local_value_1339=local_value_1339, local_value_0806=local_value_0806)
    local_value_0582, local_value_0664 = execute_step_0323(local_value_1699, local_value_0764, local_value_0573, local_value_0760, local_value_1339=local_value_1339, B=B, local_value_1089=local_value_1089)
    local_value_0585, local_value_0659 = execute_step_0299(local_value_1400.to(local_value_1699.dtype), local_value_0573, local_value_0723, local_value_1339=local_value_1339, local_value_0044=local_value_0044, local_value_1089=local_value_1089)
    local_value_0586 = execute_step_0301(local_value_1699, local_value_0764, local_value_0573, local_value_0723, local_value_1339=local_value_1339, local_value_1089=local_value_1089)
    local_value_0586 = local_value_0586.to(local_value_0047.dtype)
    execute_step_0291(local_value_0044, local_value_0586, local_value_1268=local_value_0582, out=local_value_0583)
    execute_step_0291(B, local_value_1249(local_value_0586, '... l s -> ... s l'), local_value_1268=local_value_0585, out=local_value_0587)
    if local_value_1753 is None:
        local_value_0589 = local_value_0590
    local_value_0659[..., -1] += local_value_0654
    local_value_0665 = local_value_0659.flip([-1]).cumsum(dim=-1).flip([-1])
    local_value_0653 = execute_step_0305(local_value_1699, local_value_0764, local_value_0573, local_value_0723, local_value_0047)
    local_value_0653 += local_value_0664 + local_value_0665
    local_value_0676, local_value_0564, local_value_0674 = execute_step_0295(local_value_0653, local_value_0672, local_value_0771, local_value_0000, local_value_0767=local_value_0767, local_value_0794=local_value_0794, local_value_0776=local_value_0776, local_value_0672=local_value_0676)
    local_value_1278 = (local_value_0806, local_value_0676, local_value_0564, local_value_0583, local_value_0587, local_value_0589, local_value_0816, local_value_0674, local_value_0712)
    return local_value_1278 if not local_value_1250 else (*local_value_1278, local_value_1178)

def execute_step_1316(local_value_0723, local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, D=None, local_value_1753=None):
    import state_recurrence as execute_step_1314
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0513 = local_value_0764.shape[-1]
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
    assert local_value_1090 % local_value_1089 == 0
    local_value_1699 = local_value_1249(local_value_1699, 'b l h p -> b (h p) l')
    local_value_1364 = local_value_0764.dim() == 4
    if local_value_0764.dim() == 4:
        local_value_0764 = repeat(local_value_0764, 'b h c l -> b h p c l', p=local_value_0925)
    local_value_0764 = local_value_1249(local_value_0764, 'b h p c l -> b (h p) (c l)', p=local_value_0925)
    local_value_1363 = local_value_0000.dim() == 1
    if local_value_0000.dim() == 1:
        local_value_0000 = repeat(local_value_0000, 'h -> (h p) n', p=local_value_0925, n=local_value_0759).to(dtype=local_value_1650.float32)
    else:
        local_value_0000 = local_value_0000.to(dtype=local_value_1650.float32)
    B = local_value_1249(B, 'b l g n -> b g n l')
    local_value_0044 = local_value_1249(local_value_0044, 'b l g n -> b g n l')
    if D is not None:
        if D.dim() == 2:
            D = local_value_1249(D, 'h p -> (h p)')
        else:
            D = repeat(D, 'h -> (h p)', p=local_value_0925)
    if local_value_1753 is not None:
        local_value_1753 = local_value_1249(local_value_1753, 'b l h p -> b (h p) l')
    if local_value_1699.stride(-1) != 1:
        local_value_1699 = local_value_1699.contiguous()
    if local_value_0764.stride(-1) != 1:
        local_value_0764 = local_value_0764.contiguous()
    if D is not None:
        D = D.contiguous()
    if B.stride(-1) != 1:
        B = B.contiguous()
    if local_value_0044.stride(-1) != 1:
        local_value_0044 = local_value_0044.contiguous()
    if local_value_1753 is not None and local_value_1753.stride(-1) != 1:
        local_value_1753 = local_value_1753.contiguous()
    local_value_0272, local_value_0984, *local_value_1273 = execute_step_1314.fwd(local_value_1699, local_value_0764.to(dtype=local_value_1699.dtype), local_value_0000, B, local_value_0044, D, local_value_1753, None, False)
    if local_value_1753 is not None:
        out = local_value_1273[0]
    else:
        out = None
    local_value_0723 = local_value_1249(local_value_0723, 'b l h p -> b (h p) l')
    if local_value_0723.stride(-1) != 1:
        local_value_0723 = local_value_0723.contiguous()
    local_value_0272, local_value_0672, local_value_0564, *local_value_1273 = execute_step_1314.bwd(local_value_1699, local_value_0764.to(dtype=local_value_1699.dtype), local_value_0000, B, local_value_0044, D, local_value_1753, None, local_value_0723, local_value_0984, out, None, False, False)
    local_value_0672 = local_value_1249(local_value_0672, 'b (h p) (c l) -> b h p c l', p=local_value_0925, l=local_value_0513)
    if local_value_1364:
        local_value_0672 = local_value_0672.float().sum(dim=2)
    if local_value_1363:
        local_value_0564 = local_value_1249(local_value_0564, '(h p) n -> h p n', p=local_value_0925).sum(dim=(1, 2))
    return (local_value_0672, local_value_0564)

class ComponentUnit0182(local_value_1650.autograd.Function):

    @staticmethod
    def forward(local_value_0551, local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513, D=None, local_value_1753=None, local_value_0767=None, local_value_0970=None, local_value_1339=None, local_value_0794=False, local_value_0776=(0.0, float('inf')), local_value_1276=False):
        local_value_0551.member_slot_0256 = local_value_0764.dtype
        out, local_value_1166, local_value_0781, local_value_0573, local_value_1400, local_value_0838 = execute_step_0368(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513, D=D, local_value_1753=local_value_1753, local_value_0767=local_value_0767, local_value_0970=local_value_0970, local_value_1339=local_value_1339, local_value_0794=local_value_0794, local_value_0776=local_value_0776)
        local_value_0551.save_for_backward(out if local_value_1753 is None else local_value_1166, local_value_1699, local_value_0764, local_value_0573, local_value_0000, B, local_value_0044, D, local_value_1753, local_value_0767, local_value_0970, local_value_1339)
        local_value_0551.local_value_0794 = local_value_0794
        local_value_0551.local_value_0513 = local_value_0513
        local_value_0551.local_value_0776 = local_value_0776
        local_value_0551.local_value_1276 = local_value_1276
        return out if not local_value_1276 else (out, local_value_0838)

    @staticmethod
    def backward(local_value_0551, local_value_0723, *local_value_0416):
        out, local_value_1699, local_value_0764, local_value_0573, local_value_0000, B, local_value_0044, D, local_value_1753, local_value_0767, local_value_0970, local_value_1339 = local_value_0551.saved_tensors
        local_value_0700 = local_value_0416[0] if local_value_0551.local_value_1276 else None
        local_value_0806, local_value_0672, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0816, local_value_0674, local_value_0712 = execute_step_0367(local_value_0723, local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, out, local_value_0551.local_value_0513, D=D, local_value_1753=local_value_1753, local_value_0767=local_value_0767, local_value_0970=local_value_0970, local_value_0700=local_value_0700, local_value_1339=local_value_1339, local_value_0794=local_value_0551.local_value_0794, local_value_0776=local_value_0551.local_value_0776)
        return (local_value_0806, local_value_0672, local_value_0564, local_value_0582, local_value_0585, None, local_value_0589, local_value_0816, local_value_0674, local_value_0712, None, None, None, None)

def execute_step_1030(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513, D=None, local_value_1753=None, local_value_0767=None, local_value_0970=None, local_value_1339=None, local_value_0794=False, local_value_0776=(0.0, float('inf')), local_value_1276=False):
    return ComponentUnit0182.apply(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513, D, local_value_1753, local_value_0767, local_value_0970, local_value_1339, local_value_0794, local_value_0776, local_value_1276)

def execute_step_1029(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513, D=None, local_value_1753=None, local_value_0767=None, local_value_0794=False):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0759 = B.shape[-1]
    if local_value_1348 % local_value_0513 != 0:
        local_value_0764 = local_value_0117.pad(local_value_0764, (0, 0, 0, local_value_0513 - local_value_1348 % local_value_0513))
    local_value_0764 = local_value_1249(local_value_0764, 'b (c l) h -> b h c l', l=local_value_0513)
    local_value_0764 = local_value_0764.float()
    if local_value_0767 is not None:
        local_value_0764 = local_value_0764 + local_value_1249(local_value_0767, 'h -> h 1 1')
    if local_value_0794:
        local_value_0764 = local_value_0117.softplus(local_value_0764)
    local_value_0564 = local_value_0764 * local_value_1249(local_value_0000, 'h -> h 1 1')
    local_value_0564 = local_value_0764 * local_value_1249(local_value_0000, 'h -> h 1 1')
    local_value_0573 = local_value_1650.cumsum(local_value_0564, dim=-1)
    local_value_1400 = execute_step_0516(B, local_value_1699, local_value_0764, local_value_0573, local_value_1405=True)
    local_value_1400 = local_value_1249(execute_step_1395(local_value_1249(local_value_1400, '... p n -> ... (p n)'), local_value_0573[:, :, :, -1])[0], '... (p n) -> ... p n', n=local_value_0759)
    out = execute_step_0511(B, local_value_0044, local_value_1699, local_value_0764, local_value_0573, local_value_1400, D=D, local_value_1753=local_value_1753)
    return out

def execute_step_1374(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513, D=None, local_value_1753=None, local_value_0767=None, local_value_0794=False):
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0759 = B.shape[-1]
    if local_value_1348 % local_value_0513 != 0:
        local_value_0764 = local_value_0117.pad(local_value_0764, (0, 0, 0, local_value_0513 - local_value_1348 % local_value_0513))
    local_value_0764 = local_value_1249(local_value_0764, 'b (c l) h -> b h c l', l=local_value_0513)
    local_value_0764 = local_value_0764.float()
    if local_value_0767 is not None:
        local_value_0764 = local_value_0764 + local_value_1249(local_value_0767, 'h -> h 1 1')
    if local_value_0794:
        local_value_0764 = local_value_0117.softplus(local_value_0764)
    local_value_0564 = local_value_0764 * local_value_1249(local_value_0000, 'h -> h 1 1')
    local_value_0573 = local_value_1650.cumsum(local_value_0564, dim=-1)
    local_value_1400 = execute_step_0517(B, local_value_1699, local_value_0764, local_value_0573)
    local_value_1404 = local_value_1400.dtype
    if local_value_1400.dtype not in [local_value_1650.float32, local_value_1650.float64]:
        local_value_1400 = local_value_1400.to(local_value_1650.float32)
    local_value_1400 = local_value_1249(execute_step_1396(local_value_1249(local_value_1400, '... p n -> ... (p n)'), local_value_0573[:, :, :, -1])[0], '... (p n) -> ... p n', n=local_value_0759)
    local_value_1400 = local_value_1400.to(local_value_1404)
    out = execute_step_0512(B, local_value_0044, local_value_1699, local_value_0764, local_value_0573, local_value_1400, D=D, local_value_1753=local_value_1753)
    return out

def execute_step_1376(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, local_value_0767=None, local_value_0794=False, local_value_0776=(0.0, float('inf'))):
    from mamba_ssm.ops.selective_scan_interface import selective_scan_fn as execute_step_1330
    local_value_0434, local_value_1348, local_value_1090, local_value_0925 = local_value_1699.shape
    local_value_0272, local_value_0272, local_value_1089, local_value_0759 = B.shape
    local_value_1699 = local_value_1249(local_value_1699, 'b l h p -> b (h p) l')
    if local_value_0764.dim() == 3:
        local_value_0764 = repeat(local_value_0764, 'b l h -> b l h p', p=local_value_0925)
    local_value_0764 = local_value_1249(local_value_0764, 'b l h p -> b (h p) l')
    if local_value_0000.dim() == 1:
        local_value_0000 = repeat(local_value_0000, 'h -> (h p) n', p=local_value_0925, n=local_value_0759).to(dtype=local_value_1650.float32)
    else:
        local_value_0000 = local_value_0000.to(dtype=local_value_1650.float32)
    B = local_value_1249(B, 'b l g n -> b g n l')
    local_value_0044 = local_value_1249(local_value_0044, 'b l g n -> b g n l')
    if D is not None:
        if D.dim() == 2:
            D = local_value_1249(D, 'h p -> (h p)')
        else:
            D = repeat(D, 'h -> (h p)', p=local_value_0925)
    if local_value_1753 is not None:
        local_value_1753 = local_value_1249(local_value_1753, 'b l h p -> b (h p) l')
    if local_value_0767 is not None:
        if local_value_0767.dim() == 1:
            local_value_0767 = repeat(local_value_0767, 'h -> h p', p=local_value_0925)
        local_value_0767 = local_value_1249(local_value_0767, 'h p -> (h p)')
    if local_value_0776 != (0.0, float('inf')):
        if local_value_0767 is not None:
            local_value_0764 = local_value_0764 + local_value_1249(local_value_0767, 'd -> d 1')
        if local_value_0794:
            local_value_0764 = local_value_0117.softplus(local_value_0764)
        local_value_0764 = local_value_0764.clamp(min=local_value_0776[0], max=local_value_0776[1]).to(local_value_1699.dtype)
        local_value_0767 = None
        local_value_0794 = None
    out = execute_step_1330(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, D=D, local_value_1753=local_value_1753, delta_bias=local_value_0767, local_value_0696=local_value_0794)
    return local_value_1249(out, 'b (h p) l -> b l h p', p=local_value_0925)

def execute_step_1032(local_value_1705, local_value_0533, local_value_0532, local_value_0764, local_value_0000, local_value_0513, D=None, local_value_1753=None, local_value_0767=None, local_value_0794=False, local_value_0776=(0.0, float('inf')), activation='silu', local_value_0925=None, local_value_1089=1):
    local_value_0434, local_value_1348, local_value_1090 = local_value_0764.shape[:3]
    assert local_value_1090 % local_value_1089 == 0
    if local_value_1753 is not None:
        dim = local_value_1753.shape[-1]
        assert dim % local_value_1090 == 0
        local_value_0925 = dim // local_value_1090
    else:
        if D.dim() == 1:
            assert local_value_0925 is not None
        else:
            local_value_0925 = D.shape[1]
        dim = local_value_1090 * local_value_0925
    local_value_1705 = local_value_1249(local_value_0481(local_value_1249(local_value_1705, 'b s d -> b d s'), local_value_0533, local_value_0532, activation=activation), 'b d s -> b s d')
    local_value_0759 = (local_value_1705.shape[-1] - dim) // local_value_1089 // 2
    local_value_1699, B, local_value_0044 = local_value_1650.split(local_value_1705, [dim, local_value_1089 * local_value_0759, local_value_1089 * local_value_0759], dim=-1)
    local_value_1699 = local_value_1249(local_value_1699, 'b l (h p) -> b l h p', h=local_value_1090)
    B = local_value_1249(B, 'b l (g n) -> b l g n', g=local_value_1089)
    local_value_0044 = local_value_1249(local_value_0044, 'b l (g n) -> b l g n', g=local_value_1089)
    local_value_1753 = local_value_1249(local_value_1753, 'b l (h p) -> b l h p', h=local_value_1090) if local_value_1753 is not None else None
    out = execute_step_1376(local_value_1699, local_value_0764.to(local_value_1699.dtype), local_value_0000, B, local_value_0044, D=D.float(), local_value_1753=local_value_1753, local_value_0767=local_value_0767, local_value_0794=local_value_0794, local_value_0776=local_value_0776)
    return local_value_1249(out, 'b s h p -> b s (h p)')

class ComponentUnit0183(local_value_1650.autograd.Function):

    @staticmethod
    @local_value_0559
    def forward(local_value_0551, local_value_1761, local_value_0533, local_value_0532, local_value_0767, local_value_0000, D, local_value_0513, local_value_0970=None, local_value_1339=None, local_value_0776=(0.0, float('inf')), local_value_1276=False, activation='silu', local_value_1285=None, local_value_1283=1e-06, local_value_1173=None, local_value_1172=None, local_value_0925=None, local_value_1089=1, local_value_1099=True):
        assert activation in [None, 'silu', 'swish']
        if D.dim() == 1:
            assert local_value_0925 is not None
            local_value_1090, = D.shape
        else:
            local_value_1090, local_value_0925 = D.shape
        local_value_0434, local_value_1348, local_value_0272 = local_value_1761.shape
        dim = local_value_1090 * local_value_0925
        assert local_value_1090 % local_value_1089 == 0
        local_value_0759 = (local_value_0533.shape[0] - dim) // local_value_1089 // 2
        local_value_0616 = (local_value_1761.shape[-1] - 2 * dim - 2 * local_value_1089 * local_value_0759 - local_value_1090) // 2
        assert local_value_0616 >= 0
        assert local_value_1761.shape == (local_value_0434, local_value_1348, 2 * local_value_0616 + 2 * dim + 2 * local_value_1089 * local_value_0759 + local_value_1090)
        assert local_value_0767.shape == (local_value_1090,)
        assert local_value_0000.shape == (local_value_1090,)
        local_value_1760, local_value_1753, local_value_1705, local_value_0764 = local_value_1650.split(local_value_1761, [2 * local_value_0616, dim, dim + local_value_1089 * local_value_0759 * 2, local_value_1090], dim=-1)
        local_value_1339 = local_value_1339.contiguous() if local_value_1339 is not None else None
        local_value_1706 = local_value_1249(local_value_0480.causal_conv1d_fwd(local_value_1249(local_value_1705, 'b s d -> b d s'), local_value_0533, local_value_0532, local_value_1339, None, None, activation in ['silu', 'swish']), 'b d s -> b s d')
        local_value_1699, B, local_value_0044 = local_value_1650.split(local_value_1706, [dim, local_value_1089 * local_value_0759, local_value_1089 * local_value_0759], dim=-1)
        local_value_1699 = local_value_1249(local_value_1699, 'b l (h p) -> b l h p', h=local_value_1090)
        B = local_value_1249(B, 'b l (g n) -> b l g n', g=local_value_1089)
        local_value_0044 = local_value_1249(local_value_0044, 'b l (g n) -> b l g n', g=local_value_1089)
        local_value_1753 = local_value_1249(local_value_1753, 'b l (h p) -> b l h p', h=local_value_1090) if local_value_1753 is not None else None
        if local_value_1285 is None:
            out, local_value_1166, local_value_0781, local_value_0573, local_value_1400, local_value_0838 = execute_step_0368(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513=local_value_0513, D=D, local_value_1753=local_value_1753, local_value_0767=local_value_0767, local_value_0970=local_value_0970, local_value_1339=local_value_1339, local_value_0794=True, local_value_0776=local_value_0776)
            out = local_value_1249(out, 'b s h p -> b s (h p)')
            local_value_1294 = None
            if local_value_0616 > 0:
                out = local_value_1650.cat([execute_step_0391(local_value_1760), out], dim=-1)
        else:
            local_value_1166, local_value_0272, local_value_0781, local_value_0573, local_value_1400, local_value_0838 = execute_step_0368(local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, local_value_0513=local_value_0513, D=D, local_value_1753=None, local_value_0767=local_value_0767, local_value_0970=local_value_0970, local_value_1339=local_value_1339, local_value_0794=True, local_value_0776=local_value_0776)
            local_value_1724 = local_value_1249(local_value_1166, 'b s h p -> (b s) (h p)')
            local_value_1757 = local_value_1249(local_value_1753, 'b s h p -> (b s) (h p)')
            local_value_1285 = local_value_1285.contiguous()
            if local_value_0616 == 0:
                out = None
            else:
                local_value_1138 = local_value_1650.empty((local_value_0434, local_value_1348, local_value_0616 + dim), dtype=local_value_1724.dtype, device=local_value_1724.device)
                out = local_value_1249(local_value_1138[..., local_value_0616:], 'b s d -> (b s) d')
                execute_step_0391(local_value_1760, out=local_value_1138[..., :local_value_0616])
            out, local_value_0272, local_value_1294 = execute_step_0357(local_value_1724, local_value_1285, None, local_value_1283, local_value_1757, out=out, local_value_0910=dim // local_value_1089, local_value_1099=local_value_1099, local_value_0992=True)
            if local_value_0616 == 0:
                out = local_value_1249(out, '(b s) d -> b s d', b=local_value_0434)
            else:
                out = local_value_1138
        local_value_0551.member_slot_0382 = local_value_1173.dtype if local_value_1173 is not None else None
        if local_value_1173 is not None:
            if local_value_1650.is_autocast_enabled():
                dtype = local_value_1650.get_autocast_gpu_dtype()
                out, local_value_1173 = (out.to(dtype), local_value_1173.to(dtype))
                local_value_1172 = local_value_1172.to(dtype) if local_value_1172 is not None else None
            out = local_value_0117.linear(out, local_value_1173, local_value_1172)
        else:
            assert local_value_1172 is None
        local_value_0551.save_for_backward(local_value_1761, local_value_0533, local_value_0532, local_value_1166, local_value_0000, D, local_value_0767, local_value_0970, local_value_1339, local_value_1285, local_value_1294, local_value_1173, local_value_1172)
        local_value_0551.local_value_0776 = local_value_0776
        local_value_0551.local_value_1276 = local_value_1276
        local_value_0551.activation = activation
        local_value_0551.local_value_1283 = local_value_1283
        local_value_0551.local_value_1099 = local_value_1099
        local_value_0551.local_value_0513 = local_value_0513
        local_value_0551.local_value_0925 = local_value_0925
        local_value_0551.local_value_1089 = local_value_1089
        return out if not local_value_1276 else (out, local_value_0838)

    @staticmethod
    @local_value_0558
    def backward(local_value_0551, local_value_0723, *local_value_0416):
        local_value_1761, local_value_0533, local_value_0532, out, local_value_0000, D, local_value_0767, local_value_0970, local_value_1339, local_value_1285, local_value_1294, local_value_1173, local_value_1172 = local_value_0551.saved_tensors
        local_value_0700 = local_value_0416[0] if local_value_0551.local_value_1276 else None
        local_value_0925 = local_value_0551.local_value_0925
        local_value_1090 = D.shape[0]
        dim = local_value_1090 * local_value_0925
        assert local_value_1090 % local_value_0551.local_value_1089 == 0
        local_value_0759 = (local_value_0533.shape[0] - dim) // local_value_0551.local_value_1089 // 2
        local_value_0616 = (local_value_1761.shape[-1] - 2 * dim - 2 * local_value_0551.local_value_1089 * local_value_0759 - local_value_1090) // 2
        assert local_value_0616 >= 0
        local_value_1250 = local_value_1173 is not None
        if local_value_1250:
            local_value_1164 = local_value_1650.empty(*out.shape[:2], local_value_0616 + dim, device=out.device, dtype=out.dtype)
            local_value_1139, local_value_1141 = local_value_1164.split([local_value_0616, dim], dim=-1)
        local_value_1760, local_value_1753, local_value_1705, local_value_0764 = local_value_1650.split(local_value_1761, [2 * local_value_0616, dim, dim + 2 * local_value_0551.local_value_1089 * local_value_0759, local_value_1090], dim=-1)
        local_value_1706 = local_value_1249(local_value_0480.causal_conv1d_fwd(local_value_1249(local_value_1705, 'b s d -> b d s'), local_value_0533, local_value_0532, local_value_1339, None, None, local_value_0551.activation in ['silu', 'swish']), 'b d s -> b s d')
        local_value_1699, B, local_value_0044 = local_value_1650.split(local_value_1706, [dim, local_value_0551.local_value_1089 * local_value_0759, local_value_0551.local_value_1089 * local_value_0759], dim=-1)
        local_value_1699 = local_value_1249(local_value_1699, 'b l (h p) -> b l h p', h=local_value_1090)
        B = local_value_1249(B, 'b l (g n) -> b l g n', g=local_value_0551.local_value_1089)
        local_value_0044 = local_value_1249(local_value_0044, 'b l (g n) -> b l g n', g=local_value_0551.local_value_1089)
        local_value_0820 = local_value_1650.empty_like(local_value_1761)
        local_value_0819, local_value_0816, local_value_0809, local_value_0676 = local_value_1650.split(local_value_0820, [2 * local_value_0616, dim, dim + 2 * local_value_0551.local_value_1089 * local_value_0759, local_value_1090], dim=-1)
        local_value_0808 = local_value_1650.empty_like(local_value_1705)
        local_value_0806, local_value_0582, local_value_0585 = local_value_1650.split(local_value_0808, [dim, local_value_0551.local_value_1089 * local_value_0759, local_value_0551.local_value_1089 * local_value_0759], dim=-1)
        local_value_1753 = local_value_1249(local_value_1753, 'b l (h p) -> b l h p', h=local_value_1090)
        local_value_0806 = local_value_1249(local_value_0806, 'b l (h p) -> b l h p', h=local_value_1090)
        local_value_0582 = local_value_1249(local_value_0582, 'b l (g n) -> b l g n', g=local_value_0551.local_value_1089)
        local_value_0585 = local_value_1249(local_value_0585, 'b l (g n) -> b l g n', g=local_value_0551.local_value_1089)
        if local_value_1173 is not None:
            local_value_0725 = local_value_0723
            local_value_0723 = local_value_0117.linear(local_value_0723, local_value_1173.t())
        if local_value_0616 > 0:
            local_value_0724, local_value_0723 = local_value_0723.split([local_value_0616, dim], dim=-1)
            execute_step_0389(local_value_1760, local_value_0724, local_value_0812=local_value_0819, local_value_1250=True, out=local_value_1139)
        local_value_0723 = local_value_1249(local_value_0723, 'b s (h p) -> b s h p', p=local_value_0925)
        if local_value_1285 is None:
            local_value_0816 = local_value_1249(local_value_0816, 'b l (h p) -> b l h p', h=local_value_1090)
            local_value_0806, local_value_0672, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0816, local_value_0674, local_value_0712, *local_value_1273 = execute_step_0367(local_value_0723, local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, out, local_value_0551.local_value_0513, D=D, local_value_1753=local_value_1753, local_value_0767=local_value_0767, local_value_0970=local_value_0970, local_value_0700=local_value_0700, local_value_1339=local_value_1339, local_value_0794=True, local_value_0776=local_value_0551.local_value_0776, local_value_0806=local_value_0806, local_value_0672=local_value_0676, local_value_0582=local_value_0582, local_value_0585=local_value_0585, local_value_0816=local_value_0816, local_value_1250=local_value_1250)
            local_value_1154 = local_value_1249(local_value_1273[0], 'b s h p -> b s (h p)') if local_value_1250 else None
            local_value_0750 = None
        else:
            local_value_0434 = local_value_0723.shape[0]
            local_value_0815 = local_value_1249(local_value_0723, 'b s h p -> (b s) (h p)')
            local_value_0816 = local_value_1249(local_value_0816, 'b l d -> (b l) d')
            local_value_1724 = local_value_1249(out, 'b s h p -> (b s) (h p)')
            local_value_1757 = local_value_1249(local_value_1753, 'b s h p -> (b s) (h p)')
            local_value_1141 = local_value_1249(local_value_1141, 'b s d -> (b s) d') if local_value_1250 else None
            local_value_0723, local_value_0750, local_value_0272, local_value_0816, *local_value_1273 = execute_step_0355(local_value_0815, local_value_1724, local_value_1285, None, local_value_0551.local_value_1283, None, local_value_1294, local_value_1757, local_value_1099=local_value_0551.local_value_1099, local_value_0992=True, local_value_1250=local_value_1250, local_value_0816=local_value_0816, out=local_value_1141 if local_value_1250 else None)
            local_value_1154 = local_value_1164 if local_value_1250 else None
            local_value_0723 = local_value_1249(local_value_0723, '(b s) (h p) -> b s h p', b=local_value_0434, p=local_value_0925)
            local_value_0806, local_value_0672, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0272, local_value_0674, local_value_0712 = execute_step_0367(local_value_0723, local_value_1699, local_value_0764, local_value_0000, B, local_value_0044, out, local_value_0551.local_value_0513, D=D, local_value_1753=None, local_value_0767=local_value_0767, local_value_0970=local_value_0970, local_value_0700=local_value_0700, local_value_1339=local_value_1339, local_value_0794=True, local_value_0776=local_value_0551.local_value_0776, local_value_0806=local_value_0806, local_value_0672=local_value_0676, local_value_0582=local_value_0582, local_value_0585=local_value_0585)
        if local_value_1173 is not None:
            local_value_0734 = local_value_1650.einsum('bso,bsd->od', local_value_0725, local_value_1154)
            local_value_0733 = local_value_0725.sum(dim=(0, 1)) if local_value_1172 is not None else None
        else:
            local_value_0734, local_value_0733 = (None, None)
        local_value_0809 = local_value_1249(local_value_0809, 'b s d -> b d s')
        local_value_0809, local_value_0805, local_value_0645, *local_value_0272 = local_value_0480.causal_conv1d_bwd(local_value_1249(local_value_1705, 'b s d -> b d s'), local_value_0533, local_value_0532, local_value_1249(local_value_0808, 'b s d -> b d s'), local_value_1339, None, None, local_value_0809, False, local_value_0551.activation in ['silu', 'swish'])
        local_value_0809 = local_value_1249(local_value_0809, 'b d s -> b s d')
        return (local_value_0820, local_value_0805, local_value_0645, local_value_0674, local_value_0564, local_value_0589, None, local_value_0712, None, None, None, None, local_value_0750, None, local_value_0734, local_value_0733, None, None, None)

def execute_step_1034(local_value_1761, local_value_0533, local_value_0532, local_value_0767, local_value_0000, D, local_value_0513, local_value_0970=None, local_value_1339=None, local_value_0776=(0.0, float('inf')), local_value_1276=False, activation='silu', local_value_1285=None, local_value_1283=1e-06, local_value_1173=None, local_value_1172=None, local_value_0925=None, local_value_1089=1, local_value_1099=True):
    return ComponentUnit0183.apply(local_value_1761, local_value_0533, local_value_0532, local_value_0767, local_value_0000, D, local_value_0513, local_value_0970, local_value_1339, local_value_0776, local_value_1276, activation, local_value_1285, local_value_1283, local_value_1173, local_value_1172, local_value_0925, local_value_1089, local_value_1099)

def execute_step_1035(local_value_1761, local_value_0533, local_value_0532, local_value_0767, local_value_0000, D, local_value_0513, local_value_0776=(0.0, float('inf')), activation='silu', local_value_1285=None, local_value_1283=1e-06, local_value_1173=None, local_value_1172=None, local_value_0925=None, local_value_1089=1, local_value_1099=True):
    if D.dim() == 1:
        assert local_value_0925 is not None
        local_value_1090, = D.shape
    else:
        local_value_1090, local_value_0925 = D.shape
    assert local_value_1090 % local_value_1089 == 0
    local_value_0434, local_value_1348, local_value_0272 = local_value_1761.shape
    dim = local_value_1090 * local_value_0925
    local_value_0759 = (local_value_1761.shape[-1] - 2 * dim - local_value_1090) // local_value_1089 // 2
    assert local_value_1761.shape == (local_value_0434, local_value_1348, 2 * dim + 2 * local_value_1089 * local_value_0759 + local_value_1090)
    assert local_value_0767.shape == (local_value_1090,)
    assert local_value_0000.shape == (local_value_1090,)
    if local_value_1285 is not None:
        assert local_value_1285.shape == (dim,)
    local_value_1753, local_value_1705, local_value_0764 = local_value_1650.split(local_value_1761, [dim, dim + 2 * local_value_1089 * local_value_0759, local_value_1090], dim=-1)
    local_value_1705 = local_value_1249(local_value_0481(local_value_1249(local_value_1705, 'b s d -> b d s'), local_value_0533, local_value_0532, activation=activation), 'b d s -> b s d')
    local_value_1699, B, local_value_0044 = local_value_1650.split(local_value_1705, [dim, local_value_1089 * local_value_0759, local_value_1089 * local_value_0759], dim=-1)
    local_value_1699 = local_value_1249(local_value_1699, 'b l (h p) -> b l h p', h=local_value_1090)
    B = local_value_1249(B, 'b l (g n) -> b l g n', g=local_value_1089)
    local_value_0044 = local_value_1249(local_value_0044, 'b l (g n) -> b l g n', g=local_value_1089)
    local_value_1753 = local_value_1249(local_value_1753, 'b l (h p) -> b l h p', h=local_value_1090)
    out = execute_step_1376(local_value_1699, local_value_0764.to(local_value_1699.dtype), local_value_0000, B, local_value_0044, D=D.float(), local_value_1753=local_value_1753 if local_value_1285 is None else None, local_value_0767=local_value_0767, local_value_0794=True, local_value_0776=local_value_0776)
    out = local_value_1249(out, 'b s h p -> b s (h p)')
    if local_value_1285 is not None:
        out = execute_step_1284(out, local_value_1285, None, local_value_1753=local_value_1249(local_value_1753, 'b l h p -> b l (h p)'), eps=local_value_1283, local_value_1099=local_value_1099)
    if local_value_1173 is not None:
        out = local_value_0117.linear(out, local_value_1173, local_value_1172)
    return out
