import math as local_value_1039
import torch as local_value_1650
import torch.nn.functional as local_value_0117
import triton as local_value_1655
import triton.language as local_value_1631
from einops import rearrange as local_value_1249, repeat

@local_value_1655.autotune(configs=[local_value_1655.Config({'local_value_0020': 64}), local_value_1655.Config({'local_value_0020': 128}), local_value_1655.Config({'local_value_0020': 256}), local_value_1655.Config({'local_value_0020': 512}), local_value_1655.Config({'local_value_0020': 1024}), local_value_1655.Config({'local_value_0020': 2048})], key=['dim'])
@local_value_1655.jit
def execute_step_0388(local_value_1406, local_value_1162, local_value_0839, local_value_0571, local_value_0972, local_value_1346, dim, local_value_1078, local_value_1348, local_value_0513, local_value_1592, local_value_1593, local_value_1597, local_value_1594, local_value_1562, local_value_1563, local_value_1566, local_value_1564, local_value_1556, local_value_1558, local_value_1557, local_value_1444, local_value_1445, local_value_1447, local_value_1559, local_value_1561, local_value_1560, local_value_1586, local_value_1587, HAS_INITSTATES: local_value_1631.constexpr, HAS_SEQ_IDX: local_value_1631.constexpr, local_value_0020: local_value_1631.constexpr):
    local_value_1204 = local_value_1631.program_id(axis=1)
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1210 = local_value_1631.program_id(axis=0)
    local_value_1406 += local_value_1204 * local_value_1592 + local_value_1209 * local_value_1597
    local_value_0571 += local_value_1204 * local_value_1444 + local_value_1209 * local_value_1447
    local_value_1162 += local_value_1204 * local_value_1562 + local_value_1209 * local_value_1566
    local_value_0839 += local_value_1204 * local_value_1556 + local_value_1209 * local_value_1558
    if HAS_INITSTATES:
        local_value_0972 += local_value_1204 * local_value_1559 + local_value_1209 * local_value_1561
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586
    local_value_1123 = local_value_1210 * local_value_0020 + local_value_1631.arange(0, local_value_0020)
    local_value_1407 = local_value_1406 + local_value_1123 * local_value_1594
    local_value_1163 = local_value_1162 + local_value_1123 * local_value_1564
    local_value_0840 = local_value_0839 + local_value_1123 * local_value_1557
    if not HAS_INITSTATES:
        local_value_1400 = local_value_1631.zeros((local_value_0020,), dtype=local_value_1631.float32)
    else:
        local_value_0973 = local_value_0972 + local_value_1123 * local_value_1560
        local_value_1400 = local_value_1631.load(local_value_0973, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
    local_value_1631.store(local_value_1163, local_value_1400, mask=local_value_1123 < dim)
    local_value_1163 += local_value_1563
    local_value_1339 = 0
    for c in range(local_value_1078):
        local_value_1083 = local_value_1631.load(local_value_1407, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
        local_value_0566 = local_value_1631.load(local_value_0571).to(local_value_1631.float32)
        local_value_1302 = local_value_1631.exp(local_value_0566)
        if HAS_SEQ_IDX:
            local_value_1344 = local_value_1631.load(local_value_1346 + (min((c + 1) * local_value_0513, local_value_1348) - 1) * local_value_1587)
            local_value_1302 = local_value_1631.where(local_value_1344 == local_value_1339, local_value_1302, 0.0)
            local_value_1339 = local_value_1344
        local_value_1400 = local_value_1302 * local_value_1400 + local_value_1083
        if c < local_value_1078 - 1:
            local_value_1631.store(local_value_1163, local_value_1400, mask=local_value_1123 < dim)
        else:
            local_value_1631.store(local_value_0840, local_value_1400, mask=local_value_1123 < dim)
        local_value_1407 += local_value_1593
        local_value_0571 += local_value_1445
        local_value_1163 += local_value_1563

@local_value_1655.autotune(configs=[local_value_1655.Config({'local_value_0020': 64}), local_value_1655.Config({'local_value_0020': 128}), local_value_1655.Config({'local_value_0020': 256}), local_value_1655.Config({'local_value_0020': 512}), local_value_1655.Config({'local_value_0020': 1024}), local_value_1655.Config({'local_value_0020': 2048})], key=['dim'])
@local_value_1655.jit
def execute_step_0386(local_value_0726, local_value_1162, local_value_0571, local_value_0701, local_value_1346, local_value_0762, local_value_0657, local_value_0714, local_value_1402, dim, local_value_1078, local_value_1348, local_value_0513, local_value_1504, local_value_1505, local_value_1510, local_value_1508, local_value_1562, local_value_1563, local_value_1566, local_value_1564, local_value_1444, local_value_1445, local_value_1447, local_value_1498, local_value_1500, local_value_1499, local_value_1586, local_value_1587, local_value_1524, local_value_1525, local_value_1529, local_value_1526, local_value_1475, local_value_1476, local_value_1480, local_value_1501, local_value_1503, local_value_1502, CONVERT_STATES: local_value_1631.constexpr, HAS_DFINAL_STATES: local_value_1631.constexpr, HAS_DINITSTATES: local_value_1631.constexpr, HAS_SEQ_IDX: local_value_1631.constexpr, local_value_0020: local_value_1631.constexpr):
    local_value_1204 = local_value_1631.program_id(axis=1)
    local_value_1209 = local_value_1631.program_id(axis=2)
    local_value_1210 = local_value_1631.program_id(axis=0)
    local_value_0762 += local_value_1204 * local_value_1524 + local_value_1209 * local_value_1529 + (local_value_1078 - 1) * local_value_1525
    local_value_0571 += local_value_1204 * local_value_1444 + local_value_1209 * local_value_1447 + (local_value_1078 - 1) * local_value_1445
    local_value_0657 += local_value_1204 * local_value_1475 + local_value_1209 * local_value_1480 + (local_value_1078 - 1) * local_value_1476 + local_value_1210
    local_value_1162 += local_value_1204 * local_value_1562 + local_value_1209 * local_value_1566 + (local_value_1078 - 1) * local_value_1563
    local_value_0726 += local_value_1204 * local_value_1504 + local_value_1209 * local_value_1510 + (local_value_1078 - 1) * local_value_1505
    if CONVERT_STATES:
        local_value_1402 += local_value_1204 * local_value_1562 + local_value_1209 * local_value_1566 + (local_value_1078 - 1) * local_value_1563
    if HAS_DFINAL_STATES:
        local_value_0701 += local_value_1204 * local_value_1498 + local_value_1209 * local_value_1500
    if HAS_DINITSTATES:
        local_value_0714 += local_value_1204 * local_value_1501 + local_value_1209 * local_value_1503
    if HAS_SEQ_IDX:
        local_value_1346 += local_value_1204 * local_value_1586
    local_value_1123 = local_value_1210 * local_value_0020 + local_value_1631.arange(0, local_value_0020)
    local_value_0763 = local_value_0762 + local_value_1123 * local_value_1526
    local_value_1163 = local_value_1162 + local_value_1123 * local_value_1564
    local_value_0727 = local_value_0726 + local_value_1123 * local_value_1508
    if CONVERT_STATES:
        local_value_1403 = local_value_1402 + local_value_1123 * local_value_1564
    if HAS_DFINAL_STATES:
        local_value_0760 = local_value_1631.load(local_value_0701 + local_value_1123 * local_value_1499, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
    else:
        local_value_0760 = local_value_1631.zeros((local_value_0020,), dtype=local_value_1631.float32)
    local_value_1631.store(local_value_0763, local_value_0760, mask=local_value_1123 < dim)
    if HAS_SEQ_IDX:
        local_value_1339 = local_value_1631.load(local_value_1346 + (local_value_1348 - 1) * local_value_1587)
    local_value_0763 -= local_value_1525
    for c in range(local_value_1078 - 1):
        local_value_0566 = local_value_1631.load(local_value_0571).to(local_value_1631.float32)
        local_value_1302 = local_value_1631.exp(local_value_0566)
        if HAS_SEQ_IDX:
            local_value_1344 = local_value_1631.load(local_value_1346 + ((local_value_1078 - c - 1) * local_value_0513 - 1) * local_value_1587)
            local_value_1302 = local_value_1631.where(local_value_1344 == local_value_1339, local_value_1302, 0.0)
            local_value_1339 = local_value_1344
        out = local_value_1631.load(local_value_1163, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
        if CONVERT_STATES:
            local_value_1631.store(local_value_1403, out, mask=local_value_1123 < dim)
        local_value_0653 = local_value_1631.sum(out * local_value_0760) * local_value_1302
        local_value_1631.store(local_value_0657, local_value_0653)
        local_value_0723 = local_value_1631.load(local_value_0727, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
        local_value_0760 = local_value_1302 * local_value_0760 + local_value_0723
        local_value_1631.store(local_value_0763, local_value_0760, mask=local_value_1123 < dim)
        local_value_0727 -= local_value_1505
        local_value_0763 -= local_value_1525
        local_value_0571 -= local_value_1445
        local_value_0657 -= local_value_1476
        local_value_1163 -= local_value_1563
        if CONVERT_STATES:
            local_value_1403 -= local_value_1563
    if CONVERT_STATES:
        out = local_value_1631.load(local_value_1163, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
        local_value_1631.store(local_value_1403, out, mask=local_value_1123 < dim)
    if not HAS_DINITSTATES:
        local_value_1631.store(local_value_0657, 0.0)
    else:
        local_value_0566 = local_value_1631.load(local_value_0571).to(local_value_1631.float32)
        local_value_1302 = local_value_1631.exp(local_value_0566)
        if HAS_SEQ_IDX:
            local_value_1302 = local_value_1631.where(local_value_1339 == 0, local_value_1302, 0.0)
        out = local_value_1631.load(local_value_1163, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
        local_value_0653 = local_value_1631.sum(out * local_value_0760) * local_value_1302
        local_value_1631.store(local_value_0657, local_value_0653)
        local_value_0723 = local_value_1631.load(local_value_0727, mask=local_value_1123 < dim, other=0.0).to(local_value_1631.float32)
        local_value_0760 = local_value_1302 * local_value_0760 + local_value_0723
        local_value_1631.store(local_value_0714 + local_value_1123 * local_value_1502, local_value_0760, mask=local_value_1123 < dim)

def execute_step_0387(local_value_1400, local_value_0565, local_value_0970=None, local_value_1339=None, local_value_0513=None, local_value_1152=None):
    local_value_0434, local_value_1078, local_value_1090, dim = local_value_1400.shape
    assert local_value_0565.shape == (local_value_0434, local_value_1090, local_value_1078)
    if local_value_0970 is not None:
        assert local_value_0970.shape == (local_value_0434, local_value_1090, dim)
    if local_value_1339 is not None:
        assert local_value_0513 is not None
        local_value_1348 = local_value_1339.shape[-1]
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    local_value_1152 = local_value_1400.dtype if local_value_1152 is None else local_value_1152
    out = local_value_1650.empty((local_value_0434, local_value_1078, local_value_1090, dim), device=local_value_1400.device, dtype=local_value_1152)
    local_value_0838 = local_value_1650.empty((local_value_0434, local_value_1090, dim), device=local_value_1400.device, dtype=local_value_1650.float32)
    local_value_0899 = lambda local_value_0177: (local_value_1655.cdiv(dim, local_value_0177['local_value_0020']), local_value_0434, local_value_1090)
    with local_value_1650.cuda.device(local_value_1400.device.index):
        execute_step_0388[local_value_0899](local_value_1400, out, local_value_0838, local_value_0565, local_value_0970, local_value_1339, int(dim), int(local_value_1078), int(local_value_1348 if local_value_1339 is not None else 0), int(local_value_0513 if local_value_1339 is not None else 0), local_value_1400.stride(0), local_value_1400.stride(1), local_value_1400.stride(2), local_value_1400.stride(3), out.stride(0), out.stride(1), out.stride(2), out.stride(3), local_value_0838.stride(0), local_value_0838.stride(1), local_value_0838.stride(2), local_value_0565.stride(0), local_value_0565.stride(2), local_value_0565.stride(1), *((local_value_0970.stride(0), local_value_0970.stride(1), local_value_0970.stride(2)) if local_value_0970 is not None else (0, 0, 0)), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), HAS_INITSTATES=local_value_0970 is not None, HAS_SEQ_IDX=local_value_1339 is not None)
    return (out, local_value_0838)

def execute_step_0385(local_value_1400, local_value_0565, local_value_0723, local_value_0700=None, local_value_1339=None, local_value_0919=None, local_value_0761=None, local_value_1404=None, local_value_0513=None):
    local_value_0434, local_value_1078, local_value_1090, dim = local_value_1400.shape
    assert local_value_0565.shape == (local_value_0434, local_value_1090, local_value_1078)
    assert local_value_0723.shape == (local_value_0434, local_value_1078, local_value_1090, dim)
    if local_value_1339 is not None:
        assert local_value_0513 is not None
        local_value_1348 = local_value_1339.shape[-1]
        assert local_value_1339.shape == (local_value_0434, local_value_1348)
    local_value_0760 = local_value_1650.empty_like(local_value_0723, dtype=local_value_0761 if local_value_0761 is not None else local_value_0723.dtype)
    if local_value_1404 is not None and local_value_1404 != local_value_1400.dtype:
        local_value_1401 = local_value_1650.empty_like(local_value_1400, dtype=local_value_0761 if local_value_0761 is not None else local_value_0723.dtype)
        assert local_value_1401.stride() == local_value_1400.stride()
    else:
        local_value_1401 = None
    if local_value_0919:
        local_value_0713 = local_value_1650.empty_like(local_value_0760[:, 0])
    else:
        local_value_0713 = None
    if local_value_0700 is not None:
        assert local_value_0700.shape == (local_value_0434, local_value_1090, dim)
    local_value_0031 = 64
    local_value_1071 = (dim + local_value_0031 - 1) // local_value_0031
    local_value_0654 = local_value_1650.empty(local_value_0434, local_value_1090, local_value_1078, local_value_1071, dtype=local_value_1650.float32, device=local_value_0565.device)
    local_value_0899 = lambda local_value_0177: (local_value_1655.cdiv(dim, local_value_0177['local_value_0020']), local_value_0434, local_value_1090)
    with local_value_1650.cuda.device(local_value_0723.device.index):
        execute_step_0386[local_value_0899](local_value_0723, local_value_1400, local_value_0565, local_value_0700, local_value_1339, local_value_0760, local_value_0654, local_value_0713, local_value_1401, int(dim), int(local_value_1078), int(local_value_1348 if local_value_1339 is not None else 0), int(local_value_0513 if local_value_1339 is not None else 0), local_value_0723.stride(0), local_value_0723.stride(1), local_value_0723.stride(2), local_value_0723.stride(3), local_value_1400.stride(0), local_value_1400.stride(1), local_value_1400.stride(2), local_value_1400.stride(3), local_value_0565.stride(0), local_value_0565.stride(2), local_value_0565.stride(1), *((local_value_0700.stride(0), local_value_0700.stride(1), local_value_0700.stride(2)) if local_value_0700 is not None else (0, 0, 0)), *((local_value_1339.stride(0), local_value_1339.stride(1)) if local_value_1339 is not None else (0, 0)), local_value_0760.stride(0), local_value_0760.stride(1), local_value_0760.stride(2), local_value_0760.stride(3), local_value_0654.stride(0), local_value_0654.stride(2), local_value_0654.stride(1), *((local_value_0713.stride(0), local_value_0713.stride(1), local_value_0713.stride(2)) if local_value_0713 is not None else (0, 0, 0)), CONVERT_STATES=local_value_1401 is not None, HAS_DFINAL_STATES=local_value_0700 is not None, HAS_DINITSTATES=local_value_0713 is not None, HAS_SEQ_IDX=local_value_1339 is not None)
    local_value_0030 = execute_step_0386.best_config.kwargs['local_value_0020']
    local_value_1073 = (dim + local_value_0030 - 1) // local_value_0030
    local_value_0654 = local_value_0654[..., :local_value_1073].sum(dim=-1).to(dtype=local_value_0565.dtype)
    if local_value_1404 is not None and local_value_1404 == local_value_1400.dtype:
        local_value_1401 = local_value_1400
    return (local_value_0760, local_value_0654, local_value_0713) if local_value_1404 is None else (local_value_0760, local_value_0654, local_value_0713, local_value_1401)

class ComponentUnit0235(local_value_1650.autograd.Function):

    @staticmethod
    def forward(local_value_0551, local_value_1400, local_value_0565, local_value_0970=None):
        local_value_0434, local_value_1078, local_value_1090, dim = local_value_1400.shape
        assert local_value_0565.shape == (local_value_0434, local_value_1090, local_value_1078)
        if local_value_1400.stride(-1) != 1:
            local_value_1400 = local_value_1400.contiguous()
        out, local_value_0838 = execute_step_0387(local_value_1400, local_value_0565, local_value_0970)
        local_value_0551.save_for_backward(out, local_value_0565)
        local_value_0551.local_value_0919 = local_value_0970 is not None
        return (out, local_value_0838)

    @staticmethod
    def backward(local_value_0551, local_value_0723, local_value_0700):
        out, local_value_0565 = local_value_0551.saved_tensors
        local_value_0434, local_value_1078, local_value_1090, dim = out.shape
        assert local_value_0723.shape == (local_value_0434, local_value_1078, local_value_1090, dim)
        assert local_value_0565.shape == (local_value_0434, local_value_1090, local_value_1078)
        assert local_value_0700.shape == (local_value_0434, local_value_1090, dim)
        if local_value_0723.stride(-1) != 1:
            local_value_0723 = local_value_0723.contiguous()
        local_value_0760, local_value_0654, local_value_0713 = execute_step_0385(out, local_value_0565, local_value_0723, local_value_0700=local_value_0700, local_value_0919=local_value_0551.local_value_0919)
        return (local_value_0760, local_value_0654, local_value_0713)

def execute_step_1395(local_value_1400, local_value_0565, local_value_0970=None):
    return ComponentUnit0235.apply(local_value_1400, local_value_0565, local_value_0970)

def execute_step_1396(local_value_1400, local_value_0565, local_value_0970=None):
    if local_value_0970 is None:
        local_value_0970 = local_value_1650.zeros_like(local_value_1400[:, 0])
    local_value_1400 = local_value_1650.cat([local_value_1249(local_value_0970, 'b h d -> b 1 h d'), local_value_1400], dim=1)
    local_value_0565 = local_value_0117.pad(local_value_0565, (1, 0))
    local_value_0565 = local_value_1650.cumsum(local_value_0565, dim=-1)
    local_value_1078 = local_value_0565.shape[-1]
    local_value_0770 = local_value_0565[:, :, :, None] - local_value_0565[:, :, None, :]
    local_value_0685 = local_value_1650.exp(local_value_0770)
    local_value_0482 = local_value_1650.tril(local_value_1650.ones(local_value_1078, local_value_1078, device=local_value_1400.device, dtype=bool), diagonal=0)
    local_value_0685 = local_value_0685.masked_fill(~local_value_0482, 0)
    out = local_value_1650.einsum('bhzc,bchd->bzhd', local_value_0685.to(dtype=local_value_1400.dtype), local_value_1400)
    return (out[:, :-1], out[:, -1])
