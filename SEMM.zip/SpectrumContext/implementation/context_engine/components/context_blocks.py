import os as local_value_1136
import time as local_value_1630
import math as local_value_1039
import copy as local_value_0536
from functools import partial as local_value_1197
from typing import Optional as local_value_0199, Callable as local_value_0062, Any as local_value_0008
from collections import OrderedDict as local_value_0200
import torch as local_value_1650
import torch.nn as local_value_1094
import torch.nn.functional as local_value_0117
import torch.utils.checkpoint as local_value_0509
from timm.models.layers import DropPath as local_value_0112, trunc_normal_ as local_value_1658
from fvcore.nn import FlopCountAnalysis as local_value_0120, flop_count_str as local_value_0844, flop_count as local_value_0843, parameter_count as local_value_1194
from .tensor_primitives import *
local_value_0112.__repr__ = lambda local_value_1336: f'timm.DropPath({local_value_1336.drop_prob})'
try:
    from .engine_unit_002 import execute_step_0546, execute_step_0541
except:
    from engine_unit_002 import execute_step_0546, execute_step_0541
try:
    from .engine_unit_003 import execute_step_1330, execute_step_1329
except:
    from engine_unit_003 import execute_step_1330, execute_step_1329
try:
    from .chunk_ops.engine_unit_026 import execute_step_1318
except:
    from chunk_ops.engine_unit_026 import execute_step_1318

class ComponentUnit1033:

    @staticmethod
    def execute_step_0772(dt_rank, local_value_0608, dt_scale=1.0, execute_step_0772='random', dt_min=0.001, dt_max=0.1, dt_init_floor=0.0001):
        local_value_0785 = local_value_1094.Linear(dt_rank, local_value_0608, bias=True)
        local_value_0774 = dt_rank ** (-0.5) * dt_scale
        if execute_step_0772 == 'constant':
            local_value_1094.init.constant_(local_value_0785.weight, local_value_0774)
        elif execute_step_0772 == 'random':
            local_value_1094.init.uniform_(local_value_0785.weight, -local_value_0774, local_value_0774)
        else:
            raise NotImplementedError
        local_value_0764 = local_value_1650.exp(local_value_1650.rand(local_value_0608) * (local_value_1039.log(dt_max) - local_value_1039.log(dt_min)) + local_value_1039.log(dt_min)).clamp(min=dt_init_floor)
        local_value_0985 = local_value_0764 + local_value_1650.log(-local_value_1650.expm1(-local_value_0764))
        with local_value_1650.no_grad():
            local_value_0785.bias.copy_(local_value_0985)
        return local_value_0785

    @staticmethod
    def execute_step_0003(d_state, local_value_0608, local_value_0535=-1, device=None, local_value_1044=True):
        local_value_0000 = local_value_1650.arange(1, d_state + 1, dtype=local_value_1650.float32, device=device).view(1, -1).repeat(local_value_0608, 1).contiguous()
        local_value_0002 = local_value_1650.log(local_value_0000)
        if local_value_0535 > 0:
            local_value_0002 = local_value_0002[None].repeat(local_value_0535, 1, 1).contiguous()
            if local_value_1044:
                local_value_0002 = local_value_0002.flatten(0, 1)
        local_value_0002 = local_value_1094.Parameter(local_value_0002)
        local_value_0002._no_weight_decay = True
        return local_value_0002

    @staticmethod
    def execute_step_0107(local_value_0608, local_value_0535=-1, device=None, local_value_1044=True):
        D = local_value_1650.ones(local_value_0608, device=device)
        if local_value_0535 > 0:
            D = D[None].repeat(local_value_0535, 1).contiguous()
            if local_value_1044:
                D = D.flatten(0, 1)
        D = local_value_1094.Parameter(D)
        D._no_weight_decay = True
        return D

    @classmethod
    def execute_step_0964(local_value_0524, d_state, dt_rank, local_value_0608, dt_scale, execute_step_0772, dt_min, dt_max, dt_init_floor, k_group=4):
        local_value_0786 = [local_value_0524.execute_step_0772(dt_rank, local_value_0608, dt_scale, execute_step_0772, dt_min, dt_max, dt_init_floor) for local_value_0272 in range(k_group)]
        local_value_0788 = local_value_1094.Parameter(local_value_1650.stack([local_value_1618.weight for local_value_1618 in local_value_0786], dim=0))
        local_value_0787 = local_value_1094.Parameter(local_value_1650.stack([local_value_1618.bias for local_value_1618 in local_value_0786], dim=0))
        del local_value_0786
        A_logs = local_value_0524.execute_step_0003(d_state, local_value_0608, local_value_0535=k_group, local_value_1044=True)
        Ds = local_value_0524.execute_step_0107(local_value_0608, local_value_0535=k_group, local_value_1044=True)
        return (A_logs, Ds, local_value_0788, local_value_0787)

class ComponentUnit0222:

    def execute_step_0285(local_value_1336, d_model=96, d_state=16, ssm_ratio=2.0, dt_rank='auto', dropout=0.0, local_value_1338=False, local_value_0853=True, **local_value_1007):
        if 'channel_first' in local_value_1007:
            assert not local_value_1007['channel_first']
        act_layer = local_value_1094.SiLU
        dt_min = 0.001
        dt_max = 0.1
        execute_step_0772 = 'random'
        dt_scale = 1.0
        dt_init_floor = 0.0001
        bias = False
        conv_bias = True
        d_conv = 3
        k_group = 4
        local_value_0835 = {'device': None, 'dtype': None}
        super().__init__()
        local_value_0608 = int(ssm_ratio * d_model)
        dt_rank = local_value_1039.ceil(d_model / 16) if dt_rank == 'auto' else dt_rank
        local_value_1336.forward = local_value_1336.execute_step_0862
        if local_value_1338:
            local_value_1336.forward = local_value_1197(local_value_1336.execute_step_0862, local_value_1338=True)
        if not local_value_0853:
            local_value_1336.forward = local_value_1197(local_value_1336.execute_step_0862, local_value_0853=False)
        local_value_1336.member_slot_0319 = local_value_1094.Linear(d_model, local_value_0608 * 2, bias=bias)
        local_value_1336.member_slot_0149: local_value_1094.Module = act_layer()
        local_value_1336.conv2d = local_value_1094.Conv2d(in_channels=local_value_0608, out_channels=local_value_0608, groups=local_value_0608, bias=conv_bias, kernel_size=d_conv, padding=(d_conv - 1) // 2, **local_value_0835)
        local_value_1336.member_slot_0479 = [local_value_1094.Linear(local_value_0608, dt_rank + d_state * 2, bias=False) for local_value_0272 in range(k_group)]
        local_value_1336.member_slot_0481 = local_value_1094.Parameter(local_value_1650.stack([local_value_1618.weight for local_value_1618 in local_value_1336.member_slot_0479], dim=0))
        del local_value_1336.member_slot_0479
        local_value_1336.A_logs, local_value_1336.Ds, local_value_1336.local_value_0788, local_value_1336.local_value_0787 = ComponentUnit1033.execute_step_0964(d_state, dt_rank, local_value_0608, dt_scale, execute_step_0772, dt_min, dt_max, dt_init_floor, k_group=4)
        local_value_1336.local_value_1155 = local_value_1094.LayerNorm(local_value_0608)
        local_value_1336.member_slot_0381 = local_value_1094.Linear(local_value_0608, d_model, bias=bias)
        local_value_1336.dropout = local_value_1094.Dropout(dropout) if dropout > 0.0 else local_value_1094.Identity()

    def execute_step_0862(local_value_1336, local_value_1699: local_value_1650.Tensor, local_value_1338=False, local_value_0853=True, **local_value_1007):
        local_value_1699 = local_value_1336.member_slot_0319(local_value_1699)
        local_value_1699, local_value_1753 = local_value_1699.chunk(2, dim=-1)
        local_value_1753 = local_value_1336.member_slot_0149(local_value_1753)
        local_value_1699 = local_value_1699.permute(0, 3, 1, 2).contiguous()
        local_value_1699 = local_value_1336.conv2d(local_value_1699)
        local_value_1699 = local_value_1336.member_slot_0149(local_value_1699)
        execute_step_1314 = local_value_1197(execute_step_1330, local_value_0430='mamba')
        B, D, H, W = local_value_1699.shape
        D, N = local_value_1336.A_logs.shape
        local_value_0156, D, local_value_0207 = local_value_1336.local_value_0788.shape
        L = H * W
        local_value_1714 = local_value_1650.stack([local_value_1699.view(B, -1, L), local_value_1650.transpose(local_value_1699, dim0=2, dim1=3).contiguous().view(B, -1, L)], dim=1).view(B, 2, -1, L)
        local_value_1733 = local_value_1650.cat([local_value_1714, local_value_1650.flip(local_value_1714, dims=[-1])], dim=1)
        local_value_1708 = local_value_1650.einsum('b k d l, k c d -> b k c l', local_value_1733, local_value_1336.member_slot_0481)
        if hasattr(local_value_1336, 'local_value_1719'):
            local_value_1708 = local_value_1708 + local_value_1336.local_value_1719.view(1, local_value_0156, -1, 1)
        dts, Bs, Cs = local_value_1650.split(local_value_1708, [local_value_0207, N, N], dim=2)
        dts = local_value_1650.einsum('b k r l, k d r -> b k d l', dts, local_value_1336.local_value_0788)
        local_value_1733 = local_value_1733.view(B, -1, L)
        dts = dts.contiguous().view(B, -1, L)
        Bs = Bs.contiguous()
        Cs = Cs.contiguous()
        local_value_0009 = -local_value_1336.A_logs.float().exp()
        Ds = local_value_1336.Ds.float()
        local_value_0787 = local_value_1336.local_value_0787.float().view(-1)
        local_value_1645 = lambda *local_value_0416: (local_value_0288.to(local_value_1650.float32) for local_value_0288 in local_value_0416)
        if local_value_0853:
            local_value_1733, dts, Bs, Cs = local_value_1645(local_value_1733, dts, Bs, Cs)
        if local_value_1338:
            local_value_1169 = []
            for local_value_0939 in range(4):
                local_value_1749 = execute_step_1314(local_value_1733.view(B, local_value_0156, -1, L)[:, local_value_0939], dts.view(B, local_value_0156, -1, L)[:, local_value_0939], local_value_0009.view(local_value_0156, -1, N)[local_value_0939], Bs[:, local_value_0939].unsqueeze(1), Cs[:, local_value_0939].unsqueeze(1), Ds.view(local_value_0156, -1)[local_value_0939], delta_bias=local_value_0787.view(local_value_0156, -1)[local_value_0939], local_value_0696=True).view(B, -1, L)
                local_value_1169.append(local_value_1749)
            local_value_1169 = local_value_1650.stack(local_value_1169, dim=1)
        else:
            local_value_1169 = execute_step_1314(local_value_1733, dts, local_value_0009, Bs, Cs, Ds, delta_bias=local_value_0787, local_value_0696=True).view(B, local_value_0156, -1, L)
        assert local_value_1169.dtype == local_value_1650.float
        local_value_0987 = local_value_1650.flip(local_value_1169[:, 2:4], dims=[-1]).view(B, 2, -1, L)
        local_value_1690 = local_value_1650.transpose(local_value_1169[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)
        local_value_0988 = local_value_1650.transpose(local_value_0987[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)
        y = local_value_1169[:, 0] + local_value_0987[:, 0] + local_value_1690 + local_value_0988
        y = y.transpose(dim0=1, dim1=2).contiguous()
        y = local_value_1336.local_value_1155(y).view(B, H, W, -1)
        y = y * local_value_1753
        out = local_value_1336.dropout(local_value_1336.member_slot_0381(y))
        return out

class ComponentUnit0223:

    def execute_step_0286(local_value_1336, d_model=96, d_state=16, ssm_ratio=2.0, dt_rank='auto', act_layer=local_value_1094.SiLU, d_conv=3, conv_bias=True, dropout=0.0, bias=False, dt_min=0.001, dt_max=0.1, execute_step_0772='random', dt_scale=1.0, dt_init_floor=0.0001, initialize='v0', forward_type='v2', channel_first=False, local_value_0529=False, g_ratio=0.5, use_global_local=True, **local_value_1007):
        local_value_0835 = {'device': None, 'dtype': None}
        super().__init__()
        local_value_1336.k_group = 4
        local_value_1336.d_model = int(d_model)
        local_value_1336.d_state = int(d_state)
        local_value_1336.local_value_0608 = int(ssm_ratio * d_model)
        local_value_1336.dt_rank = int(local_value_1039.ceil(local_value_1336.d_model / 16) if dt_rank == 'auto' else dt_rank)
        local_value_1336.channel_first = channel_first
        local_value_1336.member_slot_0477 = d_conv > 1
        local_value_0172 = ComponentUnit0173 if channel_first else local_value_1094.Linear
        local_value_1336.forward = local_value_1336.execute_step_0863
        execute_step_0510 = local_value_1336.execute_step_0510
        local_value_1336.member_slot_0246, forward_type = execute_step_0510('_no32', forward_type)
        local_value_1336.member_slot_0370, forward_type = execute_step_0510('_oact', forward_type)
        local_value_1336.member_slot_0247, forward_type = execute_step_0510('_noz', forward_type)
        local_value_1336.member_slot_0248, forward_type = execute_step_0510('_nozact', forward_type)
        local_value_1336.local_value_1155, forward_type = local_value_1336.execute_step_0888(forward_type, local_value_1336.local_value_0608, channel_first)
        local_value_0119 = dict(v01=local_value_1197(local_value_1336.execute_step_0859, local_value_0853=not local_value_1336.member_slot_0246, local_value_1315='mamba', local_value_1305=True), v02=local_value_1197(local_value_1336.execute_step_0859, local_value_0853=not local_value_1336.member_slot_0246, local_value_1315='mamba'), v03=local_value_1197(local_value_1336.execute_step_0859, local_value_0853=not local_value_1336.member_slot_0246, local_value_1315='oflex'), v04=local_value_1197(local_value_1336.execute_step_0859, local_value_0853=False), v05=local_value_1197(local_value_1336.execute_step_0859, local_value_0853=False, local_value_1095=True), v051d=local_value_1197(local_value_1336.execute_step_0859, local_value_0853=False, local_value_1095=True, local_value_1306='unidi'), v052d=local_value_1197(local_value_1336.execute_step_0859, local_value_0853=False, local_value_1095=True, local_value_1306='bidi'), v052dc=local_value_1197(local_value_1336.execute_step_0859, local_value_0853=False, local_value_1095=True, local_value_1306='cascade2d'), v052d3=local_value_1197(local_value_1336.execute_step_0859, local_value_0853=False, local_value_1095=True, local_value_1306=3), v2=local_value_1197(local_value_1336.execute_step_0859, local_value_0853=not local_value_1336.member_slot_0246, local_value_1315='oflex'), v3=local_value_1197(local_value_1336.execute_step_0859, local_value_0853=False, local_value_1315='oflex'))
        local_value_1336.member_slot_0278 = local_value_0119.get(forward_type, None)
        local_value_0617 = local_value_1336.local_value_0608 if local_value_1336.member_slot_0247 else local_value_1336.local_value_0608 * 2
        local_value_1336.member_slot_0319 = local_value_0172(local_value_1336.d_model, local_value_0617, bias=bias)
        local_value_1336.member_slot_0149: local_value_1094.Module = act_layer()
        if local_value_1336.member_slot_0477:
            local_value_1336.conv2d = local_value_1094.Conv2d(in_channels=local_value_1336.local_value_0608, out_channels=local_value_1336.local_value_0608, groups=local_value_1336.local_value_0608, bias=conv_bias, kernel_size=d_conv, padding=(d_conv - 1) // 2, **local_value_0835)
        local_value_1336.member_slot_0479 = [local_value_1094.Linear(local_value_1336.local_value_0608, local_value_1336.dt_rank + local_value_1336.d_state * 2, bias=False) for local_value_0272 in range(local_value_1336.k_group)]
        local_value_1336.member_slot_0481 = local_value_1094.Parameter(local_value_1650.stack([local_value_1618.weight for local_value_1618 in local_value_1336.member_slot_0479], dim=0))
        del local_value_1336.member_slot_0479
        local_value_1336.member_slot_0349 = bool(use_global_local)
        if local_value_1336.member_slot_0349:
            local_value_1336.local_value_0529 = local_value_0529
            local_value_1336.g_ratio = g_ratio
            local_value_1050 = local_value_1336.k_group * local_value_1336.local_value_0608
            local_value_0893 = int(local_value_1050 * local_value_1336.g_ratio)
            local_value_1024 = local_value_1050 - local_value_0893
            local_value_1336.member_slot_0303 = ComponentUnit0012(dim=local_value_0893, num_heads=8)
            local_value_1336.member_slot_0338 = ComponentUnit0174(dim=local_value_1024)
        local_value_1336.member_slot_0059 = False
        local_value_1336.member_slot_0067 = None
        local_value_1336.member_slot_0068 = 64
        local_value_1336.member_slot_0377 = local_value_1094.GELU() if local_value_1336.member_slot_0370 else local_value_1094.Identity()
        local_value_1336.member_slot_0381 = local_value_0172(local_value_1336.local_value_0608, local_value_1336.d_model, bias=bias)
        local_value_1336.dropout = local_value_1094.Dropout(dropout) if dropout > 0.0 else local_value_1094.Identity()
        if initialize in ['v0']:
            local_value_1336.A_logs, local_value_1336.Ds, local_value_1336.local_value_0788, local_value_1336.local_value_0787 = ComponentUnit1033.execute_step_0964(local_value_1336.d_state, local_value_1336.dt_rank, local_value_1336.local_value_0608, dt_scale, execute_step_0772, dt_min, dt_max, dt_init_floor, k_group=local_value_1336.k_group)
        elif initialize in ['v1']:
            local_value_1336.Ds = local_value_1094.Parameter(local_value_1650.ones(local_value_1336.k_group * local_value_1336.local_value_0608))
            local_value_1336.A_logs = local_value_1094.Parameter(local_value_1650.randn((local_value_1336.k_group * local_value_1336.local_value_0608, local_value_1336.d_state)))
            local_value_1336.local_value_0788 = local_value_1094.Parameter(0.1 * local_value_1650.randn((local_value_1336.k_group, local_value_1336.local_value_0608, local_value_1336.dt_rank)))
            local_value_1336.local_value_0787 = local_value_1094.Parameter(0.1 * local_value_1650.randn((local_value_1336.k_group, local_value_1336.local_value_0608)))
        elif initialize in ['v2']:
            local_value_1336.Ds = local_value_1094.Parameter(local_value_1650.ones(local_value_1336.k_group * local_value_1336.local_value_0608))
            local_value_1336.A_logs = local_value_1094.Parameter(local_value_1650.zeros((local_value_1336.k_group * local_value_1336.local_value_0608, local_value_1336.d_state)))
            local_value_1336.local_value_0788 = local_value_1094.Parameter(0.1 * local_value_1650.rand((local_value_1336.k_group, local_value_1336.local_value_0608, local_value_1336.dt_rank)))
            local_value_1336.local_value_0787 = local_value_1094.Parameter(0.1 * local_value_1650.rand((local_value_1336.k_group, local_value_1336.local_value_0608)))

    def execute_step_1349(local_value_1336, local_value_0827: bool=True, local_value_1042: int=64):
        local_value_1336.member_slot_0059 = bool(local_value_0827)
        local_value_1336.member_slot_0068 = int(local_value_1042)
        local_value_1336.member_slot_0067 = None
        return local_value_1336

    def execute_step_0891(local_value_1336, local_value_0523: bool=False):
        local_value_0640 = local_value_1336.member_slot_0067
        if local_value_0523:
            local_value_1336.member_slot_0067 = None
        return local_value_0640

    @local_value_1650.no_grad()
    def execute_step_0396(local_value_1336, local_value_1649: local_value_1650.Tensor, local_value_1042: int=64) -> local_value_1650.Tensor:
        if local_value_1649 is None:
            return None
        B, L, local_value_0044 = local_value_1649.shape
        local_value_0238 = min(int(local_value_1042), int(L))
        if local_value_0238 < L:
            local_value_0950 = local_value_1650.linspace(0, L - 1, steps=local_value_0238, device=local_value_1649.device).long()
            local_value_1649 = local_value_1649.index_select(dim=1, index=local_value_0950)
        local_value_1699 = local_value_1649.float()
        local_value_1699 = local_value_1699 - local_value_1699.mean(dim=-1, keepdim=True)
        local_value_1699 = local_value_0117.normalize(local_value_1699, dim=-1, eps=1e-06)
        local_value_0421 = local_value_1650.bmm(local_value_1699, local_value_1699.transpose(1, 2))
        local_value_0421 = local_value_0421 - local_value_0421.amin(dim=(-2, -1), keepdim=True)
        local_value_0421 = local_value_0421 / (local_value_0421.amax(dim=(-2, -1), keepdim=True) + 1e-06)
        return local_value_0421

    def execute_step_0859(local_value_1336, local_value_1699: local_value_1650.Tensor=None, local_value_0853=False, local_value_1385=True, local_value_1095=False, local_value_1315=None, local_value_1306='cross2d', local_value_1305=False, **local_value_1007):
        assert local_value_1315 in [None, 'oflex', 'mamba', 'torch']
        local_value_0383 = dict(cross2d=0, unidi=1, bidi=2, cascade2d=-1).get(local_value_1306, None) if isinstance(local_value_1306, str) else local_value_1306
        assert isinstance(local_value_0383, int)
        local_value_0696 = True
        local_value_1155 = local_value_1336.local_value_1155
        channel_first = local_value_1336.channel_first
        local_value_1645 = lambda *local_value_0416: (local_value_0288.to(local_value_1650.float32) for local_value_0288 in local_value_0416)
        B, D, H, W = local_value_1699.shape
        N = local_value_1336.d_state
        local_value_0156, D, local_value_0207 = (local_value_1336.k_group, local_value_1336.local_value_0608, local_value_1336.dt_rank)
        L = H * W

        def execute_step_1314(local_value_1660, delta, local_value_0000, B, local_value_0044, D=None, delta_bias=None, local_value_0696=True):
            return execute_step_1330(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, local_value_1385, local_value_0430=local_value_1315)
        if local_value_0383 == -1:
            local_value_1719 = getattr(local_value_1336, 'local_value_1719', None)

            def execute_step_1307(local_value_1699: local_value_1650.Tensor, local_value_1233: local_value_1650.Tensor, local_value_1231: local_value_1650.Tensor, local_value_0795: local_value_1650.Tensor, local_value_0767: local_value_1650.Tensor, local_value_0274: local_value_1650.Tensor, local_value_0278: local_value_1650.Tensor, local_value_1691=True):
                local_value_0263, local_value_0264, local_value_0265, local_value_0266 = local_value_1699.shape
                if local_value_1691:
                    local_value_0275, local_value_0277, local_value_0279 = (local_value_0263 * local_value_0265, local_value_0264, local_value_0266)
                    local_value_1733 = local_value_1699.permute(0, 2, 1, 3).contiguous()
                else:
                    local_value_0275, local_value_0277, local_value_0279 = (local_value_0263 * local_value_0266, local_value_0264, local_value_0265)
                    local_value_1733 = local_value_1699.permute(0, 3, 1, 2).contiguous()
                local_value_1733 = local_value_1650.stack([local_value_1733, local_value_1733.flip(dims=[-1])], dim=2)
                if local_value_1095:
                    local_value_1708 = local_value_0117.conv1d(local_value_1733.view(local_value_0275, -1, local_value_0279), local_value_1233.view(-1, local_value_0277, 1), bias=local_value_1231.view(-1) if local_value_1231 is not None else None, groups=2)
                    dts, Bs, Cs = local_value_1650.split(local_value_1708.view(local_value_0275, 2, -1, local_value_0279), [local_value_0207, N, N], dim=2)
                    dts = local_value_0117.conv1d(dts.contiguous().view(local_value_0275, -1, local_value_0279), local_value_0795.view(2 * local_value_0277, -1, 1), groups=2)
                else:
                    local_value_1708 = local_value_1650.einsum('b k d l, k c d -> b k c l', local_value_1733, local_value_1233)
                    if local_value_1719 is not None:
                        local_value_1708 = local_value_1708 + local_value_1719.view(1, 2, -1, 1)
                    dts, Bs, Cs = local_value_1650.split(local_value_1708, [local_value_0207, N, N], dim=2)
                    dts = local_value_1650.einsum('b k r l, k d r -> b k d l', dts, local_value_0795)
                local_value_1733 = local_value_1733.view(local_value_0275, -1, local_value_0279)
                dts = dts.contiguous().view(local_value_0275, -1, local_value_0279)
                local_value_0009 = local_value_0274.view(-1, N).to(local_value_1650.float)
                Bs = Bs.contiguous().view(local_value_0275, 2, N, local_value_0279)
                Cs = Cs.contiguous().view(local_value_0275, 2, N, local_value_0279)
                Ds = local_value_0278.view(-1)
                delta_bias = local_value_0767.view(-1).to(local_value_1650.float)
                if local_value_0853:
                    local_value_1733 = local_value_1733.to(local_value_1650.float)
                dts = dts.to(local_value_1733.dtype)
                Bs = Bs.to(local_value_1733.dtype)
                Cs = Cs.to(local_value_1733.dtype)
                ys: local_value_1650.Tensor = execute_step_1314(local_value_1733, dts, local_value_0009, Bs, Cs, Ds, delta_bias, local_value_0696).view(local_value_0275, 2, -1, local_value_0279)
                return ys
            local_value_0009 = -local_value_1336.A_logs.to(local_value_1650.float).exp().view(4, -1, N)
            local_value_1699 = local_value_0117.layer_norm(local_value_1699.permute(0, 2, 3, 1), normalized_shape=(int(local_value_1699.shape[1]),)).permute(0, 3, 1, 2).contiguous()
            local_value_1747 = execute_step_1307(local_value_1699, local_value_1233=local_value_1336.member_slot_0481.view(4, -1, D)[:2].contiguous(), local_value_1231=local_value_1719.view(4, -1)[:2].contiguous() if local_value_1719 is not None else None, local_value_0795=local_value_1336.local_value_0788.view(4, D, -1)[:2].contiguous(), local_value_0767=local_value_1336.local_value_0787.view(4, -1)[:2].contiguous() if local_value_1336.local_value_0787 is not None else None, local_value_0274=local_value_0009[:2].contiguous().view(-1, N), local_value_0278=local_value_1336.Ds.view(4, -1)[:2].contiguous().view(-1), local_value_1691=True).view(B, H, 2, -1, W).sum(dim=2).permute(0, 2, 1, 3)
            local_value_1747 = local_value_0117.layer_norm(local_value_1747.permute(0, 2, 3, 1), normalized_shape=(int(local_value_1747.shape[1]),)).permute(0, 3, 1, 2).contiguous()
            local_value_1743 = execute_step_1307(local_value_1747, local_value_1233=local_value_1336.member_slot_0481.view(4, -1, D)[2:].contiguous().to(local_value_1747.dtype), local_value_1231=local_value_1719.view(4, -1)[2:].contiguous().to(local_value_1747.dtype) if local_value_1719 is not None else None, local_value_0795=local_value_1336.local_value_0788.view(4, D, -1)[2:].contiguous().to(local_value_1747.dtype), local_value_0767=local_value_1336.local_value_0787.view(4, -1)[2:].contiguous().to(local_value_1747.dtype) if local_value_1336.local_value_0787 is not None else None, local_value_0274=local_value_0009[2:].contiguous().view(-1, N), local_value_0278=local_value_1336.Ds.view(4, -1)[2:].contiguous().view(-1), local_value_1691=False).view(B, W, 2, -1, H).sum(dim=2).permute(0, 2, 3, 1)
            y = local_value_1743
        else:
            local_value_1719 = getattr(local_value_1336, 'local_value_1719', None)
            local_value_1733 = execute_step_0546(local_value_1699, in_channel_first=True, out_channel_first=True, local_value_1308=local_value_0383, local_value_0854=local_value_1305)
            if local_value_1095:
                local_value_1708 = local_value_0117.conv1d(local_value_1733.view(B, -1, L), local_value_1336.member_slot_0481.view(-1, D, 1), bias=local_value_1719.view(-1) if local_value_1719 is not None else None, groups=local_value_0156)
                dts, Bs, Cs = local_value_1650.split(local_value_1708.view(B, local_value_0156, -1, L), [local_value_0207, N, N], dim=2)
                if hasattr(local_value_1336, 'local_value_0788'):
                    dts = local_value_0117.conv1d(dts.contiguous().view(B, -1, L), local_value_1336.local_value_0788.view(local_value_0156 * D, -1, 1), groups=local_value_0156)
            else:
                local_value_1708 = local_value_1650.einsum('b k d l, k c d -> b k c l', local_value_1733, local_value_1336.member_slot_0481)
                if local_value_1719 is not None:
                    local_value_1708 = local_value_1708 + local_value_1719.view(1, local_value_0156, -1, 1)
                dts, Bs, Cs = local_value_1650.split(local_value_1708, [local_value_0207, N, N], dim=2)
                if hasattr(local_value_1336, 'local_value_0788'):
                    dts = local_value_1650.einsum('b k r l, k d r -> b k d l', dts, local_value_1336.local_value_0788)
            local_value_1733 = local_value_1733.view(B, -1, L)
            dts = dts.contiguous().view(B, -1, L)
            local_value_0009 = -local_value_1336.A_logs.to(local_value_1650.float).exp()
            Ds = local_value_1336.Ds.to(local_value_1650.float)
            Bs = Bs.contiguous().view(B, local_value_0156, N, L)
            Cs = Cs.contiguous().view(B, local_value_0156, N, L)
            delta_bias = local_value_1336.local_value_0787.view(-1).to(local_value_1650.float)
            if local_value_0853:
                local_value_1733, dts, Bs, Cs = local_value_1645(local_value_1733, dts, Bs, Cs)
            ys = execute_step_1314(local_value_1733, dts, local_value_0009, Bs, Cs, Ds, delta_bias, local_value_0696)
            if local_value_1336.member_slot_0349:
                local_value_1680 = bool(getattr(local_value_1336, 'member_slot_0059', False))
                local_value_0873, local_value_1010 = execute_step_0885(dts, delta_bias, local_value_1336.g_ratio)
                local_value_0435 = local_value_1650.arange(B, device=ys.device)[:, None, None]
                local_value_1648 = local_value_1650.arange(L, device=ys.device)[None, :, None]
                local_value_0875 = ys[local_value_0435, local_value_0873, local_value_1648]
                if local_value_1680:
                    local_value_0876 = local_value_0875.detach()
                local_value_0875 = local_value_1336.member_slot_0303(local_value_0875)
                ys[local_value_0435, local_value_0873, local_value_1648] = local_value_0875
                local_value_1011 = ys[local_value_0435, local_value_1010, local_value_1648]
                if local_value_1680:
                    local_value_1012 = local_value_1011.detach()
                local_value_1011 = local_value_1336.member_slot_0338(local_value_1011, H, W)
                ys[local_value_0435, local_value_1010, local_value_1648] = local_value_1011
                if local_value_1680:
                    with local_value_1650.no_grad():
                        if local_value_0696:
                            local_value_0797 = local_value_0117.softplus(dts.detach().float() + delta_bias.detach().float().view(1, -1, 1))
                        else:
                            local_value_0797 = dts.detach().float() + delta_bias.detach().float().view(1, -1, 1)
                        local_value_0872 = local_value_1336.execute_step_0396(local_value_0876, local_value_1042=getattr(local_value_1336, 'member_slot_0068', 64))
                        local_value_1009 = local_value_1336.execute_step_0396(local_value_1012, local_value_1042=getattr(local_value_1336, 'member_slot_0068', 64))
                        local_value_1336.member_slot_0067 = dict(H=H, W=W, L=L, g_ratio=local_value_1336.g_ratio, delta=local_value_0797.detach().cpu(), delta_raw=dts.detach().cpu(), delta_bias=delta_bias.detach().cpu(), global_index=local_value_0873.detach().cpu(), local_index=local_value_1010.detach().cpu(), global_attention_score=None if local_value_0872 is None else local_value_0872.detach().cpu(), local_attention_score=None if local_value_1009 is None else local_value_1009.detach().cpu(), global_token_response=local_value_0876.abs().mean(dim=-1).view(B, H, W).detach().cpu(), local_token_response=local_value_1012.abs().mean(dim=-1).view(B, H, W).detach().cpu())
            ys = ys.view(B, local_value_0156, -1, H, W)
            y: local_value_1650.Tensor = execute_step_0541(ys, in_channel_first=True, out_channel_first=True, local_value_1308=local_value_0383, local_value_0854=local_value_1305)
            if getattr(local_value_1336, '__DEBUG__', False):
                setattr(local_value_1336, '__data__', dict(A_logs=local_value_1336.A_logs, Bs=Bs, Cs=Cs, Ds=Ds, us=local_value_1733, dts=dts, delta_bias=delta_bias, ys=ys, y=y, H=H, W=W))
        y = y.view(B, -1, H, W)
        if not channel_first:
            y = y.view(B, -1, H * W).transpose(dim0=1, dim1=2).contiguous().view(B, H, W, -1)
        y = local_value_1155(y)
        return y.to(local_value_1699.dtype)

    def execute_step_0863(local_value_1336, local_value_1699: local_value_1650.Tensor, **local_value_1007):
        local_value_1699 = local_value_1336.member_slot_0319(local_value_1699)
        if not local_value_1336.member_slot_0247:
            local_value_1699, local_value_1753 = local_value_1699.chunk(2, dim=1 if local_value_1336.channel_first else -1)
            if not local_value_1336.member_slot_0248:
                local_value_1753 = local_value_1336.member_slot_0149(local_value_1753)
        if not local_value_1336.channel_first:
            local_value_1699 = local_value_1699.permute(0, 3, 1, 2).contiguous()
        if local_value_1336.member_slot_0477:
            local_value_1699 = local_value_1336.conv2d(local_value_1699)
        local_value_1699 = local_value_1336.member_slot_0149(local_value_1699)
        y = local_value_1336.member_slot_0278(local_value_1699)
        y = local_value_1336.member_slot_0377(y)
        if not local_value_1336.member_slot_0247:
            y = y * local_value_1753
        out = local_value_1336.dropout(local_value_1336.member_slot_0381(y))
        return out

    @staticmethod
    def execute_step_0888(forward_type='', local_value_0608=192, channel_first=True):

        def execute_step_0510(local_value_1620, local_value_1674):
            local_value_1274 = local_value_1674[-len(local_value_1620):] == local_value_1620
            if local_value_1274:
                local_value_1674 = local_value_1674[:-len(local_value_1620)]
            return (local_value_1274, local_value_1674)
        ComponentUnit0167 = ComponentUnit0169 if channel_first else local_value_1094.LayerNorm
        local_value_1158, forward_type = execute_step_0510('_onnone', forward_type)
        local_value_1157, forward_type = execute_step_0510('_ondwconv3', forward_type)
        local_value_1156, forward_type = execute_step_0510('_oncnorm', forward_type)
        local_value_1160, forward_type = execute_step_0510('_onsoftmax', forward_type)
        local_value_1159, forward_type = execute_step_0510('_onsigmoid', forward_type)
        local_value_1155 = local_value_1094.Identity()
        if local_value_1158:
            local_value_1155 = local_value_1094.Identity()
        elif local_value_1156:
            local_value_1155 = local_value_1094.Sequential(ComponentUnit0167(local_value_0608), local_value_1094.Identity() if channel_first else ComponentUnit0204(0, 3, 1, 2), local_value_1094.Conv2d(local_value_0608, local_value_0608, kernel_size=3, padding=1, groups=local_value_0608, bias=False), local_value_1094.Identity() if channel_first else ComponentUnit0204(0, 2, 3, 1))
        elif local_value_1157:
            local_value_1155 = local_value_1094.Sequential(local_value_1094.Identity() if channel_first else ComponentUnit0204(0, 3, 1, 2), local_value_1094.Conv2d(local_value_0608, local_value_0608, kernel_size=3, padding=1, groups=local_value_0608, bias=False), local_value_1094.Identity() if channel_first else ComponentUnit0204(0, 2, 3, 1))
        elif local_value_1160:
            local_value_1155 = ComponentUnit0234(dim=-1 if channel_first else 1)
        elif local_value_1159:
            local_value_1155 = local_value_1094.Sigmoid()
        else:
            local_value_1155 = ComponentUnit0167(local_value_0608)
        return (local_value_1155, forward_type)

    @staticmethod
    def execute_step_0510(local_value_1620, local_value_1674):
        local_value_1274 = local_value_1674[-len(local_value_1620):] == local_value_1620
        if local_value_1274:
            local_value_1674 = local_value_1674[:-len(local_value_1620)]
        return (local_value_1274, local_value_1674)

class ComponentUnit0224:

    def execute_step_0287(local_value_1336, d_model=96, d_state=16, ssm_ratio=2.0, dt_rank='auto', d_conv=3, conv_bias=True, dropout=0.0, bias=False, dt_min=0.001, dt_max=0.1, execute_step_0772='random', dt_scale=1.0, dt_init_floor=0.0001, initialize='v0', forward_type='v2', channel_first=False, **local_value_1007):
        super().__init__()
        local_value_0608 = int(ssm_ratio * d_model)
        dt_rank = local_value_1039.ceil(d_model / 16) if dt_rank == 'auto' else dt_rank
        local_value_1336.channel_first = channel_first
        local_value_1336.d_state = d_state
        local_value_1336.dt_rank = dt_rank
        local_value_1336.local_value_0608 = local_value_0608
        k_group = 4
        local_value_1336.member_slot_0477 = d_conv > 1
        local_value_0172 = ComponentUnit0173 if channel_first else local_value_1094.Linear
        local_value_1336.forward = local_value_1336.execute_step_0864
        execute_step_0510 = ComponentUnit0223.execute_step_0510
        local_value_1336.local_value_1155, forward_type = ComponentUnit0223.execute_step_0888(forward_type, local_value_0608, channel_first)
        local_value_1336.member_slot_0374, forward_type = execute_step_0510('_mul', forward_type)
        local_value_1336.member_slot_0370, forward_type = execute_step_0510('_act', forward_type)
        local_value_1336.member_slot_0266 = local_value_1094.Identity() if local_value_1336.member_slot_0374 else None
        local_value_1336.member_slot_0377 = local_value_1094.GELU() if local_value_1336.member_slot_0370 else local_value_1094.Identity()
        mode = forward_type[:4]
        assert mode in ['xv1a', 'xv2a', 'xv3a']
        local_value_1336.forward = local_value_1197(local_value_1336.execute_step_0864, mode=mode)
        local_value_1336.member_slot_0263 = dict(xv1a=local_value_1336.dt_rank, xv2a=local_value_1336.local_value_0608, xv3a=4 * local_value_1336.dt_rank)[mode]
        local_value_0609 = local_value_0608 + local_value_1336.member_slot_0263 + 8 * d_state
        local_value_1336.member_slot_0319 = local_value_0172(d_model, local_value_0609, bias=bias)
        local_value_1336.member_slot_0217 = False
        local_value_1336.member_slot_0315 = False
        local_value_1336.member_slot_0371 = False
        local_value_1336.member_slot_0372 = False
        if local_value_1336.member_slot_0477:
            local_value_0471, forward_type = execute_step_0510('_ca', forward_type)
            local_value_0472, forward_type = execute_step_0510('_ca1', forward_type)
            local_value_1336.local_value_0471 = local_value_1094.SiLU() if local_value_0471 else local_value_1094.Identity()
            local_value_1336.local_value_0471 = local_value_1094.GELU() if local_value_0472 else local_value_1336.local_value_0471
            local_value_1336.member_slot_0372, forward_type = execute_step_0510('_ocov2', forward_type)
            local_value_1336.member_slot_0371, forward_type = execute_step_0510('_ocov', forward_type)
            local_value_1336.member_slot_0217, forward_type = execute_step_0510('_cpos', forward_type)
            local_value_1336.member_slot_0315 = not local_value_1336.member_slot_0371 and (not local_value_1336.member_slot_0372)
            if local_value_1336.member_slot_0315:
                local_value_1336.conv2d = local_value_1094.Conv2d(in_channels=d_model, out_channels=d_model, groups=d_model, bias=conv_bias, kernel_size=d_conv, padding=(d_conv - 1) // 2)
            if local_value_1336.member_slot_0371:
                local_value_1336.member_slot_0373 = local_value_1094.Conv2d(in_channels=local_value_0608, out_channels=local_value_0608, groups=local_value_0608, bias=conv_bias, kernel_size=d_conv, padding=(d_conv - 1) // 2)
            if local_value_1336.member_slot_0372:
                local_value_1336.conv2d = local_value_1094.Conv2d(in_channels=local_value_0609, out_channels=local_value_0609, groups=local_value_0609, bias=conv_bias, kernel_size=d_conv, padding=(d_conv - 1) // 2)
        local_value_1336.member_slot_0381 = local_value_0172(local_value_0608, d_model, bias=bias)
        local_value_1336.dropout = local_value_1094.Dropout(dropout) if dropout > 0.0 else local_value_1094.Identity()
        if initialize in ['v0']:
            local_value_1336.A_logs, local_value_1336.Ds, local_value_1336.local_value_0788, local_value_1336.local_value_0787 = ComponentUnit1033.execute_step_0964(d_state, dt_rank, local_value_0608, dt_scale, execute_step_0772, dt_min, dt_max, dt_init_floor, k_group=4)
        elif initialize in ['v1']:
            local_value_1336.Ds = local_value_1094.Parameter(local_value_1650.ones(k_group * local_value_0608))
            local_value_1336.A_logs = local_value_1094.Parameter(local_value_1650.randn((k_group * local_value_0608, d_state)))
            local_value_1336.local_value_0788 = local_value_1094.Parameter(local_value_1650.randn((k_group, local_value_0608, dt_rank)))
            local_value_1336.local_value_0787 = local_value_1094.Parameter(local_value_1650.randn((k_group, local_value_0608)))
        elif initialize in ['v2']:
            local_value_1336.Ds = local_value_1094.Parameter(local_value_1650.ones(k_group * local_value_0608))
            local_value_1336.A_logs = local_value_1094.Parameter(local_value_1650.zeros((k_group * local_value_0608, d_state)))
            local_value_1336.local_value_0788 = local_value_1094.Parameter(0.1 * local_value_1650.rand((k_group, local_value_0608, dt_rank)))
            local_value_1336.local_value_0787 = local_value_1094.Parameter(0.1 * local_value_1650.rand((k_group, local_value_0608)))
        if forward_type.startswith('xv2'):
            del local_value_1336.local_value_0788
            local_value_1336.local_value_0788 = None

    def execute_step_0864(local_value_1336, local_value_1699: local_value_1650.Tensor, **local_value_1007):
        B, (H, W) = (local_value_1699.shape[0], local_value_1699.shape[2:4] if local_value_1336.channel_first else local_value_1699.shape[1:3])
        L = H * W
        local_value_0853 = False
        local_value_0696 = True
        local_value_1155 = local_value_1336.local_value_1155
        local_value_1644 = True
        local_value_1645 = lambda *local_value_0416: (local_value_0288.to(local_value_1650.float32) for local_value_0288 in local_value_0416)

        def execute_step_1314(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696):
            return execute_step_1330(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, oflex=True, local_value_0430=None)
        if local_value_1336.member_slot_0315:
            local_value_1699 = local_value_1336.local_value_0471(local_value_1336.conv2d(local_value_1699))
        elif local_value_1336.member_slot_0217:
            local_value_1699 = local_value_1699 + local_value_1336.conv2d(local_value_1699)
        local_value_1699 = local_value_1336.member_slot_0319(local_value_1699)
        if local_value_1336.member_slot_0372:
            local_value_1699 = local_value_1336.conv2d(local_value_1699)
        us, dts, Bs, Cs = local_value_1699.split([local_value_1336.local_value_0608, local_value_1336.member_slot_0263, 4 * local_value_1336.d_state, 4 * local_value_1336.d_state], dim=1 if local_value_1336.channel_first else -1)
        local_value_0395 = us
        us = execute_step_0546(us.contiguous(), in_channel_first=local_value_1336.channel_first, out_channel_first=True).view(B, -1, L)
        Bs = execute_step_0546(Bs.contiguous(), in_channel_first=local_value_1336.channel_first, out_channel_first=True, local_value_1132=True).view(B, 4, -1, L)
        Cs = execute_step_0546(Cs.contiguous(), in_channel_first=local_value_1336.channel_first, out_channel_first=True, local_value_1132=True).view(B, 4, -1, L)
        dts = execute_step_0546(dts.contiguous(), in_channel_first=local_value_1336.channel_first, out_channel_first=True, local_value_1132=local_value_1336.member_slot_0263 == 4 * local_value_1336.dt_rank).view(B, L, -1)
        if local_value_1336.member_slot_0263 == local_value_1336.dt_rank:
            dts = local_value_0117.conv1d(dts, local_value_1336.local_value_0788.view(4 * local_value_1336.local_value_0608, local_value_1336.dt_rank, 1), None, groups=4)
        elif local_value_1336.member_slot_0263 == 4 * local_value_1336.dt_rank:
            dts = local_value_0117.conv1d(dts, local_value_1336.local_value_0788.view(4 * local_value_1336.local_value_0608, local_value_1336.dt_rank, 1), None, groups=4)
        local_value_0009 = -local_value_1336.A_logs.to(local_value_1650.float).exp()
        Ds = local_value_1336.Ds.to(local_value_1650.float)
        delta_bias = local_value_1336.local_value_0787.view(-1).to(local_value_1650.float)
        if local_value_0853:
            us, dts, Bs, Cs = local_value_1645(us, dts, Bs, Cs)
        ys: local_value_1650.Tensor = execute_step_1314(us, dts, local_value_0009, Bs, Cs, Ds, delta_bias, local_value_0696).view(B, 4, -1, H, W)
        y: local_value_1650.Tensor = execute_step_0541(ys.contiguous(), in_channel_first=local_value_1336.channel_first, out_channel_first=True)
        y = y.view(B, -1, H, W) if local_value_1336.channel_first else y.view(B, H, W, -1)
        y = local_value_1155(y)
        if getattr(local_value_1336, '__DEBUG__', False):
            setattr(local_value_1336, '__data__', dict(A_logs=local_value_1336.A_logs, Bs=Bs, Cs=Cs, Ds=Ds, us=us, dts=dts, delta_bias=delta_bias, ys=ys, y=y))
        y = y.to(local_value_1699.dtype) if local_value_1644 else y
        y = local_value_1336.member_slot_0377(y)
        if local_value_1336.member_slot_0374:
            y = y * local_value_0395
        if local_value_1336.member_slot_0371:
            y = y + local_value_1336.local_value_0471(local_value_1336.member_slot_0373(local_value_0395))
        out = local_value_1336.dropout(local_value_1336.member_slot_0381(y))
        return out

class ComponentUnit0221:

    def execute_step_0284(local_value_1336, d_model=96, d_state=16, ssm_ratio=2.0, dt_rank='auto', act_layer=local_value_1094.GELU, d_conv=3, conv_bias=True, dropout=0.0, bias=False, dt_min=0.001, dt_max=0.1, execute_step_0772='random', dt_scale=1.0, dt_init_floor=0.0001, initialize='v2', forward_type='m0', local_value_1696=False, **local_value_1007):
        local_value_0835 = {'device': None, 'dtype': None}
        super().__init__()
        local_value_0608 = int(ssm_ratio * d_model)
        dt_rank = local_value_1039.ceil(d_model / 16) if dt_rank == 'auto' else dt_rank
        assert local_value_0608 % dt_rank == 0
        local_value_1336.member_slot_0477 = d_conv > 1
        local_value_0172 = local_value_1094.Linear
        local_value_1336.forward = local_value_1336.execute_step_0861
        execute_step_0510 = ComponentUnit0223.execute_step_0510
        local_value_1336.member_slot_0246, forward_type = execute_step_0510('_no32', forward_type)
        local_value_1336.member_slot_0370, forward_type = execute_step_0510('_oact', forward_type)
        local_value_1336.member_slot_0247, forward_type = execute_step_0510('_noz', forward_type)
        local_value_1336.member_slot_0248, forward_type = execute_step_0510('_nozact', forward_type)
        local_value_1336.local_value_1155, forward_type = ComponentUnit0223.execute_step_0888(forward_type, local_value_0608, False)
        local_value_0119 = dict(m0=local_value_1197(local_value_1336.execute_step_0858, local_value_0853=False, local_value_0759=d_state))
        local_value_1336.member_slot_0278 = local_value_0119.get(forward_type, None)
        k_group = 4
        local_value_0617 = local_value_0608 if local_value_1336.member_slot_0247 else local_value_0608 * 2
        local_value_1336.member_slot_0319 = local_value_0172(d_model, local_value_0617, bias=bias)
        local_value_1336.member_slot_0149: local_value_1094.Module = act_layer()
        if local_value_1336.member_slot_0477:
            local_value_1336.conv2d = local_value_1094.Sequential(ComponentUnit0204(0, 3, 1, 2), local_value_1094.Conv2d(in_channels=local_value_0608, out_channels=local_value_0608, groups=local_value_0608, bias=conv_bias, kernel_size=d_conv, padding=(d_conv - 1) // 2, **local_value_0835), ComponentUnit0204(0, 2, 3, 1))
        local_value_1336.member_slot_0479 = [local_value_1094.Linear(local_value_0608, dt_rank + d_state * 2, bias=False) for local_value_0272 in range(k_group)]
        local_value_1336.member_slot_0481 = local_value_1094.Parameter(local_value_1650.stack([local_value_1618.weight for local_value_1618 in local_value_1336.member_slot_0479], dim=0))
        del local_value_1336.member_slot_0479
        local_value_1336.member_slot_0377 = local_value_1094.GELU() if local_value_1336.member_slot_0370 else local_value_1094.Identity()
        local_value_1336.member_slot_0381 = local_value_0172(local_value_0608, d_model, bias=bias)
        local_value_1336.dropout = local_value_1094.Dropout(dropout) if dropout > 0.0 else local_value_1094.Identity()
        if initialize in ['v1']:
            local_value_1336.Ds = local_value_1094.Parameter(local_value_1650.ones((k_group, dt_rank, int(local_value_0608 // dt_rank))))
            local_value_1336.A_logs = local_value_1094.Parameter(local_value_1650.randn((k_group, dt_rank)))
            local_value_1336.local_value_0787 = local_value_1094.Parameter(0.1 * local_value_1650.randn((k_group, dt_rank)))
        elif initialize in ['v2']:
            local_value_1336.Ds = local_value_1094.Parameter(local_value_1650.ones((k_group, dt_rank, int(local_value_0608 // dt_rank))))
            local_value_1336.A_logs = local_value_1094.Parameter(local_value_1650.zeros((k_group, dt_rank)))
            local_value_1336.local_value_0787 = local_value_1094.Parameter(0.1 * local_value_1650.rand((k_group, dt_rank)))
        local_value_1336.initial_state = None
        if local_value_1696:
            local_value_1336.initial_state = local_value_1094.Parameter(local_value_1650.zeros((1, k_group * dt_rank, int(local_value_0608 // dt_rank), d_state)), requires_grad=False)

    def execute_step_0858(local_value_1336, local_value_1699: local_value_1650.Tensor=None, local_value_0853=False, local_value_0513=64, local_value_0759=64, local_value_1315=None, local_value_1306='cross2d', local_value_1305=False, **local_value_1007):
        assert local_value_1306 in ['unidi', 'bidi', 'cross2d']
        assert local_value_1315 in [None, 'triton', 'torch']
        local_value_1719 = getattr(local_value_1336, 'local_value_1719', None)
        local_value_1645 = lambda *local_value_0416: (local_value_0288.to(local_value_1650.float32) for local_value_0288 in local_value_0416)
        N = local_value_0759
        B, H, W, local_value_0208 = local_value_1699.shape
        local_value_0156, local_value_0207 = local_value_1336.A_logs.shape
        local_value_0156, local_value_0207, D = local_value_1336.Ds.shape
        assert local_value_0208 == local_value_0207 * D
        L = H * W
        local_value_0158 = local_value_0156 * local_value_0207
        local_value_0383 = dict(cross2d=0, unidi=1, bidi=2, cascade2d=3)[local_value_1306]
        initial_state = None
        if local_value_1336.initial_state is not None:
            assert local_value_1336.initial_state.shape[-1] == local_value_0759
            initial_state = local_value_1336.initial_state.detach().repeat(B, 1, 1, 1)
        local_value_1733 = execute_step_0546(local_value_1699.view(B, H, W, local_value_0208), in_channel_first=False, out_channel_first=False, local_value_1308=local_value_0383, local_value_0854=local_value_1305)
        local_value_1708 = local_value_1650.einsum('b l k d, k c d -> b l k c', local_value_1733, local_value_1336.member_slot_0481)
        if local_value_1719 is not None:
            local_value_1708 = local_value_1708 + local_value_1719.view(1, -1, local_value_0156, 1)
        dts, Bs, Cs = local_value_1650.split(local_value_1708, [local_value_0207, N, N], dim=3)
        local_value_1733 = local_value_1733.contiguous().view(B, L, local_value_0158, D)
        dts = dts.contiguous().view(B, L, local_value_0158)
        Bs = Bs.contiguous().view(B, L, local_value_0156, N)
        Cs = Cs.contiguous().view(B, L, local_value_0156, N)
        if local_value_0853:
            local_value_1733, dts, Bs, Cs = local_value_1645(local_value_1733, dts, Bs, Cs)
        local_value_0009 = -local_value_1336.A_logs.to(local_value_1650.float).exp().view(local_value_0158)
        Ds = local_value_1336.Ds.to(local_value_1650.float).view(local_value_0158, D)
        local_value_0767 = local_value_1336.local_value_0787.view(local_value_0158)
        if local_value_0853:
            local_value_1733, dts, Bs, Cs = local_value_1645(local_value_1733, dts, Bs, Cs)
        ys, local_value_0837 = execute_step_1318(local_value_1733, dts, local_value_0009, Bs, Cs, local_value_0513=local_value_0513, D=Ds, local_value_0767=local_value_0767, local_value_0970=initial_state, local_value_0794=True, local_value_1276=True, local_value_0430=local_value_1315)
        y: local_value_1650.Tensor = execute_step_0541(ys.view(B, H, W, local_value_0156, local_value_0208), in_channel_first=False, out_channel_first=False, local_value_1308=local_value_0383, local_value_0854=local_value_1305)
        if getattr(local_value_1336, '__DEBUG__', False):
            setattr(local_value_1336, '__data__', dict(A_logs=local_value_1336.A_logs, Bs=Bs, Cs=Cs, Ds=local_value_1336.Ds, us=local_value_1733, dts=dts, delta_bias=local_value_1336.local_value_0787, initial_state=local_value_1336.initial_state, final_satte=local_value_0837, ys=ys, y=y, H=H, W=W))
        if local_value_1336.initial_state is not None:
            local_value_1336.initial_state = local_value_1094.Parameter(local_value_0837.detach().sum(0, keepdim=True), requires_grad=False)
        y = local_value_1336.local_value_1155(y.view(B, H, W, -1))
        return y.to(local_value_1699.dtype)

    def execute_step_0861(local_value_1336, local_value_1699: local_value_1650.Tensor, **local_value_1007):
        local_value_1699 = local_value_1336.member_slot_0319(local_value_1699)
        if not local_value_1336.member_slot_0247:
            local_value_1699, local_value_1753 = local_value_1699.chunk(2, dim=1 if local_value_1336.channel_first else -1)
            if not local_value_1336.member_slot_0248:
                local_value_1753 = local_value_1336.member_slot_0149(local_value_1753)
        if local_value_1336.member_slot_0477:
            local_value_1699 = local_value_1336.conv2d(local_value_1699)
        local_value_1699 = local_value_1336.member_slot_0149(local_value_1699)
        y = local_value_1336.member_slot_0278(local_value_1699)
        y = local_value_1336.member_slot_0377(y)
        if not local_value_1336.member_slot_0247:
            y = y * local_value_1753
        out = local_value_1336.dropout(local_value_1336.member_slot_0381(y))
        return out

class ComponentUnit0220(local_value_1094.Module, ComponentUnit0222, ComponentUnit0223, ComponentUnit0224, ComponentUnit0221):

    def __init__(local_value_1336, d_model=96, d_state=16, ssm_ratio=2.0, dt_rank='auto', act_layer=local_value_1094.SiLU, d_conv=3, conv_bias=True, dropout=0.0, bias=False, dt_min=0.001, dt_max=0.1, execute_step_0772='random', dt_scale=1.0, dt_init_floor=0.0001, initialize='v0', forward_type='v2', channel_first=False, **local_value_1007):
        local_value_1094.Module.__init__(local_value_1336)
        local_value_1007.update(d_model=d_model, d_state=d_state, ssm_ratio=ssm_ratio, dt_rank=dt_rank, act_layer=act_layer, d_conv=d_conv, conv_bias=conv_bias, dropout=dropout, bias=bias, dt_min=dt_min, dt_max=dt_max, execute_step_0772=execute_step_0772, dt_scale=dt_scale, dt_init_floor=dt_init_floor, initialize=initialize, forward_type=forward_type, channel_first=channel_first)
        if forward_type in ['v0', 'v0seq']:
            local_value_1336.execute_step_0285(local_value_1338='local_value_1338' in forward_type, **local_value_1007)
        elif forward_type.startswith('xv'):
            local_value_1336.execute_step_0287(**local_value_1007)
        elif forward_type.startswith('local_value_1028'):
            local_value_1336.execute_step_0284(**local_value_1007)
        else:
            local_value_1336.execute_step_0286(**local_value_1007)

class ComponentUnit0167(local_value_1094.LayerNorm):

    def __init__(local_value_1336, *local_value_0416, channel_first=None, in_channel_first=False, out_channel_first=False, **local_value_1007):
        local_value_1094.LayerNorm.__init__(local_value_1336, *local_value_0416, **local_value_1007)
        if channel_first is not None:
            in_channel_first = channel_first
            out_channel_first = channel_first
        local_value_1336.in_channel_first = in_channel_first
        local_value_1336.out_channel_first = out_channel_first

    def forward(local_value_1336, local_value_1699: local_value_1650.Tensor):
        if local_value_1336.in_channel_first:
            local_value_1699 = local_value_1699.permute(0, 2, 3, 1)
        local_value_1699 = local_value_1094.LayerNorm.forward(local_value_1336, local_value_1699)
        if local_value_1336.out_channel_first:
            local_value_1699 = local_value_1699.permute(0, 3, 1, 2)
        return local_value_1699

class ContextMixingBlock(local_value_1094.Module):

    def __init__(local_value_1336, hidden_dim: int=0, local_value_0752: float=0, norm_layer: local_value_1094.Module=ComponentUnit0167, channel_first=False, local_value_1380: int=16, ssm_ratio=2.0, local_value_1382: local_value_0008='auto', local_value_1377=local_value_1094.SiLU, local_value_1378: int=3, local_value_1379=True, local_value_1381: float=0, local_value_1383='v0', forward_type='v2', use_global_local=True, local_value_1054=4.0, local_value_1051=local_value_1094.GELU, local_value_1052: float=0.0, local_value_0895=False, local_value_1670: bool=False, local_value_1219: bool=False, local_value_0282: type=ComponentUnit0220, execute_step_0530=False, **local_value_1007):
        super().__init__()
        local_value_1336.member_slot_0454 = ssm_ratio > 0
        local_value_1336.member_slot_0355 = local_value_1054 > 0
        local_value_1336.local_value_1670 = local_value_1670
        local_value_1336.local_value_1219 = local_value_1219
        if local_value_1336.member_slot_0454:
            local_value_1336.norm = norm_layer(hidden_dim, channel_first=channel_first)
            local_value_1336.member_slot_0376 = local_value_0282(d_model=hidden_dim, d_state=local_value_1380, ssm_ratio=ssm_ratio, dt_rank=local_value_1382, act_layer=local_value_1377, d_conv=local_value_1378, conv_bias=local_value_1379, dropout=local_value_1381, initialize=local_value_1383, forward_type=forward_type, channel_first=channel_first, use_global_local=use_global_local, execute_step_0530=execute_step_0530)
        local_value_1336.local_value_0752 = local_value_0112(local_value_0752)
        if local_value_1336.member_slot_0355:
            local_value_0280 = ComponentUnit0187 if not local_value_0895 else ComponentUnit0871
            local_value_1336.member_slot_0363 = ComponentUnit0167(hidden_dim, channel_first=channel_first)
            local_value_1053 = int(hidden_dim * local_value_1054)
            local_value_1336.member_slot_0350 = local_value_0280(in_features=hidden_dim, hidden_features=local_value_1053, act_layer=local_value_1051, drop=local_value_1052, channels_first=channel_first)

    def execute_step_1349(local_value_1336, local_value_0827: bool=True, local_value_1042: int=64):
        local_value_1336.member_slot_0059 = bool(local_value_0827)
        if hasattr(local_value_1336, 'member_slot_0376') and hasattr(local_value_1336.member_slot_0376, 'execute_step_1349'):
            local_value_1336.member_slot_0376.execute_step_1349(local_value_0827=local_value_0827, local_value_1042=local_value_1042)
        return local_value_1336

    def execute_step_0891(local_value_1336, local_value_0523: bool=False):
        if hasattr(local_value_1336, 'member_slot_0376') and hasattr(local_value_1336.member_slot_0376, 'execute_step_0891'):
            return local_value_1336.member_slot_0376.execute_step_0891(local_value_0523=local_value_0523)
        return None

    def execute_step_0341(local_value_1336, input: local_value_1650.Tensor):
        local_value_1699 = input
        if local_value_1336.member_slot_0454:
            if local_value_1336.local_value_1219:
                local_value_1699 = local_value_1699 + local_value_1336.local_value_0752(local_value_1336.norm(local_value_1336.member_slot_0376(local_value_1699)))
            else:
                local_value_1699 = local_value_1699 + local_value_1336.local_value_0752(local_value_1336.member_slot_0376(local_value_1336.norm(local_value_1699)))
        if local_value_1336.member_slot_0355:
            if local_value_1336.local_value_1219:
                local_value_1699 = local_value_1699 + local_value_1336.local_value_0752(local_value_1336.member_slot_0363(local_value_1336.member_slot_0350(local_value_1699)))
            else:
                local_value_1699 = local_value_1699 + local_value_1336.local_value_0752(local_value_1336.member_slot_0350(local_value_1336.member_slot_0363(local_value_1699)))
        return local_value_1699

    def forward(local_value_1336, input: local_value_1650.Tensor):
        if local_value_1336.local_value_1670:
            return local_value_0509.checkpoint(local_value_1336.execute_step_0341, input)
        else:
            return local_value_1336.execute_step_0341(input)

class ComponentUnit0247(local_value_1094.Module):

    def __init__(local_value_1336, local_value_1200=4, local_value_0958=3, local_value_1109=1000, depths=[2, 2, 9, 2], dims=[96, 192, 384, 768], local_value_1380=16, ssm_ratio=2.0, local_value_1382='auto', local_value_1377='silu', local_value_1378=3, local_value_1379=True, local_value_1381=0.0, local_value_1383='v0', forward_type='v2', local_value_1054=4.0, local_value_1051='gelu', local_value_1052=0.0, local_value_0895=False, local_value_0753=0.1, local_value_1199=True, norm_layer='LN', local_value_0736: str='v2', local_value_1202: str='v1', local_value_1670=False, local_value_1218=False, local_value_0955=224, local_value_0282=ComponentUnit0220, **local_value_1007):
        super().__init__()
        local_value_1336.channel_first = norm_layer.lower() in ['bn', 'ln2d']
        local_value_1336.local_value_1109 = local_value_1109
        local_value_1336.member_slot_0369 = len(depths)
        if isinstance(dims, int):
            dims = [int(dims * 2 ** local_value_0946) for local_value_0946 in range(local_value_1336.member_slot_0369)]
        local_value_1336.member_slot_0367 = dims[-1]
        local_value_1336.dims = dims
        local_value_0738 = [local_value_1699.item() for local_value_1699 in local_value_1650.linspace(0, local_value_0753, sum(depths))]
        local_value_0281 = dict(ln=local_value_1094.LayerNorm, ln2d=ComponentUnit0169, bn=local_value_1094.BatchNorm2d)
        local_value_0273 = dict(silu=local_value_1094.SiLU, gelu=local_value_1094.GELU, relu=local_value_1094.ReLU, sigmoid=local_value_1094.Sigmoid)
        norm_layer: local_value_1094.Module = local_value_0281.get(norm_layer.lower(), None)
        local_value_1377: local_value_1094.Module = local_value_0273.get(local_value_1377.lower(), None)
        local_value_1051: local_value_1094.Module = local_value_0273.get(local_value_1051.lower(), None)
        local_value_1336.local_value_1215 = local_value_1336.execute_step_0381(dims[0], local_value_1200, local_value_0955) if local_value_1218 else None
        execute_step_0365 = dict(v1=local_value_1336.execute_step_0365, v2=local_value_1336.execute_step_0366).get(local_value_1202, None)
        local_value_1336.member_slot_0386 = execute_step_0365(local_value_0958, dims[0], local_value_1200, local_value_1199, norm_layer, channel_first=local_value_1336.channel_first)
        execute_step_0361 = dict(v1=ComponentUnit0202, v2=local_value_1336.execute_step_0361, v3=local_value_1336.execute_step_0362, none=lambda *local_value_0272, **local_value_0354: None).get(local_value_0736, None)
        local_value_1336.member_slot_0333 = local_value_1094.ModuleList()
        for local_value_0946 in range(local_value_1336.member_slot_0369):
            downsample = execute_step_0361(local_value_1336.dims[local_value_0946], local_value_1336.dims[local_value_0946 + 1], norm_layer=norm_layer, channel_first=local_value_1336.channel_first) if local_value_0946 < local_value_1336.member_slot_0369 - 1 else local_value_1094.Identity()
            local_value_1336.member_slot_0333.append(local_value_1336.execute_step_0364(dim=local_value_1336.dims[local_value_0946], local_value_0752=local_value_0738[sum(depths[:local_value_0946]):sum(depths[:local_value_0946 + 1])], local_value_1670=local_value_1670, norm_layer=norm_layer, downsample=downsample, channel_first=local_value_1336.channel_first, local_value_1380=local_value_1380, ssm_ratio=ssm_ratio, local_value_1382=local_value_1382, local_value_1377=local_value_1377, local_value_1378=local_value_1378, local_value_1379=local_value_1379, local_value_1381=local_value_1381, local_value_1383=local_value_1383, forward_type=forward_type, local_value_1054=local_value_1054, local_value_1051=local_value_1051, local_value_1052=local_value_1052, local_value_0895=local_value_0895, local_value_0282=local_value_0282))
        local_value_1336.member_slot_0208 = local_value_1094.Sequential(local_value_0200(norm=norm_layer(local_value_1336.member_slot_0367), permute=ComponentUnit0204(0, 3, 1, 2) if not local_value_1336.channel_first else local_value_1094.Identity(), avgpool=local_value_1094.AdaptiveAvgPool2d(1), flatten=local_value_1094.Flatten(1), head=local_value_1094.Linear(local_value_1336.member_slot_0367, local_value_1109)))
        local_value_1336.apply(local_value_1336.execute_step_0353)

    @staticmethod
    def execute_step_0381(local_value_0826, local_value_1200, local_value_0954):
        local_value_1198, local_value_1201 = (local_value_0954 // local_value_1200, local_value_0954 // local_value_1200)
        local_value_1215 = local_value_1094.Parameter(local_value_1650.zeros(1, local_value_0826, local_value_1198, local_value_1201))
        local_value_1658(local_value_1215, std=0.02)
        return local_value_1215

    def execute_step_0353(local_value_1336, local_value_1028: local_value_1094.Module):
        if isinstance(local_value_1028, local_value_1094.Linear):
            local_value_1658(local_value_1028.weight, std=0.02)
            if isinstance(local_value_1028, local_value_1094.Linear) and local_value_1028.bias is not None:
                local_value_1094.init.constant_(local_value_1028.bias, 0)
        elif isinstance(local_value_1028, local_value_1094.LayerNorm):
            local_value_1094.init.constant_(local_value_1028.bias, 0)
            local_value_1094.init.constant_(local_value_1028.weight, 1.0)

    @local_value_1650.jit.ignore
    def execute_step_1096(local_value_1336):
        return {'local_value_1215'}

    @local_value_1650.jit.ignore
    def execute_step_1097(local_value_1336):
        return {}

    @staticmethod
    def execute_step_0365(local_value_0958=3, local_value_0825=96, local_value_1200=4, local_value_1199=True, norm_layer=local_value_1094.LayerNorm, channel_first=False):
        return local_value_1094.Sequential(local_value_1094.Conv2d(local_value_0958, local_value_0825, kernel_size=local_value_1200, stride=local_value_1200, bias=True), local_value_1094.Identity() if channel_first else ComponentUnit0204(0, 2, 3, 1), norm_layer(local_value_0825) if local_value_1199 else local_value_1094.Identity())

    @staticmethod
    def execute_step_0366(local_value_0958=3, local_value_0825=96, local_value_1200=4, local_value_1199=True, norm_layer=local_value_1094.LayerNorm, channel_first=False):
        stride = local_value_1200 // 2
        kernel_size = stride + 1
        padding = 1
        return local_value_1094.Sequential(local_value_1094.Conv2d(local_value_0958, local_value_0825 // 2, kernel_size=kernel_size, stride=stride, padding=padding), local_value_1094.Identity() if channel_first or not local_value_1199 else ComponentUnit0204(0, 2, 3, 1), norm_layer(local_value_0825 // 2) if local_value_1199 else local_value_1094.Identity(), local_value_1094.Identity() if channel_first or not local_value_1199 else ComponentUnit0204(0, 3, 1, 2), local_value_1094.GELU(), local_value_1094.Conv2d(local_value_0825 // 2, local_value_0825, kernel_size=kernel_size, stride=stride, padding=padding), local_value_1094.Identity() if channel_first else ComponentUnit0204(0, 2, 3, 1), norm_layer(local_value_0825) if local_value_1199 else local_value_1094.Identity())

    @staticmethod
    def execute_step_0361(dim=96, out_dim=192, norm_layer=local_value_1094.LayerNorm, channel_first=False):
        return local_value_1094.Sequential(local_value_1094.Identity() if channel_first else ComponentUnit0204(0, 3, 1, 2), local_value_1094.Conv2d(dim, out_dim, kernel_size=2, stride=2), local_value_1094.Identity() if channel_first else ComponentUnit0204(0, 2, 3, 1), norm_layer(out_dim))

    @staticmethod
    def execute_step_0362(dim=96, out_dim=192, norm_layer=local_value_1094.LayerNorm, channel_first=False):
        return local_value_1094.Sequential(local_value_1094.Identity() if channel_first else ComponentUnit0204(0, 3, 1, 2), local_value_1094.Conv2d(dim, out_dim, kernel_size=3, stride=2, padding=1), local_value_1094.Identity() if channel_first else ComponentUnit0204(0, 2, 3, 1), norm_layer(out_dim))

    @staticmethod
    def execute_step_0364(dim=96, local_value_0752=[0.1, 0.1], local_value_1670=False, norm_layer=local_value_1094.LayerNorm, downsample=local_value_1094.Identity(), channel_first=False, local_value_1380=16, ssm_ratio=2.0, local_value_1382='auto', local_value_1377=local_value_1094.SiLU, local_value_1378=3, local_value_1379=True, local_value_1381=0.0, local_value_1383='v0', forward_type='v2', local_value_1054=4.0, local_value_1051=local_value_1094.GELU, local_value_1052=0.0, local_value_0895=False, local_value_0282=ComponentUnit0220, **local_value_1007):
        local_value_0697 = len(local_value_0752)
        blocks = []
        for d in range(local_value_0697):
            blocks.append(ContextMixingBlock(hidden_dim=dim, local_value_0752=local_value_0752[d], norm_layer=norm_layer, channel_first=channel_first, local_value_1380=local_value_1380, ssm_ratio=ssm_ratio, local_value_1382=local_value_1382, local_value_1377=local_value_1377, local_value_1378=local_value_1378, local_value_1379=local_value_1379, local_value_1381=local_value_1381, local_value_1383=local_value_1383, forward_type=forward_type, local_value_1054=local_value_1054, local_value_1051=local_value_1051, local_value_1052=local_value_1052, local_value_0895=local_value_0895, local_value_1670=local_value_1670, local_value_0282=local_value_0282))
        return local_value_1094.Sequential(local_value_0200(blocks=local_value_1094.Sequential(*blocks), downsample=downsample))

    def forward(local_value_1336, local_value_1699: local_value_1650.Tensor):
        local_value_1699 = local_value_1336.member_slot_0386(local_value_1699)
        if local_value_1336.local_value_1215 is not None:
            local_value_1215 = local_value_1336.local_value_1215.permute(0, 2, 3, 1) if not local_value_1336.channel_first else local_value_1336.local_value_1215
            local_value_1699 = local_value_1699 + local_value_1215
        for local_value_1014 in local_value_1336.member_slot_0333:
            local_value_1699 = local_value_1014(local_value_1699)
        local_value_1699 = local_value_1336.member_slot_0208(local_value_1699)
        return local_value_1699

    def execute_step_0845(local_value_1336, shape=(3, 224, 224), local_value_1678=True):
        supported_ops = {'aten::silu': None, 'aten::neg': None, 'aten::exp': None, 'aten::flip': None, 'prim::PythonOp.ComponentUnit0230': local_value_1197(execute_step_1329, local_value_0430='prefixsum', local_value_1678=local_value_1678)}
        model = local_value_0536.deepcopy(local_value_1336)
        model.cuda().eval()
        input = local_value_1650.randn((1, *shape), device=next(model.parameters()).device)
        execute_step_1195 = local_value_1194(model)['']
        local_value_0124, local_value_1667 = local_value_0843(model=model, inputs=(input,), supported_ops=supported_ops)
        del model, input
        return sum(local_value_0124.values()) * 1000000000.0
        return f'execute_step_1195 {execute_step_1195} GFLOPs {sum(local_value_0124.values())}'

    def _load_from_state_dict(local_value_1336, state_dict, local_value_1222, local_value_1026, local_value_1408, local_value_1049, local_value_1663, local_value_0832):

        def execute_step_0503(src, state_dict: dict=state_dict, local_value_1408=False):
            if local_value_1408:
                if local_value_1222 + src in list(state_dict.keys()):
                    return True
            else:
                key = local_value_1222 + src
                for k in list(state_dict.keys()):
                    if k.startswith(key):
                        return True
            return False

        def execute_step_0492(src, local_value_0758, state_dict: dict=state_dict, local_value_1408=False):
            if local_value_1408:
                if local_value_1222 + src in list(state_dict.keys()):
                    state_dict[local_value_1222 + local_value_0758] = state_dict[local_value_1222 + src]
                    state_dict.pop(local_value_1222 + src)
            else:
                key = local_value_1222 + src
                for k in list(state_dict.keys()):
                    if k.startswith(key):
                        local_value_1082 = local_value_1222 + local_value_0758 + k[len(key):]
                        state_dict[local_value_1082] = state_dict[k]
                        state_dict.pop(k)
        if execute_step_0503('local_value_1215', local_value_1408=True):
            local_value_1366: local_value_1650.Tensor = state_dict[local_value_1222 + 'local_value_1215']
            state_dict[local_value_1222 + 'local_value_1215'] = local_value_0117.interpolate(local_value_1366.float(), size=local_value_1336.local_value_1215.shape[2:4], align_corners=False, mode='bicubic').to(local_value_1366.device)
        execute_step_0492('member_slot_0386.member_slot_0394', 'member_slot_0386.0')
        execute_step_0492('member_slot_0386.norm', 'member_slot_0386.2')
        for local_value_0939 in range(100):
            for local_value_0997 in range(100):
                execute_step_0492(f'member_slot_0333.{local_value_0939}.blocks.{local_value_0997}.ln_1', f'member_slot_0333.{local_value_0939}.blocks.{local_value_0997}.norm')
                execute_step_0492(f'member_slot_0333.{local_value_0939}.blocks.{local_value_0997}.self_attention', f'member_slot_0333.{local_value_0939}.blocks.{local_value_0997}.member_slot_0376')
        execute_step_0492('norm', 'member_slot_0208.norm')
        execute_step_0492('head', 'member_slot_0208.head')
        return super()._load_from_state_dict(state_dict, local_value_1222, local_value_1026, local_value_1408, local_value_1049, local_value_1663, local_value_0832)
