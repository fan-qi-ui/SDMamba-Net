import torch as local_value_1650
import torch.nn as local_value_1094
import torch.nn.functional as local_value_0117

class ComponentUnit0173(local_value_1094.Linear):

    def forward(local_value_1336, local_value_1699: local_value_1650.Tensor):
        return local_value_0117.conv2d(local_value_1699, local_value_1336.weight[:, :, None, None], local_value_1336.bias)

    def _load_from_state_dict(local_value_1336, state_dict, local_value_1222, local_value_1026, local_value_1408, local_value_1049, local_value_1663, local_value_0832):
        state_dict[local_value_1222 + 'weight'] = state_dict[local_value_1222 + 'weight'].view(local_value_1336.weight.shape)
        return super()._load_from_state_dict(state_dict, local_value_1222, local_value_1026, local_value_1408, local_value_1049, local_value_1663, local_value_0832)

class ComponentUnit0169(local_value_1094.LayerNorm):

    def forward(local_value_1336, local_value_1699: local_value_1650.Tensor):
        local_value_1699 = local_value_1699.permute(0, 2, 3, 1)
        local_value_1699 = local_value_1094.functional.layer_norm(local_value_1699, local_value_1336.normalized_shape, local_value_1336.weight, local_value_1336.bias, local_value_1336.eps)
        local_value_1699 = local_value_1699.permute(0, 3, 1, 2)
        return local_value_1699

class ComponentUnit0202(local_value_1094.Module):

    def __init__(local_value_1336, dim, out_dim=-1, norm_layer=local_value_1094.LayerNorm, channel_first=False):
        super().__init__()
        local_value_1336.dim = dim
        local_value_0172 = ComponentUnit0173 if channel_first else local_value_1094.Linear
        local_value_1336.member_slot_0135 = local_value_1336.execute_step_0379 if channel_first else local_value_1336.execute_step_0380
        local_value_1336.reduction = local_value_0172(4 * dim, 2 * dim if out_dim < 0 else out_dim, bias=False)
        local_value_1336.norm = norm_layer(4 * dim)

    @staticmethod
    def execute_step_0380(local_value_1699: local_value_1650.Tensor):
        H, W, local_value_0272 = local_value_1699.shape[-3:]
        if W % 2 != 0 or H % 2 != 0:
            local_value_1699 = local_value_0117.pad(local_value_1699, (0, 0, 0, W % 2, 0, H % 2))
        local_value_1700 = local_value_1699[..., 0::2, 0::2, :]
        local_value_1701 = local_value_1699[..., 1::2, 0::2, :]
        local_value_1702 = local_value_1699[..., 0::2, 1::2, :]
        local_value_1703 = local_value_1699[..., 1::2, 1::2, :]
        local_value_1699 = local_value_1650.cat([local_value_1700, local_value_1701, local_value_1702, local_value_1703], -1)
        return local_value_1699

    @staticmethod
    def execute_step_0379(local_value_1699: local_value_1650.Tensor):
        H, W = local_value_1699.shape[-2:]
        if W % 2 != 0 or H % 2 != 0:
            local_value_1699 = local_value_0117.pad(local_value_1699, (0, 0, 0, W % 2, 0, H % 2))
        local_value_1700 = local_value_1699[..., 0::2, 0::2]
        local_value_1701 = local_value_1699[..., 1::2, 0::2]
        local_value_1702 = local_value_1699[..., 0::2, 1::2]
        local_value_1703 = local_value_1699[..., 1::2, 1::2]
        local_value_1699 = local_value_1650.cat([local_value_1700, local_value_1701, local_value_1702, local_value_1703], 1)
        return local_value_1699

    def forward(local_value_1336, local_value_1699):
        local_value_1699 = local_value_1336.member_slot_0135(local_value_1699)
        local_value_1699 = local_value_1336.norm(local_value_1699)
        local_value_1699 = local_value_1336.reduction(local_value_1699)
        return local_value_1699

class ComponentUnit0204(local_value_1094.Module):

    def __init__(local_value_1336, *local_value_0416):
        super().__init__()
        local_value_1336.local_value_0416 = local_value_0416

    def forward(local_value_1336, local_value_1699: local_value_1650.Tensor):
        return local_value_1699.permute(*local_value_1336.local_value_0416)

class ComponentUnit0187(local_value_1094.Module):

    def __init__(local_value_1336, in_features, hidden_features=None, local_value_1153=None, act_layer=local_value_1094.GELU, drop=0.0, channels_first=False):
        super().__init__()
        local_value_1153 = local_value_1153 or in_features
        hidden_features = hidden_features or in_features
        local_value_0172 = ComponentUnit0173 if channels_first else local_value_1094.Linear
        local_value_1336.member_slot_0267 = local_value_0172(in_features, hidden_features)
        local_value_1336.member_slot_0149 = act_layer()
        local_value_1336.member_slot_0268 = local_value_0172(hidden_features, local_value_1153)
        local_value_1336.drop = local_value_1094.Dropout(drop)

    def forward(local_value_1336, local_value_1699):
        local_value_1699 = local_value_1336.member_slot_0267(local_value_1699)
        local_value_1699 = local_value_1336.member_slot_0149(local_value_1699)
        local_value_1699 = local_value_1336.drop(local_value_1699)
        local_value_1699 = local_value_1336.member_slot_0268(local_value_1699)
        local_value_1699 = local_value_1336.drop(local_value_1699)
        return local_value_1699

class ComponentUnit0871(local_value_1094.Module):

    def __init__(local_value_1336, in_features, hidden_features=None, local_value_1153=None, act_layer=local_value_1094.GELU, drop=0.0, channels_first=False):
        super().__init__()
        local_value_1336.channel_first = channels_first
        local_value_1153 = local_value_1153 or in_features
        hidden_features = hidden_features or in_features
        local_value_0172 = ComponentUnit0173 if channels_first else local_value_1094.Linear
        local_value_1336.member_slot_0267 = local_value_0172(in_features, 2 * hidden_features)
        local_value_1336.member_slot_0149 = act_layer()
        local_value_1336.member_slot_0268 = local_value_0172(hidden_features, local_value_1153)
        local_value_1336.drop = local_value_1094.Dropout(drop)

    def forward(local_value_1336, local_value_1699: local_value_1650.Tensor):
        local_value_1699 = local_value_1336.member_slot_0267(local_value_1699)
        local_value_1699, local_value_1753 = local_value_1699.chunk(2, dim=1 if local_value_1336.channel_first else -1)
        local_value_1699 = local_value_1336.member_slot_0268(local_value_1699 * local_value_1336.member_slot_0149(local_value_1753))
        local_value_1699 = local_value_1336.drop(local_value_1699)
        return local_value_1699

class ComponentUnit0234(local_value_1094.Softmax):

    def forward(local_value_1336, local_value_1699: local_value_1650.Tensor):
        if local_value_1336.dim == -1:
            B, local_value_0044, H, W = local_value_1699.shape
            return super().forward(local_value_1699.view(B, local_value_0044, -1)).view(B, local_value_0044, H, W)
        elif local_value_1336.dim == 1:
            B, H, W, local_value_0044 = local_value_1699.shape
            return super().forward(local_value_1699.view(B, -1, local_value_0044)).view(B, H, W, local_value_0044)
        else:
            raise NotImplementedError

class ComponentUnit0100(local_value_1094.Module):

    def __init__(local_value_1336, in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=True, norm='local_value_1014'):
        super().__init__()
        local_value_1336.member_slot_0241 = local_value_1094.Conv2d(in_channels=in_channels, out_channels=in_channels, kernel_size=kernel_size, stride=stride, padding=padding, groups=in_channels)
        local_value_1336.member_slot_0389 = local_value_1094.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=1)
        if norm == 'local_value_1014':
            norm = ComponentUnit0169(out_channels)
        else:
            norm = local_value_1094.GroupNorm(out_channels // 8, num_channels=out_channels)
        local_value_1336.norm = norm

    def forward(local_value_1336, local_value_1699):
        local_value_1699 = local_value_1336.member_slot_0241(local_value_1699)
        local_value_1699 = local_value_1336.member_slot_0389(local_value_1699)
        local_value_1699 = local_value_1336.norm(local_value_1699)
        return local_value_1699

class ComponentUnit0012(local_value_1094.Module):

    def __init__(local_value_1336, dim, num_heads=8, local_value_1240=False, local_value_1238=False, local_value_0422=0.0, local_value_1232=0.0, norm_layer=local_value_1094.GroupNorm):
        super().__init__()
        assert dim % num_heads == 0
        local_value_1336.num_heads = num_heads
        local_value_1336.member_slot_0311 = dim // num_heads
        local_value_1336.local_value_1302 = local_value_1336.member_slot_0311 ** (-0.5)
        local_value_1336.member_slot_0287 = True
        local_value_1336.member_slot_0318 = local_value_1094.GroupNorm(dim // 8, dim)
        local_value_1336.local_value_1239 = local_value_1094.Linear(dim, dim * 3, bias=local_value_1240)
        local_value_1336.member_slot_0396 = norm_layer(local_value_1336.member_slot_0311) if local_value_1238 else local_value_1094.Identity()
        local_value_1336.member_slot_0328 = norm_layer(local_value_1336.member_slot_0311) if local_value_1238 else local_value_1094.Identity()
        local_value_1336.local_value_0422 = local_value_1094.Dropout(local_value_0422)
        local_value_1336.member_slot_0394 = local_value_1094.Linear(dim, dim)
        local_value_1336.local_value_1232 = local_value_1094.Dropout(local_value_1232)

    def forward(local_value_1336, local_value_1699):
        B, L, local_value_0044 = local_value_1699.shape
        local_value_1699 = local_value_1336.member_slot_0318(local_value_1699.permute(0, 2, 1)).permute(0, 2, 1)
        local_value_1239 = local_value_1336.local_value_1239(local_value_1699).reshape(B, L, 3, local_value_1336.num_heads, local_value_1336.member_slot_0311).permute(2, 0, 3, 1, 4)
        local_value_1236, k, local_value_1672 = local_value_1239.unbind(0)
        local_value_1236, k = (local_value_1336.member_slot_0396(local_value_1236), local_value_1336.member_slot_0328(k))
        if local_value_1336.member_slot_0287:
            local_value_1699 = local_value_0117.scaled_dot_product_attention(local_value_1236, k, local_value_1672, dropout_p=local_value_1336.local_value_0422.p)
        else:
            local_value_1236 = local_value_1236 * local_value_1336.local_value_1302
            local_value_0421 = local_value_1236 @ k.transpose(-2, -1)
            local_value_0421 = local_value_0421.softmax(dim=-1)
            local_value_0421 = local_value_1336.local_value_0422(local_value_0421)
            local_value_1699 = local_value_0421 @ local_value_1672
        local_value_1699 = local_value_1699.transpose(1, 2).reshape(B, L, local_value_0044)
        local_value_1699 = local_value_1336.member_slot_0394(local_value_1699)
        local_value_1699 = local_value_1336.local_value_1232(local_value_1699)
        return local_value_1699

class ComponentUnit0174(local_value_1094.Module):

    def __init__(local_value_1336, dim):
        super().__init__()
        local_value_1336.dim = dim
        local_value_1336.member_slot_0318 = local_value_1094.GroupNorm(dim // 8, dim)
        local_value_1336.member_slot_0347 = local_value_1094.MaxPool2d(kernel_size=3, stride=1, padding=1)
        local_value_1336.member_slot_0212 = local_value_1094.Conv2d(dim, 1, 1)
        local_value_1336.sigmoid = local_value_1094.Sigmoid()
        local_value_1336.member_slot_0213 = local_value_1094.Conv2d(dim, dim, 1)

    def forward(local_value_1336, local_value_1699, h, local_value_1683):
        b, local_value_0272, c = local_value_1699.shape
        local_value_1699 = local_value_1699.view(b, h, local_value_1683, c).permute(0, 3, 1, 2)
        local_value_1699 = local_value_1336.member_slot_0318(local_value_1699)
        local_value_1701 = local_value_1336.sigmoid(local_value_1336.member_slot_0212(local_value_1336.member_slot_0347(local_value_1699)))
        local_value_1699 = local_value_1701 * local_value_1699
        local_value_1699 = local_value_1336.member_slot_0213(local_value_1699).permute(0, 2, 3, 1).view(b, -1, c)
        return local_value_1699

def execute_step_0885(delta, delta_bias, local_value_1246=0.5):
    if delta_bias is not None:
        delta = delta + delta_bias[..., None]
    delta = local_value_1650.nn.functional.softplus(delta)
    local_value_0272, D, local_value_0272 = delta.shape
    local_value_0892 = int(D * local_value_1246)
    local_value_0272, local_value_1359 = local_value_1650.sort(delta, descending=True, dim=1)
    local_value_0894, local_value_1025 = local_value_1650.split(local_value_1359, [local_value_0892, D - local_value_0892], dim=1)
    local_value_0894 = local_value_0894.permute(0, 2, 1)
    local_value_1025 = local_value_1025.permute(0, 2, 1)
    return (local_value_0894, local_value_1025)

def execute_step_0530(delta, delta_bias, local_value_0000, B, local_value_0044, local_value_1726):
    if delta_bias is not None:
        delta = delta + delta_bias[..., None]
    delta = local_value_1650.nn.functional.softplus(delta)
    local_value_0039, local_value_0156, N, L = B.shape
    local_value_0157 = local_value_1726[1]
    local_value_0063 = int(local_value_0157 / local_value_0156)
    B = B.view(local_value_0039, local_value_0156, 1, N, L).repeat(1, 1, local_value_0063, 1, 1).view(local_value_0039, local_value_0157, N, L)
    local_value_0044 = local_value_0044.view(local_value_0039, local_value_0156, 1, N, L).repeat(1, 1, local_value_0063, 1, 1).view(local_value_0039, local_value_0157, N, L)
    local_value_0564 = local_value_1650.exp(local_value_1650.einsum('bdl,dn->bldn', delta, local_value_0000))
    local_value_0582 = local_value_1650.einsum('bdl,bdnl->bldn', delta, B)
    local_value_0013 = local_value_1650.zeros((local_value_1726[0], local_value_1726[1], local_value_1726[2], local_value_1726[2]), requires_grad=True).to(local_value_0564.device)
    for local_value_1243 in range(L):
        for c in range(local_value_1243 + 1):
            local_value_0556 = local_value_0044[:, :, :, local_value_1243]
            local_value_0554 = local_value_1650.ones((local_value_0564.shape[0], local_value_0564.shape[2], local_value_0564.shape[3]), requires_grad=True, dtype=local_value_1650.float16).to(local_value_0564.device)
            if c < local_value_1243:
                for local_value_0939 in range(local_value_1243 - c):
                    local_value_0554 = local_value_0554 * local_value_0564[:, local_value_1243 - local_value_0939, :, :]
            local_value_0555 = local_value_0582[:, c, :, :]
            local_value_0013[:, :, local_value_1243, c] = local_value_1650.sum(local_value_0556 * local_value_0554 * local_value_0555, axis=-1)
    return local_value_0013
