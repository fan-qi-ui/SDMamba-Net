import math as local_value_1039
from functools import partial as local_value_1197
import torch as local_value_1650
import torch.nn.functional as local_value_0117
import pytest as local_value_1235
from einops import rearrange as local_value_1249, repeat
local_value_0179 = 'v0'

def execute_step_1323(us, dts, local_value_0009, Bs, Cs, Ds, delta_bias=None, local_value_0696=False, return_last_state=False, local_value_0519=64):

    def execute_step_1317(us, dts, local_value_0009, Bs, Cs, local_value_0933):
        """
        us, dts: (L, B, G, D) # L is chunk_size
        As: (G, D, N)
        Bs, Cs: (L, B, G, N)
        Ds: (G, D)
        hprefix: (B, G, D, N)
        """
        local_value_1659 = dts.cumsum(dim=0)
        local_value_0011 = local_value_1650.einsum('gdn,lbgd->lbgdn', local_value_0009, local_value_1659).exp()
        local_value_1302 = 1
        local_value_1244 = local_value_0011 / local_value_1302
        local_value_0802 = dts * us
        local_value_0765 = local_value_1650.einsum('lbgd,lbgn->lbgdn', local_value_0802, Bs)
        local_value_0936 = local_value_1244 * (local_value_0765 / local_value_1244).cumsum(dim=0)
        local_value_0934 = local_value_0936 + local_value_0011 * local_value_0933.unsqueeze(0)
        ys = local_value_1650.einsum('lbgn,lbgdn->lbgd', Cs, local_value_0934)
        return (ys, local_value_0934)
    dtype = local_value_1650.float32
    local_value_0976 = us.dtype
    local_value_0914 = Ds is not None
    if local_value_0519 < 1:
        local_value_0519 = Bs.shape[-1]
    dts = dts.to(dtype)
    if delta_bias is not None:
        dts = dts + delta_bias.view(1, -1, 1).to(dtype)
    if local_value_0696:
        dts = local_value_1650.nn.functional.softplus(dts)
    if len(Bs.shape) == 3:
        Bs = Bs.unsqueeze(1)
    if len(Cs.shape) == 3:
        Cs = Cs.unsqueeze(1)
    B, local_value_0122, N, L = Bs.shape
    us = us.view(B, local_value_0122, -1, L).permute(3, 0, 1, 2).to(dtype)
    dts = dts.view(B, local_value_0122, -1, L).permute(3, 0, 1, 2).to(dtype)
    local_value_0009 = local_value_0009.view(local_value_0122, -1, N).to(dtype)
    Bs = Bs.permute(3, 0, 1, 2).to(dtype)
    Cs = Cs.permute(3, 0, 1, 2).to(dtype)
    Ds = Ds.view(local_value_0122, -1).to(dtype) if local_value_0914 else None
    D = local_value_0009.shape[1]
    local_value_1181 = []
    local_value_0933 = us.new_zeros((B, local_value_0122, D, N), dtype=dtype)
    for local_value_0939 in range(0, L, local_value_0519):
        ys, local_value_0934 = execute_step_1317(us[local_value_0939:local_value_0939 + local_value_0519], dts[local_value_0939:local_value_0939 + local_value_0519], local_value_0009, Bs[local_value_0939:local_value_0939 + local_value_0519], Cs[local_value_0939:local_value_0939 + local_value_0519], local_value_0933)
        local_value_1181.append(ys)
        local_value_0933 = local_value_0934[-1]
    local_value_1181 = local_value_1650.cat(local_value_1181, dim=0)
    if local_value_0914:
        local_value_1181 = local_value_1181 + Ds * us
    local_value_1181 = local_value_1181.permute(1, 2, 3, 0).view(B, -1, L)
    return local_value_1181.to(local_value_0976) if not return_last_state else (local_value_1181.to(local_value_0976), local_value_0933.view(B, local_value_0122 * D, N).float())

class ComponentUnit0231(local_value_1650.autograd.Function):
    local_value_0088 = local_value_0179 == 'fnDEBUG'
    if local_value_0088:
        print('DEBUG here...', flush=True)
        saved_tensors = []

        @classmethod
        def save_for_backward(local_value_0551, *local_value_0416):
            local_value_0551.saved_tensors = local_value_0416

    @staticmethod
    @local_value_1650.cuda.amp.custom_fwd(cast_inputs=local_value_1650.float32)
    def forward(local_value_0551, us, dts, local_value_0009, Bs, Cs, Ds, delta_bias=None, local_value_0696=False, return_last_state=False, local_value_0519=64):
        local_value_0914 = Ds is not None
        dtype = local_value_1650.float32
        dts = dts.to(dtype)
        if delta_bias is not None:
            dts = dts + delta_bias.view(1, -1, 1).to(dtype)
        if local_value_0696:
            dts = local_value_1650.nn.functional.softplus(dts)
        local_value_0037 = len(Bs.shape) == 3
        local_value_0060 = len(Cs.shape) == 3
        if local_value_0037:
            Bs = Bs.unsqueeze(1)
        if local_value_0060:
            Cs = Cs.unsqueeze(1)
        B, local_value_0122, N, L = Bs.shape
        us = us.view(B, local_value_0122, -1, L).permute(3, 0, 1, 2).to(dtype)
        dts = dts.view(B, local_value_0122, -1, L).permute(3, 0, 1, 2).to(dtype)
        local_value_0009 = local_value_0009.view(local_value_0122, -1, N).to(dtype)
        Bs = Bs.permute(3, 0, 1, 2).to(dtype)
        Cs = Cs.permute(3, 0, 1, 2).to(dtype)
        Ds = Ds.view(local_value_0122, -1).to(dtype) if local_value_0914 else None
        D = local_value_0009.shape[1]
        local_value_0551.shape = (B, local_value_0122, D, N, L)
        local_value_0551.local_value_0696 = local_value_0696
        local_value_0551.return_last_state = return_last_state
        local_value_0551.local_value_0519 = local_value_0519
        local_value_0551.member_slot_0004 = (local_value_0037, local_value_0060)
        save_for_backward = [us, dts, local_value_0009, Bs, Cs, Ds, delta_bias]
        local_value_0518 = list(range(0, L, local_value_0519))
        local_value_1181 = []
        local_value_1128 = []
        local_value_0933 = us.new_zeros((B, local_value_0122, D, N), dtype=local_value_1650.float)
        for local_value_0939 in local_value_0518:
            local_value_1659 = dts[local_value_0939:local_value_0939 + local_value_0519].cumsum(dim=0)
            local_value_0011 = local_value_1650.einsum('gdn,lbgd->lbgdn', local_value_0009, local_value_1659).exp()
            local_value_1302 = 1
            local_value_1244 = local_value_0011 / local_value_1302
            local_value_0802 = dts[local_value_0939:local_value_0939 + local_value_0519] * us[local_value_0939:local_value_0939 + local_value_0519]
            local_value_0765 = local_value_1650.einsum('lbgd,lbgn->lbgdn', local_value_0802, Bs[local_value_0939:local_value_0939 + local_value_0519])
            local_value_1636 = local_value_0765 / local_value_1244
            local_value_1637 = local_value_1636.cumsum(dim=0)
            local_value_0934 = local_value_1244 * local_value_1637 + local_value_0011 * local_value_0933.unsqueeze(0)
            ys = local_value_1650.einsum('lbgn,lbgdn->lbgd', Cs[local_value_0939:local_value_0939 + local_value_0519], local_value_0934)
            local_value_1181.append(ys)
            local_value_1128.append(local_value_0934)
            local_value_0933 = local_value_0934[-1]
        local_value_1181 = local_value_1650.cat(local_value_1181, dim=0)
        local_value_1128 = local_value_1650.cat(local_value_1128, dim=0)
        if local_value_0914:
            local_value_1181 = local_value_1181 + Ds * us
        save_for_backward.extend([local_value_1128])
        local_value_0551.save_for_backward(*save_for_backward)
        local_value_1181 = local_value_1181.permute(1, 2, 3, 0).view(B, -1, L)
        if getattr(local_value_0551, 'local_value_0088', False):
            print('DEBUG here ..............', flush=True)
            local_value_1181.backward = local_value_1197(local_value_0551.backward, local_value_0551)
        return (local_value_1181, local_value_0933.view(B, local_value_0122 * D, N))

    @staticmethod
    @local_value_1650.cuda.amp.custom_bwd
    def backward(local_value_0551, local_value_0737: local_value_1650.Tensor, *local_value_0416):
        local_value_0088 = getattr(local_value_0551, 'local_value_0088', False)
        us, dts, local_value_0009, Bs, Cs, Ds, delta_bias, local_value_1128 = local_value_0551.saved_tensors
        B, local_value_0122, D, N, L = local_value_0551.shape
        local_value_0519 = local_value_0551.local_value_0519
        local_value_0696 = local_value_0551.local_value_0696
        local_value_0737 = local_value_0737.view(B, local_value_0122, D, L).permute(3, 0, 1, 2)

        def execute_step_1279(local_value_1699):
            local_value_0553 = local_value_1650.cumsum(local_value_1699, dim=0)
            return local_value_1699 - local_value_0553 + local_value_0553[-1:None]
        if local_value_0088:
            dtype = local_value_1650.float32
            us = us.requires_grad_()
            dts = dts.requires_grad_()
            local_value_0009 = local_value_0009.requires_grad_()
            Bs = Bs.requires_grad_()
            Cs = Cs.requires_grad_()
            Ds = Ds.requires_grad_() if Ds is not None else None
            delta_bias = delta_bias.requires_grad_() if delta_bias is not None else None
            local_value_1128 = local_value_1128.requires_grad_()
        if local_value_0088:
            local_value_0914 = Ds is not None
            local_value_1640 = []
            local_value_1643 = []
            local_value_1639 = []
            local_value_1642 = []
            local_value_1641 = []
            local_value_0518 = list(range(0, L, local_value_0519))
            local_value_1181 = []
            local_value_1128 = []
            local_value_0933 = us.new_zeros((B, local_value_0122, D, N), dtype=local_value_1650.float)
            for local_value_0939 in local_value_0518:
                local_value_1659 = dts[local_value_0939:local_value_0939 + local_value_0519].cumsum(dim=0)
                local_value_0011 = local_value_1650.einsum('gdn,lbgd->lbgdn', local_value_0009, local_value_1659).exp()
                local_value_1302 = 1
                local_value_1244 = local_value_0011 / local_value_1302
                local_value_0802 = dts[local_value_0939:local_value_0939 + local_value_0519] * us[local_value_0939:local_value_0939 + local_value_0519]
                local_value_0765 = local_value_1650.einsum('lbgd,lbgn->lbgdn', local_value_0802, Bs[local_value_0939:local_value_0939 + local_value_0519])
                local_value_1636 = local_value_0765 / local_value_1244
                local_value_1637 = local_value_1636.cumsum(dim=0)
                local_value_0934 = local_value_1244 * local_value_1637 + local_value_0011 * local_value_0933.unsqueeze(0)
                ys = local_value_1650.einsum('lbgn,lbgdn->lbgd', Cs[local_value_0939:local_value_0939 + local_value_0519], local_value_0934)
                local_value_1181.append(ys)
                local_value_1128.append(local_value_0934)
                local_value_0933 = local_value_0934[-1]
                local_value_1642.append(local_value_1637)
                local_value_1641.append(local_value_1636)
                local_value_1640.append(local_value_0765)
                local_value_1643.append(local_value_1244)
                local_value_1639.append(local_value_0011)
            local_value_1181 = local_value_1650.cat(local_value_1181, dim=0)
            local_value_1128 = local_value_1650.cat(local_value_1128, dim=0)
            if local_value_0914:
                local_value_1181 = local_value_1181 + Ds * us
        if local_value_0088:
            local_value_0375 = local_value_1181.requires_grad_()
        local_value_0801 = None
        local_value_0594 = None
        if Ds is not None:
            local_value_0594 = local_value_1650.einsum('lbgd,lbgd->gd', local_value_0737, us).view(-1)
            local_value_0801 = local_value_1650.einsum('lbgd,gd->lbgd', local_value_0737, Ds)
        local_value_0518 = list(range(0, L, local_value_0519))
        local_value_0577 = us.new_zeros((local_value_0122, D, N), dtype=local_value_1650.float)
        local_value_0801 = us.new_zeros((L, B, local_value_0122, D), dtype=local_value_1650.float) if local_value_0801 is None else local_value_0801
        local_value_0682 = us.new_zeros((L, B, local_value_0122, D), dtype=local_value_1650.float)
        local_value_0584 = us.new_zeros((L, B, local_value_0122, N), dtype=local_value_1650.float)
        local_value_0588 = us.new_zeros((L, B, local_value_0122, N), dtype=local_value_1650.float)
        local_value_0703 = us.new_zeros((B, local_value_0122, D, N), dtype=local_value_1650.float)
        for local_value_0939 in local_value_0518[::-1]:
            local_value_1638 = dts[local_value_0939:local_value_0939 + local_value_0519]
            local_value_1659 = local_value_1638.cumsum(dim=0)
            local_value_0011 = local_value_1650.einsum('gdn,lbgd->lbgdn', local_value_0009, local_value_1659).exp()
            local_value_1302 = local_value_0011[-1].detach()
            local_value_1302 = 1
            local_value_1244 = local_value_0011 / local_value_1302
            local_value_0802 = dts[local_value_0939:local_value_0939 + local_value_0519] * us[local_value_0939:local_value_0939 + local_value_0519]
            local_value_0765 = local_value_1650.einsum('lbgd,lbgn->lbgdn', local_value_0802, Bs[local_value_0939:local_value_0939 + local_value_0519])
            local_value_0766 = local_value_0765 / local_value_1244
            local_value_0935 = local_value_0766.cumsum(dim=0)
            if False:
                local_value_0933 = (hsuffix - hs_minus_prefix[-1]) / local_value_1302
                local_value_0934 = hs_minus_prefix + local_value_0011 * local_value_0933.unsqueeze(0)
            local_value_0350 = local_value_1128[local_value_0939:local_value_0939 + local_value_0519]
            local_value_0349 = local_value_1128[local_value_0939 - 1] if local_value_0939 > 0 else None
            local_value_0588[local_value_0939:local_value_0939 + local_value_0519] = local_value_1650.einsum('lbgd,lbgdn->lbgn', local_value_0737[local_value_0939:local_value_0939 + local_value_0519], local_value_0350)
            local_value_0704 = local_value_0737[local_value_0939:local_value_0939 + local_value_0519].unsqueeze(4) * Cs[local_value_0939:local_value_0939 + local_value_0519].unsqueeze(3)
            local_value_0704[-1] = local_value_0704[-1] + local_value_0703
            local_value_0703 = local_value_1650.einsum('lbgdn,lbgdn -> bgdn', local_value_0704, local_value_0011)
            local_value_0579 = local_value_0704 * local_value_0349.unsqueeze_(0) if local_value_0939 > 0 else None
            local_value_0745 = local_value_0704 * local_value_0935
            local_value_0705 = local_value_0704 * local_value_1244
            if local_value_0088:
                print('1', (local_value_1650.autograd.grad(local_value_0375, local_value_1642[local_value_0518.index(local_value_0939)], local_value_0737, create_graph=True, allow_unused=True)[0] - local_value_0705).abs().sum())
            local_value_0603 = execute_step_1279(local_value_0705)
            if local_value_0088:
                local_value_0604 = local_value_1650.autograd.grad(local_value_0935, local_value_0766, local_value_0705, create_graph=True, allow_unused=True)[0]
                print('2.0', (local_value_1650.autograd.grad(local_value_0375, local_value_1641[local_value_0518.index(local_value_0939)], local_value_0737, create_graph=True, allow_unused=True)[0] - local_value_0603).abs().sum())
                print('2.1', (local_value_0603 - local_value_0604).abs().sum())
                local_value_0603 = local_value_0604
            local_value_0673 = local_value_0603 / local_value_1244
            local_value_0584[local_value_0939:local_value_0939 + local_value_0519] = local_value_1650.einsum('lbgdn,lbgd->lbgn', local_value_0673, local_value_0802)
            local_value_0683 = local_value_1650.einsum('lbgdn,lbgn->lbgd', local_value_0673, Bs[local_value_0939:local_value_0939 + local_value_0519])
            local_value_0801[local_value_0939:local_value_0939 + local_value_0519] = local_value_0801[local_value_0939:local_value_0939 + local_value_0519] + local_value_0683 * dts[local_value_0939:local_value_0939 + local_value_0519]
            if local_value_0088:
                print('3', (local_value_1650.autograd.grad(local_value_0375, local_value_1640[local_value_0518.index(local_value_0939)], local_value_0737, create_graph=True, allow_unused=True)[0] - local_value_0673).abs().sum())
            if local_value_0088:
                local_value_1633 = local_value_1650.randn((L, B, local_value_0122, D, N)).to(dtype).cuda().requires_grad_()
                local_value_1634 = local_value_1650.cumsum(local_value_1633, dim=0)
                local_value_1635 = local_value_1650.randn((L, B, local_value_0122, D, N)).to(dtype).cuda()
                print('ex.0', (local_value_1650.autograd.grad(local_value_1634, local_value_1633, local_value_1635, create_graph=True, allow_unused=True)[0] - execute_step_1279(local_value_1635)).abs().sum())
            local_value_0742 = local_value_0603 * (-local_value_0766 / local_value_1244)
            if local_value_0088:
                local_value_0744 = local_value_0603 * (local_value_0765 / -(local_value_1244 * local_value_1244))
                local_value_0743 = local_value_1650.autograd.grad(local_value_0766, local_value_1244, local_value_0603, create_graph=True, allow_unused=True)[0]
                print('4.0', (local_value_0742 - local_value_0743).abs().sum())
                print('4.0_v1', (local_value_0742 - local_value_0744).abs().sum())
            local_value_0682[local_value_0939:local_value_0939 + local_value_0519] = local_value_0683 * us[local_value_0939:local_value_0939 + local_value_0519]
            local_value_0578 = local_value_0742 / local_value_1302 + local_value_0745 / local_value_1302 + (local_value_0579 if local_value_0939 > 0 else 0)
            if local_value_0088:
                local_value_0746 = local_value_1650.autograd.grad(local_value_0375, local_value_1643[local_value_0518.index(local_value_0939)], local_value_0737, create_graph=True, allow_unused=True)[0]
                local_value_0581 = local_value_1650.autograd.grad(local_value_0375, local_value_1639[local_value_0518.index(local_value_0939)], local_value_0737, create_graph=True, allow_unused=True)[0]
                print('4.1', (local_value_0746 - (local_value_0742 + local_value_0745)).abs().sum())
                print('4.2', ((local_value_0746 - (local_value_0742 + local_value_0745)) / local_value_1302).abs().sum())
                print('4.3', (local_value_0581 - local_value_0578).abs().sum())
            local_value_0580 = local_value_0578 * local_value_0011
            local_value_0577 = local_value_0577 + local_value_1650.einsum('lbgdn,lbgd->gdn', local_value_0580, local_value_1659)
            local_value_0624 = local_value_1650.einsum('lbgdn,gdn->lbgd', local_value_0580, local_value_0009)
            local_value_0377 = execute_step_1279(local_value_0624)
            if local_value_0088:
                local_value_0378 = local_value_1650.autograd.grad(local_value_1659, local_value_1638, local_value_0624, create_graph=True, allow_unused=True)[0]
                print('5.0', (local_value_0377 - local_value_0378).abs().sum())
            local_value_0682[local_value_0939:local_value_0939 + local_value_0519] = local_value_0682[local_value_0939:local_value_0939 + local_value_0519] + local_value_0377
        if local_value_0088:
            print('local_value_0834', (local_value_1650.autograd.grad(local_value_0375, dts, local_value_0737, create_graph=True, allow_unused=True)[0] - local_value_0682).abs().sum(), flush=True)
        if local_value_0696:
            local_value_0682 = local_value_0682 - local_value_0682 * (-dts).exp()
        local_value_0671 = None
        if delta_bias is not None:
            local_value_0671 = local_value_0682.sum([0, 1]).view(-1)
        if local_value_0088:
            print('local_value_0834', (local_value_1650.autograd.grad(local_value_0375, us, local_value_0737, create_graph=True, allow_unused=True)[0] - local_value_0801).abs().sum(), flush=True)
            print('local_value_0834', (local_value_1650.autograd.grad(local_value_0375, Bs, local_value_0737, create_graph=True, allow_unused=True)[0] - local_value_0584).abs().sum(), flush=True)
            print('local_value_0834', (local_value_1650.autograd.grad(local_value_0375, Cs, local_value_0737, create_graph=True, allow_unused=True)[0] - local_value_0588).abs().sum(), flush=True)
            print('local_value_0834', (local_value_1650.autograd.grad(local_value_0375, Ds, local_value_0737, create_graph=True, allow_unused=True)[0].view(-1) - local_value_0594).abs().sum(), flush=True)
            print('local_value_0834', (local_value_1650.autograd.grad(local_value_0375, local_value_0009, local_value_0737, create_graph=True, allow_unused=True)[0] - local_value_0577).abs().sum(), flush=True)
        local_value_0801 = local_value_0801.permute(1, 2, 3, 0).view(B, -1, L)
        local_value_0682 = local_value_0682.permute(1, 2, 3, 0).view(B, -1, L)
        local_value_0577 = local_value_0577.view(-1, N)
        local_value_0584 = local_value_0584.permute(1, 2, 3, 0)
        local_value_0588 = local_value_0588.permute(1, 2, 3, 0)
        if local_value_0551.member_slot_0004[0]:
            local_value_0584 = local_value_0584.flatten(1, 2)
        if local_value_0551.member_slot_0004[1]:
            local_value_0588 = local_value_0588.flatten(1, 2)
        return (local_value_0801, local_value_0682, local_value_0577, local_value_0584, local_value_0588, local_value_0594, local_value_0671, None, None, None)

def execute_step_1324(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias=None, local_value_0696=None, return_last_state=False, local_value_0519=64):
    mode = local_value_0179
    if mode in ['fnDEBUG']:
        local_value_1177 = ComponentUnit0231.forward(ComponentUnit0231, local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, return_last_state, local_value_0519)
        return (local_value_1177[0].to(local_value_1660.dtype), *local_value_1177[1:]) if return_last_state else local_value_1177[0].to(local_value_1660.dtype)
    else:
        local_value_1177 = ComponentUnit0231.apply(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, return_last_state, local_value_0519)
        return (local_value_1177[0].to(local_value_1660.dtype), *local_value_1177[1:]) if return_last_state else local_value_1177[0].to(local_value_1660.dtype)

def execute_step_1326(us, dts, local_value_0009, Bs, Cs, Ds, delta_bias=None, local_value_0696=False, return_last_state=False, local_value_0519=64):
    if local_value_0519 < 1:
        local_value_0519 = Bs.shape[-1]
    mask = local_value_1650.tril(local_value_1650.ones((local_value_0519, local_value_0519), device=us.device), diagonal=0)

    def execute_step_1368(us, dts, local_value_0009, Bs, Cs, local_value_0913, mask):
        local_value_0466 = us.shape[2]
        local_value_0369 = (mask[:local_value_0466, :local_value_0466].contiguous() if local_value_0466 < local_value_0519 else mask).view(1, 1, local_value_0466, local_value_0466, 1)
        local_value_1685 = local_value_0009[None, :, None, :, :] * local_value_1650.cumsum(dts, dim=2)[..., None, :]
        local_value_1672 = us * dts
        k = Bs
        local_value_1236 = Cs
        local_value_1683 = local_value_1685.exp()
        local_value_0999 = k[..., None] / local_value_1683
        local_value_1237 = local_value_1236[..., None] * local_value_1683
        local_value_1087 = local_value_1683[:, :, -1] * local_value_1650.einsum('bhlkv,bhlv->bhkv', local_value_0999, local_value_1672)
        local_value_1741 = local_value_1650.einsum('bhlrv,bhrv->bhlv', local_value_1650.einsum('bhlkv,bhrkv->bhlrv', local_value_1237, local_value_0999) * local_value_0369, local_value_1672)
        local_value_1740 = local_value_1650.einsum('bhlkv,bhkv->bhlv', local_value_1237, local_value_0913)
        local_value_1086 = local_value_1683[:, :, -1] * local_value_0913
        local_value_1085 = local_value_1086 + local_value_1087
        y = local_value_1740 + local_value_1741
        return (y, local_value_1085)
    dtype = local_value_1650.float32
    local_value_0976 = us.dtype
    local_value_0914 = Ds is not None
    dts = dts.to(dtype)
    if delta_bias is not None:
        dts = dts + delta_bias.view(1, -1, 1).to(dtype)
    if local_value_0696:
        dts = local_value_1650.nn.functional.softplus(dts)
    if len(Bs.shape) == 3:
        Bs = Bs.unsqueeze(1)
    if len(Cs.shape) == 3:
        Cs = Cs.unsqueeze(1)
    B, local_value_0123, L = us.shape
    B, local_value_0122, N, L = Bs.shape
    D = local_value_0123 // local_value_0122
    us = us.view(B, local_value_0122, -1, L).permute(0, 1, 3, 2).to(dtype)
    dts = dts.view(B, local_value_0122, -1, L).permute(0, 1, 3, 2).to(dtype)
    local_value_0009 = local_value_0009.view(local_value_0122, D, N).permute(0, 2, 1).to(dtype)
    Bs = Bs.permute(0, 1, 3, 2).to(dtype)
    Cs = Cs.permute(0, 1, 3, 2).to(dtype)
    Ds = Ds.view(local_value_0122, -1).to(dtype) if local_value_0914 else None
    local_value_1181 = []
    local_value_0933 = us.new_zeros((B, local_value_0122, N, D), dtype=dtype)
    for local_value_0939 in range(0, L, local_value_0519):
        ys, local_value_0933 = execute_step_1368(us[:, :, local_value_0939:local_value_0939 + local_value_0519], dts[:, :, local_value_0939:local_value_0939 + local_value_0519], local_value_0009, Bs[:, :, local_value_0939:local_value_0939 + local_value_0519], Cs[:, :, local_value_0939:local_value_0939 + local_value_0519], local_value_0933, mask)
        local_value_1181.append(ys)
    local_value_1181 = local_value_1650.cat(local_value_1181, dim=2)
    if local_value_0914:
        local_value_1181 = local_value_1181 + Ds.view(1, local_value_0122, 1, D) * us
    local_value_1181 = local_value_1181.permute(0, 1, 3, 2).contiguous().view(B, -1, L)
    local_value_0933 = local_value_0933.permute(0, 1, 3, 2).contiguous().view(B, local_value_0123, N).float()
    return local_value_1181.to(local_value_0976) if not return_last_state else (local_value_1181.to(local_value_0976), local_value_0933)

def execute_step_1328(us, dts, local_value_0009, Bs, Cs, Ds, delta_bias=None, local_value_0696=False, return_last_state=False, local_value_0519=64):
    local_value_0986 = 1.44269504
    if local_value_0519 < 0:
        local_value_0519 = 64
    local_value_0519 = min(local_value_0519, Bs.shape[-1])
    if len(Bs.shape) == 3:
        Bs = Bs.unsqueeze(1)
    if len(Cs.shape) == 3:
        Cs = Cs.unsqueeze(1)
    B, local_value_0123, L = us.shape
    B, local_value_0122, N, L = Bs.shape
    D = local_value_0123 // local_value_0122
    local_value_0289 = local_value_1650.arange(0, local_value_0519, dtype=local_value_1650.int8, device=Bs.device)
    local_value_0382 = local_value_0289[None, :]
    local_value_0331 = local_value_0289[:, None]
    local_value_0372 = (local_value_0331 >= local_value_0382).float()

    def execute_step_0560(us, dts, Bs, Cs, local_value_0519=local_value_0519):
        B, H, L, D = us.shape
        B, H, L, N = Bs.shape
        local_value_0193 = -(L // -local_value_0519)
        local_value_1646 = local_value_0193 * local_value_0519 - L
        local_value_0376 = lambda local_value_1699: local_value_1650.nn.functional.pad(local_value_1699.view(B * H, L, -1), (0, 0, 0, local_value_1646, 0, 0)).view(B * H, local_value_0193, local_value_0519, local_value_1699.shape[-1])
        us, dts, Bs, Cs = (local_value_0376(us), local_value_0376(dts), local_value_0376(Bs), local_value_0376(Cs))
        return (us, dts, Bs, Cs)

    def execute_step_1370(local_value_1241, local_value_1006, local_value_1681, local_value_1697=None, local_value_0009=None, local_value_1659=None, dts=None, mask=None, local_value_1302=1):
        if local_value_1697 is None:
            if local_value_1659 is None:
                local_value_1659 = local_value_1650.cumsum(dts * local_value_0986, dim=2)
            local_value_0394 = local_value_1659.view(-1, local_value_0009.shape[0], *local_value_1659.shape[1:])[:, :, :, :, None, :]
            local_value_1697 = local_value_1650.exp2(local_value_0009[None, :, None, None, :, :] * local_value_0394).flatten(0, 1)
        local_value_1237 = local_value_1241[..., None] * local_value_1697 * local_value_1302
        local_value_0999 = local_value_1006[..., None] / local_value_1697
        local_value_1242 = local_value_1650.einsum('mctnd,mcrnd->mctrd', local_value_1237, local_value_0999)
        local_value_1242 = local_value_1242 * mask[None, None, :, :, None]
        local_value_1737 = local_value_1650.einsum('mctrd,mcrd->mctd', local_value_1242, local_value_1681)
        local_value_0937 = local_value_1697[:, :, -1, :, :] * (local_value_0999 * local_value_1681[..., None, :]).sum(dim=-3)
        local_value_0562 = local_value_1697[:, :, -1, :, :]
        return (local_value_0937, local_value_1737, local_value_1697, local_value_0562, local_value_1237)

    def execute_step_1369(local_value_0562, local_value_0937):
        device, dtype = (local_value_0937.device, local_value_0937.dtype)
        local_value_0175, local_value_0044, N, D = local_value_0937.shape
        local_value_0938 = [local_value_1650.zeros((local_value_0175, N, D), device=device, dtype=dtype)]
        local_value_0967 = local_value_0938[0]
        for c in range(local_value_0044):
            local_value_0967 = local_value_0562[:, c] * local_value_0967 + local_value_0937[:, c]
            local_value_0938.append(local_value_0967)
        return local_value_1650.stack(local_value_0938, dim=1)

    def execute_step_1372(local_value_1737, local_value_0934, local_value_1237):
        local_value_0968 = local_value_0934[:, :-1, :, :].contiguous()
        local_value_1736 = local_value_1650.einsum('mctnd,mcnd->mctd', local_value_1237, local_value_0968)
        y = local_value_1736 + local_value_1737
        return y

    def execute_step_1371(local_value_1241, local_value_1006, local_value_1681, local_value_1697=None, local_value_0009=None, local_value_1659=None, dts=None, mask=None, local_value_1302=1):
        local_value_0175, local_value_0044, local_value_0238, N = local_value_1241.shape
        assert N == 1
        if local_value_1697 is None:
            if local_value_1659 is None:
                local_value_1659 = local_value_1650.cumsum(dts, dim=2)
            local_value_0394 = local_value_1659.view(-1, local_value_0009.shape[0], *local_value_1659.shape[1:])[:, :, :, :, None, :]
            local_value_1697 = (local_value_0009[None, :, None, None, :, :] * local_value_0394).exp().flatten(0, 1)
        local_value_1237 = local_value_1241[..., None] * local_value_1697 * local_value_1302
        local_value_1673 = local_value_1681 / local_value_1697[:, :, :, 0, :]
        local_value_1737 = local_value_1697[:, :, :, 0, :] * local_value_1650.einsum('mctr,mcrd->mctd', local_value_1241[:, :, :, None, 0] * local_value_1006[:, :, None, :, 0] * mask[None, None, :, :], local_value_1673)
        local_value_0937 = (local_value_1697[:, :, -1, 0, :] * (local_value_1006 * local_value_1673).sum(dim=-2))[:, :, None, :]
        local_value_0562 = local_value_1697[:, :, -1, :, :]
        return (local_value_0937, local_value_1737, local_value_1697, local_value_0562, local_value_1237)

    def execute_step_1373(local_value_1737, local_value_0934, local_value_1237):
        local_value_0968 = local_value_0934[:, :-1, :, :].contiguous()
        local_value_1736 = local_value_1237[:, :, :, 0, :] * local_value_0968
        y = local_value_1736 + local_value_1737
        return y
    if N == 1:
        execute_step_1370 = execute_step_1371
        execute_step_1372 = execute_step_1373
    dtype = local_value_1650.float32
    local_value_0976 = us.dtype
    local_value_0914 = Ds is not None
    dts = dts.to(dtype)
    if delta_bias is not None:
        dts = dts + delta_bias.view(1, -1, 1).to(dtype)
    if local_value_0696:
        dts = local_value_1650.nn.functional.softplus(dts)
    us = us.view(B, local_value_0122, -1, L).permute(0, 1, 3, 2).to(dtype)
    dts = dts.view(B, local_value_0122, -1, L).permute(0, 1, 3, 2).to(dtype)
    local_value_0009 = local_value_0009.view(local_value_0122, D, N).permute(0, 2, 1).to(dtype)
    Bs = Bs.permute(0, 1, 3, 2).to(dtype)
    Cs = Cs.permute(0, 1, 3, 2).to(dtype)
    Ds = Ds.view(local_value_0122, -1).to(dtype) if local_value_0914 else None
    local_value_0395, dts, Bs, Cs = execute_step_0560(us, dts, Bs, Cs, local_value_0519=local_value_0519)
    local_value_0937, local_value_1737, local_value_1697, local_value_0562, local_value_1237 = execute_step_1370(Cs, Bs, local_value_0395 * dts, None, local_value_0009, None, dts, mask=local_value_0372)
    local_value_0938 = execute_step_1369(local_value_0562, local_value_0937)
    local_value_1181 = execute_step_1372(local_value_1737, local_value_0938, local_value_1237)
    local_value_1181 = local_value_1181.contiguous().view(B, local_value_0122, -1, D)[:, :, :L, :].contiguous()
    local_value_0933 = local_value_0938[:, -1, :, :].contiguous()
    if local_value_0914:
        local_value_1181 = local_value_1181 + Ds.view(1, local_value_0122, 1, D) * us
    local_value_1181 = local_value_1181.permute(0, 1, 3, 2).contiguous().view(B, -1, L)
    local_value_0933 = local_value_0933.permute(0, 2, 1).contiguous().view(B, local_value_0123, N).float()
    return local_value_1181.to(local_value_0976) if not return_last_state else (local_value_1181.to(local_value_0976), local_value_0933)

class ComponentUnit0233(local_value_1650.autograd.Function):

    @staticmethod
    @local_value_1650.cuda.amp.custom_fwd(cast_inputs=local_value_1650.float32)
    def forward(local_value_0551, us, dts, local_value_0009, Bs, Cs, Ds, delta_bias=None, local_value_0696=False, return_last_state=False, local_value_0519=64):
        save_for_backward = []
        if local_value_0519 < 1:
            local_value_0519 = Bs.shape[-1]
        mask = local_value_1650.tril(local_value_1650.ones((local_value_0519, local_value_0519), device=us.device), diagonal=0)

        def execute_step_1368(us, dts, local_value_0009, Bs, Cs, local_value_0913, mask):
            local_value_0466 = us.shape[2]
            local_value_0369 = (mask[:local_value_0466, :local_value_0466].contiguous() if local_value_0466 < mask.shape[0] else mask).view(1, 1, local_value_0466, local_value_0466, 1)
            local_value_1685 = local_value_0009[None, :, None, :, :] * local_value_1650.cumsum(dts, dim=2)[..., None, :]
            local_value_1672 = us * dts
            k = Bs
            local_value_1236 = Cs
            local_value_1683 = local_value_1685.exp()
            local_value_0999 = k[..., None] / local_value_1683
            local_value_1237 = local_value_1236[..., None] * local_value_1683
            local_value_1087 = local_value_1683[:, :, -1] * local_value_1650.einsum('bhlkv,bhlv->bhkv', local_value_0999, local_value_1672)
            local_value_1741 = local_value_1650.einsum('bhlrv,bhrv->bhlv', local_value_1650.einsum('bhlkv,bhrkv->bhlrv', local_value_1237, local_value_0999) * local_value_0369, local_value_1672)
            local_value_1740 = local_value_1650.einsum('bhlkv,bhkv->bhlv', local_value_1237, local_value_0913)
            local_value_1086 = local_value_1683[:, :, -1] * local_value_0913
            local_value_1085 = local_value_1086 + local_value_1087
            y = local_value_1740 + local_value_1741
            return (y, local_value_1085)
        dtype = local_value_1650.float32
        local_value_0976 = us.dtype
        local_value_0914 = Ds is not None
        dts = dts.to(dtype)
        if delta_bias is not None:
            dts = dts + delta_bias.view(1, -1, 1).to(dtype)
        if local_value_0696:
            dts = local_value_1650.nn.functional.softplus(dts)
        if len(Bs.shape) == 3:
            Bs = Bs.unsqueeze(1)
        if len(Cs.shape) == 3:
            Cs = Cs.unsqueeze(1)
        B, local_value_0123, L = us.shape
        B, local_value_0122, N, L = Bs.shape
        D = local_value_0123 // local_value_0122
        us = us.view(B, local_value_0122, -1, L).permute(0, 1, 3, 2).to(dtype)
        dts = dts.view(B, local_value_0122, -1, L).permute(0, 1, 3, 2).to(dtype)
        local_value_0009 = local_value_0009.view(local_value_0122, D, N).permute(0, 2, 1).to(dtype)
        Bs = Bs.permute(0, 1, 3, 2).to(dtype)
        Cs = Cs.permute(0, 1, 3, 2).to(dtype)
        Ds = Ds.view(local_value_0122, -1).to(dtype) if local_value_0914 else None
        local_value_0551.shape = (B, local_value_0122, L, N, D)
        local_value_0933 = us.new_zeros((B, local_value_0122, N, D), dtype=dtype)
        local_value_1181 = []
        local_value_1128 = [local_value_0933]
        for local_value_0939 in range(0, L, local_value_0519):
            ys, local_value_0933 = execute_step_1368(us[:, :, local_value_0939:local_value_0939 + local_value_0519], dts[:, :, local_value_0939:local_value_0939 + local_value_0519], local_value_0009, Bs[:, :, local_value_0939:local_value_0939 + local_value_0519], Cs[:, :, local_value_0939:local_value_0939 + local_value_0519], local_value_0933, mask)
            local_value_1181.append(ys)
            local_value_1128.append(local_value_0933)
        local_value_1181 = local_value_1650.cat(local_value_1181, dim=2)
        if local_value_0914:
            local_value_1181 = local_value_1181 + Ds.view(1, local_value_0122, 1, D) * us
        local_value_1181 = local_value_1181.permute(0, 1, 3, 2).contiguous().view(B, -1, L)
        local_value_0933 = local_value_0933.permute(0, 1, 3, 2).contiguous().view(B, local_value_0123, N).float()
        local_value_1128 = local_value_1650.stack(local_value_1128, dim=2)
        local_value_0551.local_value_0519 = local_value_0519
        local_value_0551.local_value_0696 = local_value_0696
        save_for_backward.extend([mask, us, dts, local_value_0009, Bs, Cs, Ds, delta_bias, local_value_1128])
        local_value_0551.save_for_backward(*save_for_backward)
        return local_value_1181.to(local_value_0976) if not return_last_state else (local_value_1181.to(local_value_0976), local_value_0933)

    @staticmethod
    @local_value_1650.cuda.amp.custom_bwd
    def backward(local_value_0551, local_value_0737: local_value_1650.Tensor, *local_value_0416):
        mask, us, dts, local_value_0009, Bs, Cs, Ds, delta_bias, local_value_1128 = local_value_0551.saved_tensors
        B, local_value_0122, L, N, D = local_value_0551.shape
        local_value_0519 = local_value_0551.local_value_0519
        local_value_0696 = local_value_0551.local_value_0696
        local_value_0737 = local_value_0737.view(B, local_value_0122, D, L).permute(0, 1, 3, 2)

        def execute_step_1280(local_value_1699):
            local_value_0553 = local_value_1650.cumsum(local_value_1699, dim=2)
            return local_value_1699 - local_value_0553 + local_value_0553[:, :, -1:None]
        local_value_0801 = None
        local_value_0594 = None
        if Ds is not None:
            local_value_0594 = local_value_1650.einsum('bgld,bgld->gd', local_value_0737, us).view(-1)
            local_value_0801 = local_value_1650.einsum('bgld,gd->bgld', local_value_0737, Ds)
        local_value_0518 = list(range(0, L, local_value_0519))
        local_value_0577 = us.new_zeros((local_value_0122, N, D), dtype=local_value_1650.float)
        local_value_0801 = us.new_zeros((B, local_value_0122, L, D), dtype=local_value_1650.float) if local_value_0801 is None else local_value_0801
        local_value_0682 = us.new_zeros((B, local_value_0122, L, D), dtype=local_value_1650.float)
        local_value_0584 = us.new_zeros((B, local_value_0122, L, N), dtype=local_value_1650.float)
        local_value_0588 = us.new_zeros((B, local_value_0122, L, N), dtype=local_value_1650.float)
        local_value_0703 = us.new_zeros((B, local_value_0122, N, D), dtype=local_value_1650.float)
        local_value_1129 = -2
        for local_value_0939 in local_value_0518[::-1]:
            local_value_0913 = local_value_1128[:, :, local_value_1129]
            local_value_1129 = local_value_1129 - 1
            local_value_0557 = us[:, :, local_value_0939:local_value_0939 + local_value_0519]
            local_value_0488 = dts[:, :, local_value_0939:local_value_0939 + local_value_0519]
            local_value_0464 = Bs[:, :, local_value_0939:local_value_0939 + local_value_0519]
            local_value_0465 = Cs[:, :, local_value_0939:local_value_0939 + local_value_0519]
            local_value_0487 = local_value_0737[:, :, local_value_0939:local_value_0939 + local_value_0519]
            local_value_0466 = local_value_0557.shape[2]
            local_value_0369 = (mask[:local_value_0466, :local_value_0466].contiguous() if local_value_0466 < local_value_0519 else mask).view(1, 1, local_value_0466, local_value_0466, 1)
            local_value_1659 = local_value_1650.cumsum(local_value_0488, dim=2)
            local_value_1685 = local_value_0009[None, :, None, :, :] * local_value_1659[..., None, :]
            local_value_1672 = local_value_0557 * local_value_0488
            k = local_value_0464
            local_value_1236 = local_value_0465
            local_value_1683 = local_value_1685.exp()
            local_value_0999 = k[..., None] / local_value_1683
            local_value_1237 = local_value_1236[..., None] * local_value_1683
            local_value_1088 = local_value_1650.einsum('bhlkv,bhlv->bhkv', local_value_0999, local_value_1672)
            local_value_1742 = local_value_1650.einsum('bhlkv,bhrkv->bhlrv', local_value_1237, local_value_0999) * local_value_0369
            local_value_0610, local_value_0627, local_value_0602 = (None, None, None)
            local_value_0605 = None
            if True:
                local_value_0629 = local_value_1650.einsum('bhlv,bhlrv->bhrv', local_value_0487, local_value_1742)
                local_value_0638 = local_value_1650.einsum('bhlv,bhrv->bhlrv', local_value_0487, local_value_1672) * local_value_0369
                local_value_0622 = local_value_1650.einsum('bhlrv,bhrkv->bhlkv', local_value_0638, local_value_0999)
                local_value_0613 = local_value_1650.einsum('bhlrv,bhlkv->bhrkv', local_value_0638, local_value_1237)
                local_value_0635 = local_value_0703 * local_value_1088
                local_value_0615 = local_value_0703 * local_value_1683[:, :, -1]
                local_value_0612 = local_value_1650.einsum('bhkv,bhlv->bhlkv', local_value_0615, local_value_1672)
                local_value_0628 = local_value_1650.einsum('bhkv,bhlkv->bhlv', local_value_0615, local_value_0999)
                local_value_0620 = local_value_1650.einsum('bhlkv,bhlkv->bhlk', local_value_0622, local_value_1683)
                local_value_0633 = local_value_1650.einsum('bhlkv,bhlk->bhlkv', local_value_0622, local_value_1236)
                local_value_0611 = local_value_0613 + local_value_0612
                local_value_0610 = local_value_1650.einsum('bhlkv->bhlk', local_value_0611 / local_value_1683)
                local_value_0632 = local_value_0611 * (-local_value_0999 / local_value_1683)
                local_value_0631 = local_value_0633 + local_value_0632
                local_value_0631[:, :, -1] += local_value_0635
                local_value_0637 = local_value_0631 * local_value_1683
                local_value_0626 = local_value_1650.einsum('bhlkv,hkv->bhlv', local_value_0637, local_value_0009)
                local_value_0596 = local_value_1650.einsum('bhlkv,bhlv->hkv', local_value_0637, local_value_1659)
                local_value_0599 = execute_step_1280(local_value_0626)
                local_value_0627 = local_value_0629 + local_value_0628
                local_value_0600 = local_value_0627 * local_value_0557
                local_value_0602 = local_value_0627 * local_value_0488
                local_value_0598 = local_value_0599 + local_value_0600
                local_value_0619 = local_value_0620
            if True:
                local_value_0607 = local_value_1650.einsum('bhlv,bhlkv->bhkv', local_value_0487, local_value_1237)
                local_value_0621 = local_value_1650.einsum('bhlv,bhkv->bhlkv', local_value_0487, local_value_0913)
                local_value_0606 = local_value_0703 * local_value_1683[:, :, -1]
                local_value_0634 = local_value_0703 * local_value_0913
                local_value_0605 = local_value_0607 + local_value_0606
                local_value_0618 = local_value_1650.einsum('bhlkv,bhlkv->bhlk', local_value_0621, local_value_1683)
                local_value_0630 = local_value_1650.einsum('bhlkv,bhlk->bhlkv', local_value_0621, local_value_1236)
                local_value_0630[:, :, -1] += local_value_0634
                local_value_0636 = local_value_0630 * local_value_1683
                local_value_0625 = local_value_1650.einsum('bhlkv,hkv->bhlv', local_value_0636, local_value_0009)
                local_value_0595 = local_value_1650.einsum('bhlkv,bhlv->hkv', local_value_0636, local_value_1659)
                local_value_0597 = execute_step_1280(local_value_0625)
            local_value_0801[:, :, local_value_0939:local_value_0939 + local_value_0519] += local_value_0602
            local_value_0682[:, :, local_value_0939:local_value_0939 + local_value_0519] = local_value_0598 + local_value_0597
            local_value_0577 += local_value_0596 + local_value_0595
            local_value_0584[:, :, local_value_0939:local_value_0939 + local_value_0519] = local_value_0610
            local_value_0588[:, :, local_value_0939:local_value_0939 + local_value_0519] = local_value_0619 + local_value_0618
            local_value_0703 = local_value_0605
        if local_value_0696:
            local_value_0682 = local_value_0682 - local_value_0682 * (-dts).exp()
        local_value_0671 = None
        if delta_bias is not None:
            local_value_0671 = local_value_0682.sum([0, 2])
            local_value_0671 = local_value_0671.view(-1)
        local_value_0577 = local_value_0577.permute(0, 2, 1).contiguous().view(-1, N)
        local_value_0801 = local_value_0801.permute(0, 1, 3, 2).contiguous().view(B, -1, L)
        local_value_0682 = local_value_0682.permute(0, 1, 3, 2).contiguous().view(B, -1, L)
        local_value_0584 = local_value_0584.permute(0, 1, 3, 2).contiguous()
        local_value_0588 = local_value_0588.permute(0, 1, 3, 2).contiguous()
        return (local_value_0801, local_value_0682, local_value_0577, local_value_0584, local_value_0588, local_value_0594, local_value_0671, None, None, None)

def execute_step_1327(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias=None, local_value_0696=None, return_last_state=False, local_value_0519=64):
    local_value_1177 = ComponentUnit0233.apply(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, return_last_state, local_value_0519)
    return (local_value_1177[0].to(local_value_1660.dtype), *local_value_1177[1:]) if return_last_state else local_value_1177[0].to(local_value_1660.dtype)
execute_step_1323 = execute_step_1323
execute_step_1323 = execute_step_1326
execute_step_1323 = execute_step_1328
from ssmtriton import selective_scan_easyv3 as local_value_1367
execute_step_1323 = local_value_1367

def execute_step_0457(local_value_0519=64):

    def execute_step_1330(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753=None, delta_bias=None, local_value_0696=None, return_last_state=False):
        assert local_value_1753 is None
        return execute_step_1323(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, return_last_state, local_value_0519)
    return execute_step_1330

def execute_step_1331(local_value_1660, delta, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, delta_bias=None, local_value_0696=False, return_last_state=False):
    local_value_0799 = local_value_1660.dtype
    local_value_1660 = local_value_1660.float()
    delta = delta.float()
    if delta_bias is not None:
        delta = delta + delta_bias[..., None].float()
    if local_value_0696:
        delta = local_value_0117.softplus(delta)
    local_value_0434, dim, local_value_0759 = (local_value_1660.shape[0], local_value_0000.shape[0], local_value_0000.shape[1])
    local_value_0993 = B.dim() >= 3
    local_value_0994 = local_value_0044.dim() >= 3
    if local_value_0000.is_complex():
        if local_value_0993:
            B = local_value_1650.view_as_complex(local_value_1249(B.float(), '... (L two) -> ... L two', two=2))
        if local_value_0994:
            local_value_0044 = local_value_1650.view_as_complex(local_value_1249(local_value_0044.float(), '... (L two) -> ... L two', two=2))
    else:
        B = B.float()
        local_value_0044 = local_value_0044.float()
    local_value_1699 = local_value_0000.new_zeros((local_value_0434, dim, local_value_0759))
    ys = []
    local_value_0690 = local_value_1650.exp(local_value_1650.einsum('bdl,dn->bdln', delta, local_value_0000))
    if not local_value_0993:
        local_value_0691 = local_value_1650.einsum('bdl,dn,bdl->bdln', delta, B, local_value_1660)
    elif B.dim() == 3:
        local_value_0691 = local_value_1650.einsum('bdl,bnl,bdl->bdln', delta, B, local_value_1660)
    else:
        B = repeat(B, 'B G N L -> B (G H) N L', H=dim // B.shape[1])
        local_value_0691 = local_value_1650.einsum('bdl,bdnl,bdl->bdln', delta, B, local_value_1660)
    if local_value_0994 and local_value_0044.dim() == 4:
        local_value_0044 = repeat(local_value_0044, 'B G N L -> B (G H) N L', H=dim // local_value_0044.shape[1])
    local_value_1013 = None
    for local_value_0939 in range(local_value_1660.shape[2]):
        local_value_1699 = local_value_0690[:, :, local_value_0939] * local_value_1699 + local_value_0691[:, :, local_value_0939]
        if not local_value_0994:
            y = local_value_1650.einsum('bdn,dn->bd', local_value_1699, local_value_0044)
        elif local_value_0044.dim() == 3:
            y = local_value_1650.einsum('bdn,bn->bd', local_value_1699, local_value_0044[:, :, local_value_0939])
        else:
            y = local_value_1650.einsum('bdn,bdn->bd', local_value_1699, local_value_0044[:, :, :, local_value_0939])
        if local_value_0939 == local_value_1660.shape[2] - 1:
            local_value_1013 = local_value_1699
        if y.is_complex():
            y = y.real * 2
        ys.append(y)
    y = local_value_1650.stack(ys, dim=2)
    out = y if D is None else y + local_value_1660 * local_value_1249(D, 'd -> d 1')
    if local_value_1753 is not None:
        out = out * local_value_0117.silu(local_value_1753)
    out = out.to(dtype=local_value_0799)
    return out if not return_last_state else (out, local_value_1013)

@local_value_1235.mark.parametrize('local_value_1698', [local_value_1650.float32])
@local_value_1235.mark.parametrize('local_value_0996', [local_value_1650.float32])
@local_value_1235.mark.parametrize('local_value_1348', [65, 128, 256, 512, 1024, 2048, 4096])
@local_value_1235.mark.parametrize('return_last_state', [True])
@local_value_1235.mark.parametrize('local_value_0916', [False, True])
@local_value_1235.mark.parametrize('local_value_0696', [False, True])
@local_value_1235.mark.parametrize('local_value_0922', [False])
@local_value_1235.mark.parametrize('local_value_0914', [False, True])
@local_value_1235.mark.parametrize('local_value_1676', [2])
@local_value_1235.mark.parametrize('local_value_0994', [True])
@local_value_1235.mark.parametrize('local_value_0993', [True])
@local_value_1235.mark.parametrize('local_value_0519', [64])
def execute_step_1624(local_value_0993, local_value_0994, local_value_1676, local_value_0914, local_value_0922, local_value_0916, local_value_0696, return_last_state, local_value_1348, local_value_0996, local_value_1698, local_value_0519):
    execute_step_1330 = execute_step_0457(local_value_0519=local_value_0519)
    if local_value_1676 > 1 and (not local_value_0993 or not local_value_0994):
        local_value_1235.skip()
    device = 'cuda'
    rtol, atol = (0.0006, 0.002) if local_value_0996 == local_value_1650.float32 else (0.003, 0.005)
    if local_value_0996 == local_value_1650.bfloat16:
        rtol, atol = (0.03, 0.05)
    local_value_1296, local_value_0419 = (0.001, 0.001)
    if local_value_0922:
        local_value_1296 = max(local_value_1296, rtol)
        local_value_0419 = max(local_value_0419, atol)
    local_value_1650.random.manual_seed(0)
    local_value_0437 = 2
    dim = 18
    local_value_0759 = 8
    local_value_0759 = 1
    local_value_0989 = local_value_1698 == local_value_1650.complex64
    local_value_0000 = (-0.5 * local_value_1650.rand(dim, local_value_0759, device=device, dtype=local_value_1698)).requires_grad_()
    if not local_value_0993:
        local_value_0036 = (dim, local_value_0759)
    elif local_value_1676 == 1:
        local_value_0036 = (local_value_0437, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    else:
        local_value_0036 = (local_value_0437, local_value_1676, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    B = local_value_1650.randn(*local_value_0036, device=device, dtype=local_value_1698 if not local_value_0993 else local_value_0996, requires_grad=True)
    if not local_value_0994:
        local_value_0059 = (dim, local_value_0759)
    elif local_value_1676 == 1:
        local_value_0059 = (local_value_0437, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    else:
        local_value_0059 = (local_value_0437, local_value_1676, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    local_value_0044 = local_value_1650.randn(*local_value_0059, device=device, dtype=local_value_1698 if not local_value_0994 else local_value_0996, requires_grad=True)
    if local_value_0914:
        D = local_value_1650.randn(dim, device=device, dtype=local_value_1650.float32, requires_grad=True)
    else:
        D = None
    if local_value_0922:
        local_value_1753 = local_value_1650.randn(local_value_0437, dim, local_value_1348, device=device, dtype=local_value_0996, requires_grad=True)
    else:
        local_value_1753 = None
    if local_value_0916:
        delta_bias = (0.5 * local_value_1650.rand(dim, device=device, dtype=local_value_1650.float32)).requires_grad_()
    else:
        delta_bias = None
    local_value_1660 = local_value_1650.randn(local_value_0437, dim, local_value_1348, device=device, dtype=local_value_0996, requires_grad=True)
    delta = (0.5 * local_value_1650.rand(local_value_0437, dim, local_value_1348, device=device, dtype=local_value_0996)).requires_grad_()
    local_value_0007 = local_value_0000.detach().clone().requires_grad_()
    local_value_0035 = B.detach().clone().requires_grad_()
    local_value_0058 = local_value_0044.detach().clone().requires_grad_()
    local_value_0110 = D.detach().clone().requires_grad_() if D is not None else None
    local_value_1756 = local_value_1753.detach().clone().requires_grad_() if local_value_1753 is not None else None
    local_value_1662 = local_value_1660.detach().clone().requires_grad_()
    local_value_0695 = delta.detach().clone().requires_grad_()
    local_value_0694 = delta_bias.detach().clone().requires_grad_() if delta_bias is not None else None
    out, *local_value_1273 = execute_step_1330(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753=local_value_1753, delta_bias=delta_bias, local_value_0696=local_value_0696, return_last_state=return_last_state)
    if return_last_state:
        local_value_1391 = local_value_1273[0]
    local_value_1165, *local_value_1273 = execute_step_1331(local_value_1662, local_value_0695, local_value_0007, local_value_0035, local_value_0058, local_value_0110, local_value_1753=local_value_1756, delta_bias=local_value_0694, local_value_0696=local_value_0696, return_last_state=return_last_state)
    if return_last_state:
        local_value_1399 = local_value_1273[0]
    print(f'Output max diff: {(out - local_value_1165).abs().max().item()}')
    print(f'Output mean diff: {(out - local_value_1165).abs().mean().item()}')
    assert local_value_1650.allclose(out, local_value_1165, rtol=rtol, atol=atol)
    if return_last_state:
        print(f'State max diff: {(local_value_1391 - local_value_1399).abs().max().item()}')
        assert local_value_1650.allclose(local_value_1391, local_value_1399, rtol=rtol, atol=atol)
    g = local_value_1650.randn_like(out)
    local_value_1165.backward(g)
    out.backward(g)
    print(f'du max diff: {(local_value_1660.grad - local_value_1662.grad).abs().max().item()}')
    print(f'ddelta max diff: {(delta.grad - local_value_0695.grad).abs().max().item()}')
    print(f'dA max diff: {(local_value_0000.grad - local_value_0007.grad).abs().max().item()}')
    print(f'dB max diff: {(B.grad - local_value_0035.grad).abs().max().item()}')
    print(f'dC max diff: {(local_value_0044.grad - local_value_0058.grad).abs().max().item()}')
    if local_value_0914:
        print(f'dD max diff: {(D.grad - local_value_0110.grad).abs().max().item()}')
    if local_value_0922:
        print(f'dz max diff: {(local_value_1753.grad - local_value_1756.grad).abs().max().item()}')
    if local_value_0916:
        print(f'ddelta_bias max diff: {(delta_bias.grad - local_value_0694.grad).abs().max().item()}')
    assert local_value_1650.allclose(local_value_1660.grad, local_value_1662.grad.to(dtype=local_value_0996), rtol=rtol * 2, atol=atol * 2)
    assert local_value_1650.allclose(delta.grad, local_value_0695.grad.to(dtype=local_value_0996), rtol=rtol * 5, atol=atol * 10)
    assert local_value_1650.allclose(local_value_0000.grad, local_value_0007.grad, rtol=local_value_1296, atol=local_value_0419 * 5)
    assert local_value_1650.allclose(B.grad, local_value_0035.grad, rtol=local_value_1296 if not local_value_0993 else rtol, atol=local_value_0419 if not local_value_0993 else atol)
    assert local_value_1650.allclose(local_value_0044.grad, local_value_0058.grad, rtol=local_value_1296 if not local_value_0994 else rtol, atol=local_value_0419 if not local_value_0994 else atol)
    if local_value_0914:
        assert local_value_1650.allclose(D.grad, local_value_0110.grad, rtol=local_value_1296, atol=local_value_0419)
    if local_value_0922:
        assert local_value_1650.allclose(local_value_1753.grad, local_value_1756.grad, rtol=local_value_1296, atol=local_value_0419)
    if local_value_0916:
        assert local_value_1650.allclose(delta_bias.grad, local_value_0694.grad, rtol=local_value_1296, atol=local_value_0419)
if __name__ == '__main__':
    execute_step_1624(True, True, 3, True, False, True, True, True, 1011, local_value_1650.float32, local_value_1650.float32, 64)
