import math as local_value_1039
import torch as local_value_1650
import torch.nn.functional as local_value_0117
import pytest as local_value_1235
import torch as local_value_1650
import torch.nn.functional as local_value_0117
from torch.cuda.amp import custom_bwd as local_value_0558, custom_fwd as local_value_0559
from einops import rearrange as local_value_1249, repeat
import time as local_value_1630
from functools import partial as local_value_1197
local_value_0225 = True

def execute_step_0459(local_value_1319: object=None, mode='mamba_ssm', local_value_1620=None):
    local_value_0179 = mode

    class ComponentUnit0232(local_value_1650.autograd.Function):

        @staticmethod
        def forward(local_value_0551, local_value_1660, delta, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, delta_bias=None, local_value_0696=False, return_last_state=False, local_value_1106=1, local_value_0431=-1):
            if local_value_1660.stride(-1) != 1:
                local_value_1660 = local_value_1660.contiguous()
            if delta.stride(-1) != 1:
                delta = delta.contiguous()
            if D is not None:
                D = D.contiguous()
            if B.stride(-1) != 1:
                B = B.contiguous()
            if local_value_0044.stride(-1) != 1:
                local_value_0044 = local_value_0044.contiguous()
            if local_value_1753 is not None and local_value_1753.stride(-1) != 1:
                local_value_1753 = local_value_1753.contiguous()
            if B.dim() == 3:
                B = local_value_1249(B, 'b dstate l -> b 1 dstate l')
                local_value_0551.member_slot_0442 = True
            if local_value_0044.dim() == 3:
                local_value_0044 = local_value_1249(local_value_0044, 'b dstate l -> b 1 dstate l')
                local_value_0551.member_slot_0443 = True
            if D is not None and D.dtype != local_value_1650.float:
                local_value_0551.member_slot_0109 = D.dtype
                D = D.float()
            if delta_bias is not None and delta_bias.dtype != local_value_1650.float:
                local_value_0551.member_slot_0110 = delta_bias.dtype
                delta_bias = delta_bias.float()
            assert local_value_1660.shape[1] % (B.shape[1] * local_value_1106) == 0
            assert local_value_1106 in [1, 2, 3, 4]
            if local_value_0431 > 0:
                assert local_value_1660.shape[1] % (B.shape[1] * local_value_0431) == 0
                assert local_value_0431 in [1, 2, 3, 4]
            else:
                local_value_0431 = local_value_1106
            local_value_0551.local_value_0431 = local_value_0431
            if local_value_0179 in ['mamba_ssm']:
                out, local_value_1699, *local_value_1273 = local_value_1319.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0696)
            elif local_value_0179 in ['local_value_1385']:
                out, local_value_1699, *local_value_1273 = local_value_1319.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, local_value_1106, local_value_0225)
            elif local_value_0179 in ['sscore']:
                out, local_value_1699, *local_value_1273 = local_value_1319.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, local_value_1106)
            elif local_value_0179 in ['sstest']:
                out, local_value_1699, *local_value_1273 = local_value_1319.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0696, local_value_1106)
            elif local_value_0179 in ['sscorendstate']:
                assert local_value_0000.shape[-1] == 1 and B.shape[2] == 1 and (local_value_0044.shape[2] == 1)
                local_value_0000 = local_value_0000.view(-1)
                B = B.squeeze(2)
                local_value_0044 = local_value_0044.squeeze(2)
                out, local_value_1699, *local_value_1273 = local_value_1319.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, 1)
            else:
                raise NotImplementedError
            local_value_0551.local_value_0696 = local_value_0696
            local_value_0551.local_value_0922 = local_value_1753 is not None
            local_value_1013 = local_value_1699[:, :, -1, 1::2]
            if not local_value_0551.local_value_0922:
                local_value_0551.save_for_backward(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_1699)
                return out if not return_last_state else (out, local_value_1013)
            else:
                local_value_0551.save_for_backward(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_1699, out)
                if local_value_0179 in ['mamba_ssm', 'sstest']:
                    local_value_1170 = local_value_1273[0]
                    return local_value_1170 if not return_last_state else (local_value_1170, local_value_1013)
                elif local_value_0179 in ['sscore', 'local_value_1385']:
                    return out if not return_last_state else (out, local_value_1013)

        @staticmethod
        def backward(local_value_0551, local_value_0723, *local_value_0416):
            if not local_value_0551.local_value_0922:
                local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_1699 = local_value_0551.saved_tensors
                local_value_1753 = None
                out = None
            else:
                local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_1699, out = local_value_0551.saved_tensors
            if local_value_0723.stride(-1) != 1:
                local_value_0723 = local_value_0723.contiguous()
            if local_value_0179 in ['mamba_ssm']:
                local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, *local_value_1273 = local_value_1319.bwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0723, local_value_1699, out, None, local_value_0551.local_value_0696, False)
            elif local_value_0179 in ['sstest']:
                local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, *local_value_1273 = local_value_1319.bwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0723, local_value_1699, out, None, local_value_0551.local_value_0696, False, local_value_0551.local_value_0431)
            elif local_value_0179 in ['sscore', 'local_value_1385']:
                local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, *local_value_1273 = local_value_1319.bwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0723, local_value_1699, local_value_0551.local_value_0696, local_value_0551.local_value_0431)
            elif local_value_0179 in ['sscorendstate']:
                local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, *local_value_1273 = local_value_1319.bwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0723, local_value_1699, local_value_0551.local_value_0696, 1)
                local_value_0564 = local_value_0564.unsqueeze(1)
                local_value_0582 = local_value_0582.unsqueeze(2)
                local_value_0585 = local_value_0585.unsqueeze(2)
            else:
                raise NotImplementedError
            local_value_0816 = local_value_1273[0] if local_value_0551.local_value_0922 else None
            local_value_0582 = local_value_0582.squeeze(1) if getattr(local_value_0551, 'member_slot_0442', False) else local_value_0582
            local_value_0585 = local_value_0585.squeeze(1) if getattr(local_value_0551, 'member_slot_0443', False) else local_value_0585
            local_value_0332 = None
            if D is not None:
                if local_value_0589.dtype != getattr(local_value_0551, 'member_slot_0109', local_value_0589.dtype):
                    local_value_0332 = local_value_0589.to(local_value_0551.member_slot_0109)
                else:
                    local_value_0332 = local_value_0589
            local_value_0335 = None
            if delta_bias is not None:
                if local_value_0671.dtype != getattr(local_value_0551, 'member_slot_0110', local_value_0671.dtype):
                    local_value_0335 = local_value_0671.to(local_value_0551.member_slot_0110)
                else:
                    local_value_0335 = local_value_0671
            return (local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589 if D is not None else None, local_value_0816, local_value_0671 if delta_bias is not None else None, None, None, None, None)

    def execute_step_1330(local_value_1660, delta, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, delta_bias=None, local_value_0696=False, return_last_state=False, local_value_1106=1, local_value_0431=-1):
        local_value_1177 = ComponentUnit0232.apply(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0696, return_last_state, local_value_1106, local_value_0431)
        if mode in ['local_value_1385']:
            return local_value_1177.to(local_value_1660.dtype) if not return_last_state else (local_value_1177[0].to(local_value_1660.dtype), local_value_1177[1])
        else:
            return local_value_1177
    execute_step_1330.__repr__ = lambda *local_value_0272: f'execute_step_1330 | {mode} | {local_value_1620}'
    return execute_step_1330

def execute_step_1331(local_value_1660, delta, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, delta_bias=None, local_value_0696=False, return_last_state=False):
    local_value_0799 = local_value_1660.dtype
    local_value_1660 = local_value_1660.float()
    delta = delta.float()
    if delta_bias is not None:
        delta = delta + delta_bias[..., None].float()
    if local_value_0696:
        delta = local_value_0117.softplus(delta)
    local_value_0434, dim, local_value_0759 = (local_value_1660.shape[0], local_value_0000.shape[0], local_value_0000.shape[1])
    local_value_0993 = B.dim() >= 3
    local_value_0994 = local_value_0044.dim() >= 3
    if local_value_0000.is_complex():
        if local_value_0993:
            B = local_value_1650.view_as_complex(local_value_1249(B.float(), '... (L two) -> ... L two', two=2))
        if local_value_0994:
            local_value_0044 = local_value_1650.view_as_complex(local_value_1249(local_value_0044.float(), '... (L two) -> ... L two', two=2))
    else:
        B = B.float()
        local_value_0044 = local_value_0044.float()
    local_value_1699 = local_value_0000.new_zeros((local_value_0434, dim, local_value_0759))
    ys = []
    local_value_0690 = local_value_1650.exp(local_value_1650.einsum('bdl,dn->bdln', delta, local_value_0000))
    if not local_value_0993:
        local_value_0691 = local_value_1650.einsum('bdl,dn,bdl->bdln', delta, B, local_value_1660)
    elif B.dim() == 3:
        local_value_0691 = local_value_1650.einsum('bdl,bnl,bdl->bdln', delta, B, local_value_1660)
    else:
        B = repeat(B, 'B G N L -> B (G H) N L', H=dim // B.shape[1])
        local_value_0691 = local_value_1650.einsum('bdl,bdnl,bdl->bdln', delta, B, local_value_1660)
    if local_value_0994 and local_value_0044.dim() == 4:
        local_value_0044 = repeat(local_value_0044, 'B G N L -> B (G H) N L', H=dim // local_value_0044.shape[1])
    local_value_1013 = None
    for local_value_0939 in range(local_value_1660.shape[2]):
        local_value_1699 = local_value_0690[:, :, local_value_0939] * local_value_1699 + local_value_0691[:, :, local_value_0939]
        if not local_value_0994:
            y = local_value_1650.einsum('bdn,dn->bd', local_value_1699, local_value_0044)
        elif local_value_0044.dim() == 3:
            y = local_value_1650.einsum('bdn,bn->bd', local_value_1699, local_value_0044[:, :, local_value_0939])
        else:
            y = local_value_1650.einsum('bdn,bdn->bd', local_value_1699, local_value_0044[:, :, :, local_value_0939])
        if local_value_0939 == local_value_1660.shape[2] - 1:
            local_value_1013 = local_value_1699
        if y.is_complex():
            y = y.real * 2
        ys.append(y)
    y = local_value_1650.stack(ys, dim=2)
    out = y if D is None else y + local_value_1660 * local_value_1249(D, 'd -> d 1')
    if local_value_1753 is not None:
        out = out * local_value_0117.silu(local_value_1753)
    out = out.to(dtype=local_value_0799)
    return out if not return_last_state else (out, local_value_1013)

def execute_step_1332(local_value_1660, delta, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, delta_bias=None, local_value_0696=False, return_last_state=False):
    local_value_0799 = local_value_1660.dtype
    local_value_0000 = local_value_0000.to(local_value_0799)
    B = B.to(local_value_0799)
    local_value_0044 = local_value_0044.to(local_value_0799)
    D = D.to(local_value_0799) if D is not None else None
    local_value_1753 = local_value_1753.to(local_value_0799) if local_value_1753 is not None else None
    delta = delta.to(local_value_0799) if delta is not None else None
    delta_bias = delta_bias.to(local_value_0799) if delta_bias is not None else None
    if delta_bias is not None:
        delta = delta + delta_bias[..., None]
    if local_value_0696:
        delta = local_value_0117.softplus(delta)
    local_value_0434, dim, local_value_0759 = (local_value_1660.shape[0], local_value_0000.shape[0], local_value_0000.shape[1])
    local_value_0993 = B.dim() >= 3
    local_value_0994 = local_value_0044.dim() >= 3
    if local_value_0000.is_complex():
        if local_value_0993:
            B = local_value_1650.view_as_complex(local_value_1249(B, '... (L two) -> ... L two', two=2))
        if local_value_0994:
            local_value_0044 = local_value_1650.view_as_complex(local_value_1249(local_value_0044, '... (L two) -> ... L two', two=2))
    local_value_1699 = local_value_0000.new_zeros((local_value_0434, dim, local_value_0759))
    ys = []
    local_value_0690 = local_value_1650.exp(local_value_1650.einsum('bdl,dn->bdln', delta, local_value_0000))
    if not local_value_0993:
        local_value_0691 = local_value_1650.einsum('bdl,dn,bdl->bdln', delta, B, local_value_1660)
    elif B.dim() == 3:
        local_value_0691 = local_value_1650.einsum('bdl,bnl,bdl->bdln', delta, B, local_value_1660)
    else:
        B = repeat(B, 'B G N L -> B (G H) N L', H=dim // B.shape[1])
        local_value_0691 = local_value_1650.einsum('bdl,bdnl,bdl->bdln', delta, B, local_value_1660)
    if local_value_0994 and local_value_0044.dim() == 4:
        local_value_0044 = repeat(local_value_0044, 'B G N L -> B (G H) N L', H=dim // local_value_0044.shape[1])
    local_value_1013 = None
    for local_value_0939 in range(local_value_1660.shape[2]):
        local_value_1699 = local_value_0690[:, :, local_value_0939] * local_value_1699 + local_value_0691[:, :, local_value_0939]
        if not local_value_0994:
            y = local_value_1650.einsum('bdn,dn->bd', local_value_1699, local_value_0044)
        elif local_value_0044.dim() == 3:
            y = local_value_1650.einsum('bdn,bn->bd', local_value_1699, local_value_0044[:, :, local_value_0939])
        else:
            y = local_value_1650.einsum('bdn,bdn->bd', local_value_1699, local_value_0044[:, :, :, local_value_0939])
        if local_value_0939 == local_value_1660.shape[2] - 1:
            local_value_1013 = local_value_1699
        if y.is_complex():
            y = y.real * 2
        ys.append(y)
    y = local_value_1650.stack(ys, dim=2)
    out = y if D is None else y + local_value_1660 * local_value_1249(D, 'd -> d 1')
    if local_value_1753 is not None:
        out = out * local_value_0117.silu(local_value_1753)
    out = out.to(dtype=local_value_0799)
    return out if not return_last_state else (out, local_value_1013.float())

def execute_step_1330(local_value_1660, delta, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, delta_bias=None, local_value_0696=False, return_last_state=False, *local_value_0416, **local_value_1007):
    return execute_step_1332(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0696, return_last_state)
local_value_0179 = 'mamba_ssm_ssoflex'
if local_value_0179 in ['mamba_ssm']:
    import selective_scan_cuda as local_value_1319
    execute_step_1330 = execute_step_0459(local_value_1319, mode=local_value_0179)
    execute_step_1331 = execute_step_1331
elif local_value_0179 in ['local_value_1385']:
    import selective_scan_cuda_oflex as local_value_1321
    local_value_1319 = local_value_1321
    execute_step_1330 = execute_step_0459(local_value_1321, mode=local_value_0179)
    execute_step_1331 = execute_step_1331
elif local_value_0179 in ['sscore']:
    import selective_scan_cuda_core as local_value_1320
    local_value_1319 = local_value_1320
    execute_step_1330 = execute_step_0459(local_value_1320, mode=local_value_0179)
    execute_step_1331 = execute_step_1331
elif local_value_0179 in ['sstest']:
    import selective_scan_cuda_test as local_value_1322
    local_value_1319 = local_value_1322
    execute_step_1330 = execute_step_0459(local_value_1322, mode=local_value_0179)
    execute_step_1331 = execute_step_1331
elif local_value_0179 in ['mamba_ssm_sscore']:
    import selective_scan_cuda_core as local_value_1320
    import selective_scan_cuda as local_value_1319
    execute_step_1330 = execute_step_0459(local_value_1320, mode='sscore')
    execute_step_1331 = execute_step_0459(local_value_1319, mode='mamba_ssm')
elif local_value_0179 in ['mamba_ssm_sstest']:
    import selective_scan_cuda_test as local_value_1322
    import selective_scan_cuda as local_value_1319
    execute_step_1330 = execute_step_0459(local_value_1322, mode='sstest')
    execute_step_1331 = execute_step_0459(local_value_1319, mode='mamba_ssm')
elif local_value_0179 in ['mamba_ssm_sscorendstate']:
    import selective_scan_cuda_core as local_value_1320
    import selective_scan_cuda as local_value_1319
    execute_step_1330 = execute_step_0459(local_value_1320, mode='sscorendstate')
    execute_step_1331 = execute_step_0459(local_value_1319, mode='mamba_ssm')
elif local_value_0179 in ['mamba_ssm_ssoflex']:
    import selective_scan_cuda_oflex as local_value_1321
    import selective_scan_cuda as local_value_1319
    execute_step_1330 = execute_step_0459(local_value_1321, mode='local_value_1385')
    execute_step_1331 = execute_step_0459(local_value_1319, mode='mamba_ssm')
else:
    local_value_1319 = None
print('use MODE:', local_value_0179)
local_value_0096 = [1]
local_value_0090 = [768]
local_value_0091 = [768]
local_value_0091 = [24]
local_value_0016 = [2]
local_value_0192 = [1, 2, 3, 4]
local_value_0152 = local_value_0179 in [None]

@local_value_1235.mark.parametrize('local_value_1698', [local_value_1650.float32])
@local_value_1235.mark.parametrize('local_value_0996', [local_value_1650.float32, local_value_1650.float16, local_value_1650.bfloat16])
@local_value_1235.mark.parametrize('local_value_1348', [64, 128, 256, 512, 1024, 2048, 4096])
@local_value_1235.mark.parametrize('return_last_state', [True])
@local_value_1235.mark.parametrize('local_value_0916', [False, True])
@local_value_1235.mark.parametrize('local_value_0696', [False, True])
@local_value_1235.mark.parametrize('local_value_0922', [False])
@local_value_1235.mark.parametrize('local_value_0914', [False, True])
@local_value_1235.mark.parametrize('local_value_1676', [1, 2])
@local_value_1235.mark.parametrize('local_value_0994', [True])
@local_value_1235.mark.parametrize('local_value_0993', [True])
@local_value_1235.mark.parametrize('local_value_1106', local_value_0192)
@local_value_1235.mark.parametrize('local_value_0437', local_value_0016)
@local_value_1235.mark.parametrize('dim', local_value_0090)
@local_value_1235.mark.parametrize('dim1', local_value_0091)
@local_value_1235.mark.parametrize('local_value_0759', local_value_0096)
def execute_step_1624(local_value_0993, local_value_0994, local_value_1676, local_value_0914, local_value_0922, local_value_0916, local_value_0696, return_last_state, local_value_1348, local_value_0996, local_value_1698, local_value_1106, local_value_0437, dim, dim1, local_value_0759):
    local_value_1698 = local_value_0996 if local_value_0152 else local_value_1698
    print(f'method: {local_value_1319}')
    if local_value_1676 > 1 and (not local_value_0993 or not local_value_0994):
        local_value_1235.skip()
    device = 'cuda'
    rtol, atol = (0.0006, 0.002) if local_value_0996 == local_value_1650.float32 else (0.003, 0.005)
    if local_value_0996 == local_value_1650.bfloat16:
        rtol, atol = (0.03, 0.05)
    local_value_1296, local_value_0419 = (0.001, 0.001)
    if local_value_0922:
        local_value_1296 = max(local_value_1296, rtol)
        local_value_0419 = max(local_value_0419, atol)
    local_value_1650.random.manual_seed(0)
    local_value_0989 = local_value_1698 == local_value_1650.complex64
    local_value_0000 = (-0.5 * local_value_1650.rand(dim, local_value_0759, device=device, dtype=local_value_1698)).requires_grad_()
    if not local_value_0993:
        local_value_0036 = (dim, local_value_0759)
    elif local_value_1676 == 1:
        local_value_0036 = (local_value_0437, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    else:
        local_value_0036 = (local_value_0437, local_value_1676, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    B = local_value_1650.randn(*local_value_0036, device=device, dtype=local_value_1698 if not local_value_0993 else local_value_0996, requires_grad=True)
    if not local_value_0994:
        local_value_0059 = (dim, local_value_0759)
    elif local_value_1676 == 1:
        local_value_0059 = (local_value_0437, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    else:
        local_value_0059 = (local_value_0437, local_value_1676, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    local_value_0044 = local_value_1650.randn(*local_value_0059, device=device, dtype=local_value_1698 if not local_value_0994 else local_value_0996, requires_grad=True)
    if local_value_0914:
        D = local_value_1650.randn(dim, device=device, dtype=local_value_1650.float32, requires_grad=True)
    else:
        D = None
    if local_value_0922:
        local_value_1753 = local_value_1650.randn(local_value_0437, dim, local_value_1348, device=device, dtype=local_value_0996, requires_grad=True)
    else:
        local_value_1753 = None
    if local_value_0916:
        delta_bias = (0.5 * local_value_1650.rand(dim1, device=device, dtype=local_value_1650.float32)).requires_grad_()
    else:
        delta_bias = None
    local_value_1660 = local_value_1650.randn(local_value_0437, dim, local_value_1348, device=device, dtype=local_value_0996, requires_grad=True)
    delta = (0.5 * local_value_1650.rand(local_value_0437, dim1, local_value_1348, device=device, dtype=local_value_0996)).requires_grad_()
    local_value_0007 = local_value_0000.detach().clone().requires_grad_()
    local_value_0035 = B.detach().clone().requires_grad_()
    local_value_0058 = local_value_0044.detach().clone().requires_grad_()
    local_value_0110 = D.detach().clone().requires_grad_() if D is not None else None
    local_value_1756 = local_value_1753.detach().clone().requires_grad_() if local_value_1753 is not None else None
    local_value_1662 = local_value_1660.detach().clone().requires_grad_()
    local_value_0695 = delta.detach().clone().requires_grad_()
    local_value_0694 = delta_bias.detach().clone().requires_grad_() if delta_bias is not None else None
    if dim1 != dim:
        assert dim % dim1 == 0
        local_value_0695 = delta.unsqueeze(2).repeat(1, 1, dim // dim1, 1).contiguous().flatten(1, 2)
        local_value_0695 = local_value_0695.detach().clone().requires_grad_()
        local_value_0694 = delta_bias.unsqueeze(1).repeat(1, dim // dim1).view(-1).detach().clone().requires_grad_() if delta_bias is not None else None
    out, *local_value_1273 = execute_step_1330(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753=local_value_1753, delta_bias=delta_bias, local_value_0696=local_value_0696, return_last_state=return_last_state, local_value_1106=local_value_1106)
    if return_last_state:
        local_value_1391 = local_value_1273[0]
    local_value_1165, *local_value_1273 = execute_step_1331(local_value_1662, local_value_0695, local_value_0007, local_value_0035, local_value_0058, local_value_0110, local_value_1753=local_value_1756, delta_bias=local_value_0694, local_value_0696=local_value_0696, return_last_state=return_last_state)
    if return_last_state:
        local_value_1399 = local_value_1273[0]
    print(f'Output max diff: {(out - local_value_1165).abs().max().item()}')
    print(f'Output mean diff: {(out - local_value_1165).abs().mean().item()}')
    assert local_value_1650.allclose(out, local_value_1165, rtol=rtol, atol=atol)
    if return_last_state:
        print(f'State max diff: {(local_value_1391 - local_value_1399).abs().max().item()}')
        assert local_value_1650.allclose(local_value_1391, local_value_1399, rtol=rtol, atol=atol)
    g = local_value_1650.randn_like(out)
    local_value_1165.backward(g)
    out.backward(g)
    print(f'du max diff: {(local_value_1660.grad - local_value_1662.grad).abs().max().item()}')
    print(f'dA max diff: {(local_value_0000.grad - local_value_0007.grad).abs().max().item()}')
    print(f'dB max diff: {(B.grad - local_value_0035.grad).abs().max().item()}')
    print(f'dC max diff: {(local_value_0044.grad - local_value_0058.grad).abs().max().item()}')
    if local_value_0914:
        print(f'dD max diff: {(D.grad - local_value_0110.grad).abs().max().item()}')
        assert local_value_1650.allclose(D.grad, local_value_0110.grad, rtol=local_value_1296, atol=local_value_0419)
    if local_value_0922:
        print(f'dz max diff: {(local_value_1753.grad - local_value_1756.grad).abs().max().item()}')
        assert local_value_1650.allclose(local_value_1753.grad, local_value_1756.grad, rtol=local_value_1296, atol=local_value_0419)
    assert local_value_1650.allclose(local_value_1660.grad, local_value_1662.grad.to(dtype=local_value_0996), rtol=rtol * 2, atol=atol * 2)
    assert local_value_1650.allclose(local_value_0000.grad, local_value_0007.grad, rtol=local_value_1296, atol=local_value_0419 * 5)
    assert local_value_1650.allclose(B.grad, local_value_0035.grad, rtol=local_value_1296 if not local_value_0993 else rtol, atol=local_value_0419 if not local_value_0993 else atol)
    assert local_value_1650.allclose(local_value_0044.grad, local_value_0058.grad, rtol=local_value_1296 if not local_value_0994 else rtol, atol=local_value_0419 if not local_value_0994 else atol)
    if dim == dim1:
        print(f'ddelta max diff: {(delta.grad - local_value_0695.grad).abs().max().item()}')
        assert local_value_1650.allclose(delta.grad, local_value_0695.grad.to(dtype=local_value_0996), rtol=rtol * 5, atol=atol * 10)
        if local_value_0916:
            print(f'ddelta_bias max diff: {(delta_bias.grad - local_value_0694.grad).abs().max().item()}')
            assert local_value_1650.allclose(delta_bias.grad, local_value_0694.grad, rtol=local_value_1296, atol=local_value_0419)
    else:
        local_value_0702 = local_value_0695.grad.view(local_value_0695.grad.shape[0], -1, dim // dim1, local_value_0695.grad.shape[-1]).sum(2)
        print(f'ddelta max diff: {(delta.grad - local_value_0702).abs().max().item()}')
        assert local_value_1650.allclose(delta.grad, local_value_0702.to(dtype=local_value_0996), rtol=rtol * 5, atol=atol * 10), breakpoint()
        if local_value_0916:
            local_value_0646 = local_value_0694.grad.view(-1, dim // dim1).sum(-1)
            print(f'ddelta_bias max diff: {(delta_bias.grad - local_value_0646).abs().max().item()}')
            assert local_value_1650.allclose(delta_bias.grad, local_value_0646, rtol=local_value_1296, atol=local_value_0419)
