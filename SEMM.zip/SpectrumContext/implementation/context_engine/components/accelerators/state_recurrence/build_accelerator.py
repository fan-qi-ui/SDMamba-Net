import sys as local_value_1617
import warnings as local_value_1686
import os as local_value_1136
import re as local_value_1248
import ast as local_value_0417
from pathlib import Path as local_value_0203
from packaging.version import parse as local_value_1196, Version as local_value_0251
import platform as local_value_1214
import shutil as local_value_1352
from setuptools import setup as local_value_1350, find_packages as local_value_0841
import subprocess as local_value_1614
from wheel.bdist_wheel import bdist_wheel as local_value_0290
import torch as local_value_1650
from torch.utils.cpp_extension import BuildExtension as local_value_0043, CppExtension as local_value_0067, CUDAExtension as local_value_0054, CUDA_HOME as local_value_0055
local_value_1627 = local_value_1136.path.dirname(local_value_1136.path.abspath(__file__))
local_value_0118 = local_value_1136.getenv('local_value_0118', 'FALSE') == 'TRUE'

def execute_step_0880():
    device = local_value_1650.device('cuda')
    local_value_0476 = local_value_1650.cuda.get_device_capability(device)
    return int(str(local_value_0476[0]) + str(local_value_0476[1]))

def execute_step_0881(local_value_0552):
    local_value_1247 = local_value_1614.check_output([local_value_0552 + '/bin/nvcc', '-V'], universal_newlines=True)
    local_value_1174 = local_value_1247.split()
    local_value_1256 = local_value_1174.index('release') + 1
    local_value_0433 = local_value_1196(local_value_1174[local_value_1256].split(',')[0])
    return (local_value_1247, local_value_0433)
local_value_0180 = ['oflex']

def execute_step_0883():
    local_value_0486 = []
    print('\n\ntorch.__version__  = {}\n\n'.format(local_value_1650.__version__))
    print('\n\nCUDA_HOME = {}\n\n'.format(local_value_0055))
    if execute_step_0880() < 80:
        local_value_1686.warn('This code uses BFloat16 date type, which is only supported on GPU architectures with compute capability 8.0 or higher')
    local_value_1065 = True
    if local_value_0055 is not None:
        local_value_0272, local_value_0433 = execute_step_0881(local_value_0055)
        print('CUDA version: ', local_value_0433, flush=True)
        if local_value_0433 < local_value_0251('11.6'):
            local_value_1686.warn('CUDA version ealier than 11.6 may leads to performance mismatch.')
        if local_value_0433 < local_value_0251('11.2'):
            local_value_1065 = False
    local_value_0486.append(f'-arch=sm_{execute_step_0880()}')
    if local_value_1065:
        local_value_0486.extend(['--threads', '4'])
    if local_value_0118:
        local_value_1650._C._GLIBCXX_USE_CXX11_ABI = True
    sources = dict(core=['native_impl/state_recurrence/baseline_backend/engine_unit_011.cpp', 'native_impl/state_recurrence/baseline_backend/engine_unit_016.cu', 'native_impl/state_recurrence/baseline_backend/engine_unit_015.cu'], nrow=['native_impl/state_recurrence/cusnrow/selective_scan_nrow.cpp', 'native_impl/state_recurrence/cusnrow/engine_unit_016.cu', 'native_impl/state_recurrence/cusnrow/selective_scan_core_fwd2.cu', 'native_impl/state_recurrence/cusnrow/selective_scan_core_fwd3.cu', 'native_impl/state_recurrence/cusnrow/selective_scan_core_fwd4.cu', 'native_impl/state_recurrence/cusnrow/engine_unit_015.cu', 'native_impl/state_recurrence/cusnrow/selective_scan_core_bwd2.cu', 'native_impl/state_recurrence/cusnrow/selective_scan_core_bwd3.cu', 'native_impl/state_recurrence/cusnrow/selective_scan_core_bwd4.cu'], ndstate=['native_impl/state_recurrence/cusndstate/selective_scan_ndstate.cpp', 'native_impl/state_recurrence/cusndstate/engine_unit_016.cu', 'native_impl/state_recurrence/cusndstate/engine_unit_015.cu'], oflex=['native_impl/state_recurrence/flexible_backend/engine_unit_019.cpp', 'native_impl/state_recurrence/flexible_backend/engine_unit_016.cu', 'native_impl/state_recurrence/flexible_backend/engine_unit_015.cu'])
    local_value_1075 = dict(core='selective_scan_cuda_core', nrow='selective_scan_cuda_nrow', ndstate='selective_scan_cuda_ndstate', oflex='selective_scan_cuda_oflex')
    ext_modules = [local_value_0054(name=local_value_1075.get(local_value_0179, None), sources=sources.get(local_value_0179, None), extra_compile_args={'cxx': ['-O3', '-std=c++17'], 'nvcc': ['-O3', '-std=c++17', '-U__CUDA_NO_HALF_OPERATORS__', '-U__CUDA_NO_HALF_CONVERSIONS__', '-U__CUDA_NO_BFLOAT16_OPERATORS__', '-U__CUDA_NO_BFLOAT16_CONVERSIONS__', '-U__CUDA_NO_BFLOAT162_OPERATORS__', '-U__CUDA_NO_BFLOAT162_CONVERSIONS__', '--expt-relaxed-constexpr', '--expt-extended-lambda', '--use_fast_math', '--ptxas-options=-v', '-lineinfo'] + local_value_0486}, include_dirs=[local_value_0203(local_value_1627) / 'native_impl' / 'state_recurrence']) for local_value_0179 in local_value_0180]
    return ext_modules
ext_modules = execute_step_0883()
local_value_1350(name='state_recurrence', version='0.0.2', packages=[], description='selective scan', long_description='', long_description_content_type='text/markdown', ext_modules=ext_modules, cmdclass={'bdist_wheel': local_value_0290, 'build_ext': local_value_0043} if ext_modules else {'bdist_wheel': local_value_0290}, python_requires='>=3.7', install_requires=['torch', 'packaging', 'ninja', 'einops'])
