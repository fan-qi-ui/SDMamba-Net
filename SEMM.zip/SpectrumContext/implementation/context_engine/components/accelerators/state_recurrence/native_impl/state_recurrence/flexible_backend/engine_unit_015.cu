
#include "engine_unit_013.cuh"

template void NativeUnit022<1, float, float, float>(NativeUnit009 &params, cudaStream_t stream);
template void NativeUnit022<1, at::Half, float, float>(NativeUnit009 &params, cudaStream_t stream);
template void NativeUnit022<1, at::BFloat16, float, float>(NativeUnit009 &params, cudaStream_t stream);
template void NativeUnit022<1, at::Half, float, at::Half>(NativeUnit009 &params, cudaStream_t stream);
template void NativeUnit022<1, at::BFloat16, float, at::BFloat16>(NativeUnit009 &params, cudaStream_t stream);

