
#include "engine_unit_018.cuh"

template void NativeUnit027<1, float, float, float>(NativeUnit008 &params, cudaStream_t stream);
template void NativeUnit027<1, at::Half, float, float>(NativeUnit008 &params, cudaStream_t stream);
template void NativeUnit027<1, at::BFloat16, float, float>(NativeUnit008 &params, cudaStream_t stream);
template void NativeUnit027<1, at::Half, float, at::Half>(NativeUnit008 &params, cudaStream_t stream);
template void NativeUnit027<1, at::BFloat16, float, at::BFloat16>(NativeUnit008 &params, cudaStream_t stream);

