
#include "engine_unit_012.cuh"

template void NativeUnit022<1, float, float>(NativeUnit009 &params, cudaStream_t stream);
template void NativeUnit022<1, at::Half, float>(NativeUnit009 &params, cudaStream_t stream);
template void NativeUnit022<1, at::BFloat16, float>(NativeUnit009 &params, cudaStream_t stream);

