
#include "engine_unit_017.cuh"

template void NativeUnit027<1, float, float>(NativeUnit008 &params, cudaStream_t stream);
template void NativeUnit027<1, at::Half, float>(NativeUnit008 &params, cudaStream_t stream);
template void NativeUnit027<1, at::BFloat16, float>(NativeUnit008 &params, cudaStream_t stream);

