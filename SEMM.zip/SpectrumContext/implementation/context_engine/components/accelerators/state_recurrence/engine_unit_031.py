import math as local_value_1039
import torch as local_value_1650
import torch.nn.functional as local_value_0117
import pytest as local_value_1235
import torch as local_value_1650
import torch.nn.functional as local_value_0117
from torch.cuda.amp import custom_bwd as local_value_0558, custom_fwd as local_value_0559
from einops import rearrange as local_value_1249, repeat
import time as local_value_1630
from functools import partial as local_value_1197

def execute_step_0459(local_value_1319: object=None, mode='mamba_ssm', local_value_1620=None):
    local_value_0179 = mode

    class ComponentUnit0232(local_value_1650.autograd.Function):

        @staticmethod
        def forward(local_value_0551, local_value_1660, delta, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, delta_bias=None, local_value_0696=False, return_last_state=False, local_value_1106=1, local_value_0431=-1):
            if local_value_1660.stride(-1) != 1:
                local_value_1660 = local_value_1660.contiguous()
            if delta.stride(-1) != 1:
                delta = delta.contiguous()
            if D is not None:
                D = D.contiguous()
            if B.stride(-1) != 1:
                B = B.contiguous()
            if local_value_0044.stride(-1) != 1:
                local_value_0044 = local_value_0044.contiguous()
            if local_value_1753 is not None and local_value_1753.stride(-1) != 1:
                local_value_1753 = local_value_1753.contiguous()
            if B.dim() == 3:
                B = local_value_1249(B, 'b dstate l -> b 1 dstate l')
                local_value_0551.member_slot_0442 = True
            if local_value_0044.dim() == 3:
                local_value_0044 = local_value_1249(local_value_0044, 'b dstate l -> b 1 dstate l')
                local_value_0551.member_slot_0443 = True
            if D is not None and D.dtype != local_value_1650.float:
                local_value_0551.member_slot_0109 = D.dtype
                D = D.float()
            if delta_bias is not None and delta_bias.dtype != local_value_1650.float:
                local_value_0551.member_slot_0110 = delta_bias.dtype
                delta_bias = delta_bias.float()
            assert local_value_1660.shape[1] % (B.shape[1] * local_value_1106) == 0
            assert local_value_1106 in [1, 2, 3, 4]
            if local_value_0431 > 0:
                assert local_value_1660.shape[1] % (B.shape[1] * local_value_0431) == 0
                assert local_value_0431 in [1, 2, 3, 4]
            else:
                local_value_0431 = local_value_1106
            local_value_0551.local_value_0431 = local_value_0431
            if local_value_0179 in ['mamba_ssm']:
                out, local_value_1699, *local_value_1273 = local_value_1319.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0696)
            elif local_value_0179 in ['sscore']:
                out, local_value_1699, *local_value_1273 = local_value_1319.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, local_value_1106)
            elif local_value_0179 in ['sstest']:
                out, local_value_1699, *local_value_1273 = local_value_1319.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0696, local_value_1106)
            elif local_value_0179 in ['sscorendstate']:
                assert local_value_0000.shape[-1] == 1 and B.shape[2] == 1 and (local_value_0044.shape[2] == 1)
                local_value_0000 = local_value_0000.view(-1)
                B = B.squeeze(2)
                local_value_0044 = local_value_0044.squeeze(2)
                out, local_value_1699, *local_value_1273 = local_value_1319.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, 1)
            else:
                raise NotImplementedError
            local_value_0551.local_value_0696 = local_value_0696
            local_value_0551.local_value_0922 = local_value_1753 is not None
            local_value_1013 = local_value_1699[:, :, -1, 1::2]
            if not local_value_0551.local_value_0922:
                local_value_0551.save_for_backward(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_1699)
                return out if not return_last_state else (out, local_value_1013)
            else:
                local_value_0551.save_for_backward(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_1699, out)
                if local_value_0179 in ['mamba_ssm', 'sstest']:
                    local_value_1170 = local_value_1273[0]
                    return local_value_1170 if not return_last_state else (local_value_1170, local_value_1013)
                elif local_value_0179 in ['sscore']:
                    return out if not return_last_state else (out, local_value_1013)

        @staticmethod
        def backward(local_value_0551, local_value_0723, *local_value_0416):
            if not local_value_0551.local_value_0922:
                local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_1699 = local_value_0551.saved_tensors
                local_value_1753 = None
                out = None
            else:
                local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_1699, out = local_value_0551.saved_tensors
            if local_value_0723.stride(-1) != 1:
                local_value_0723 = local_value_0723.contiguous()
            if local_value_0179 in ['mamba_ssm']:
                local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, *local_value_1273 = local_value_1319.bwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0723, local_value_1699, out, None, local_value_0551.local_value_0696, False)
            elif local_value_0179 in ['sstest']:
                local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, *local_value_1273 = local_value_1319.bwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0723, local_value_1699, out, None, local_value_0551.local_value_0696, False, local_value_0551.local_value_0431)
            elif local_value_0179 in ['sscore']:
                local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, *local_value_1273 = local_value_1319.bwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0723, local_value_1699, local_value_0551.local_value_0696, local_value_0551.local_value_0431)
            elif local_value_0179 in ['sscorendstate']:
                local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, *local_value_1273 = local_value_1319.bwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0723, local_value_1699, local_value_0551.local_value_0696, 1)
                local_value_0564 = local_value_0564.unsqueeze(1)
                local_value_0582 = local_value_0582.unsqueeze(2)
                local_value_0585 = local_value_0585.unsqueeze(2)
            else:
                raise NotImplementedError
            local_value_0816 = local_value_1273[0] if local_value_0551.local_value_0922 else None
            local_value_0582 = local_value_0582.squeeze(1) if getattr(local_value_0551, 'member_slot_0442', False) else local_value_0582
            local_value_0585 = local_value_0585.squeeze(1) if getattr(local_value_0551, 'member_slot_0443', False) else local_value_0585
            local_value_0332 = None
            if D is not None:
                if local_value_0589.dtype != getattr(local_value_0551, 'member_slot_0109', local_value_0589.dtype):
                    local_value_0332 = local_value_0589.to(local_value_0551.member_slot_0109)
                else:
                    local_value_0332 = local_value_0589
            local_value_0335 = None
            if delta_bias is not None:
                if local_value_0671.dtype != getattr(local_value_0551, 'member_slot_0110', local_value_0671.dtype):
                    local_value_0335 = local_value_0671.to(local_value_0551.member_slot_0110)
                else:
                    local_value_0335 = local_value_0671
            return (local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589 if D is not None else None, local_value_0816, local_value_0671 if delta_bias is not None else None, None, None, None, None)

    def execute_step_1330(local_value_1660, delta, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, delta_bias=None, local_value_0696=False, return_last_state=False, local_value_1106=1, local_value_0431=-1):
        return ComponentUnit0232.apply(local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0696, return_last_state, local_value_1106, local_value_0431)
    execute_step_1330.__repr__ = lambda *local_value_0272: f'execute_step_1330 | {mode} | {local_value_1620}'
    return execute_step_1330

def execute_step_1331(local_value_1660, delta, local_value_0000, B, local_value_0044, D=None, local_value_1753=None, delta_bias=None, local_value_0696=False, return_last_state=False):
    local_value_0799 = local_value_1660.dtype
    local_value_1660 = local_value_1660.float()
    delta = delta.float()
    if delta_bias is not None:
        delta = delta + delta_bias[..., None].float()
    if local_value_0696:
        delta = local_value_0117.softplus(delta)
    local_value_0434, dim, local_value_0759 = (local_value_1660.shape[0], local_value_0000.shape[0], local_value_0000.shape[1])
    local_value_0993 = B.dim() >= 3
    local_value_0994 = local_value_0044.dim() >= 3
    if local_value_0000.is_complex():
        if local_value_0993:
            B = local_value_1650.view_as_complex(local_value_1249(B.float(), '... (L two) -> ... L two', two=2))
        if local_value_0994:
            local_value_0044 = local_value_1650.view_as_complex(local_value_1249(local_value_0044.float(), '... (L two) -> ... L two', two=2))
    else:
        B = B.float()
        local_value_0044 = local_value_0044.float()
    local_value_1699 = local_value_0000.new_zeros((local_value_0434, dim, local_value_0759))
    ys = []
    local_value_0690 = local_value_1650.exp(local_value_1650.einsum('bdl,dn->bdln', delta, local_value_0000))
    if not local_value_0993:
        local_value_0691 = local_value_1650.einsum('bdl,dn,bdl->bdln', delta, B, local_value_1660)
    elif B.dim() == 3:
        local_value_0691 = local_value_1650.einsum('bdl,bnl,bdl->bdln', delta, B, local_value_1660)
    else:
        B = repeat(B, 'B G N L -> B (G H) N L', H=dim // B.shape[1])
        local_value_0691 = local_value_1650.einsum('bdl,bdnl,bdl->bdln', delta, B, local_value_1660)
    if local_value_0994 and local_value_0044.dim() == 4:
        local_value_0044 = repeat(local_value_0044, 'B G N L -> B (G H) N L', H=dim // local_value_0044.shape[1])
    local_value_1013 = None
    for local_value_0939 in range(local_value_1660.shape[2]):
        local_value_1699 = local_value_0690[:, :, local_value_0939] * local_value_1699 + local_value_0691[:, :, local_value_0939]
        if not local_value_0994:
            y = local_value_1650.einsum('bdn,dn->bd', local_value_1699, local_value_0044)
        elif local_value_0044.dim() == 3:
            y = local_value_1650.einsum('bdn,bn->bd', local_value_1699, local_value_0044[:, :, local_value_0939])
        else:
            y = local_value_1650.einsum('bdn,bdn->bd', local_value_1699, local_value_0044[:, :, :, local_value_0939])
        if local_value_0939 == local_value_1660.shape[2] - 1:
            local_value_1013 = local_value_1699
        if y.is_complex():
            y = y.real * 2
        ys.append(y)
    y = local_value_1650.stack(ys, dim=2)
    out = y if D is None else y + local_value_1660 * local_value_1249(D, 'd -> d 1')
    if local_value_1753 is not None:
        out = out * local_value_0117.silu(local_value_1753)
    out = out.to(dtype=local_value_0799)
    return out if not return_last_state else (out, local_value_1013)

def execute_step_1325(us, dts, local_value_0009, Bs, Cs, Ds, delta_bias=None, local_value_0696=False, return_last_state=False, local_value_0519=3):

    def execute_step_1317(us, dts, local_value_0009, Bs, Cs, local_value_0933, local_value_0184):
        """
        us, dts: (L, B, G, D) # L is chunk_size
        As: (G, D, N)
        Bs, Cs: (L, B, G, N)
        Ds: (G, D)
        hprefix: (B, G, D, N)
        """
        local_value_0166 = us.shape[0]
        local_value_1659 = dts.cumsum(dim=0)
        local_value_0162 = local_value_1650.einsum('gdn,lbgd->lbgdn', -local_value_0009, local_value_1659)
        local_value_0161 = local_value_0162.exp()
        local_value_0011 = (-local_value_0162).exp()
        local_value_0205 = local_value_1650.einsum('lbgd,lbgn->lbgdn', dts * us, Bs)
        if local_value_0166 < local_value_0519:
            local_value_0206 = local_value_0184[:local_value_0166, :local_value_0166, None, None, None, None] * local_value_0205.unsqueeze(0).repeat(local_value_0166, 1, 1, 1, 1, 1)
        else:
            local_value_0206 = local_value_0184[:, :, None, None, None, None] * local_value_0205.unsqueeze(0).repeat(local_value_0166, 1, 1, 1, 1, 1)
        local_value_0150 = local_value_0011 * local_value_1650.einsum('rlbgdn,lbgdn->rbgdn', local_value_0206, local_value_0161)
        local_value_0934 = local_value_0150 + local_value_0011 * local_value_0933.unsqueeze(0)
        ys = local_value_1650.einsum('lbgn,lbgdn->lbgd', Cs, local_value_0934)
        return (ys, local_value_0934)
    dtype = local_value_1650.float32
    local_value_0976 = us.dtype
    local_value_0914 = Ds is not None
    if local_value_0519 < 1:
        local_value_0519 = Bs.shape[-1]
    local_value_0184 = local_value_1650.tril(us.new_ones((local_value_0519, local_value_0519)))
    dts = dts.to(dtype)
    if delta_bias is not None:
        dts = dts + delta_bias.view(1, -1, 1).to(dtype)
    if local_value_0696:
        dts = local_value_1650.nn.functional.softplus(dts)
    if len(Bs.shape) == 3:
        Bs = Bs.unsqueeze(1)
    if len(Cs.shape) == 3:
        Cs = Cs.unsqueeze(1)
    B, local_value_0122, N, L = Bs.shape
    us = us.view(B, local_value_0122, -1, L).permute(3, 0, 1, 2).to(dtype)
    dts = dts.view(B, local_value_0122, -1, L).permute(3, 0, 1, 2).to(dtype)
    local_value_0009 = local_value_0009.view(local_value_0122, -1, N).to(dtype)
    Bs = Bs.permute(3, 0, 1, 2).to(dtype)
    Cs = Cs.permute(3, 0, 1, 2).to(dtype)
    Ds = Ds.view(local_value_0122, -1).to(dtype) if local_value_0914 else None
    D = local_value_0009.shape[1]
    local_value_1181 = []
    local_value_0933 = us.new_zeros((B, local_value_0122, D, N), dtype=dtype)
    for local_value_0939 in range(0, L, local_value_0519):
        ys, local_value_0934 = execute_step_1317(us[local_value_0939:local_value_0939 + local_value_0519], dts[local_value_0939:local_value_0939 + local_value_0519], local_value_0009, Bs[local_value_0939:local_value_0939 + local_value_0519], Cs[local_value_0939:local_value_0939 + local_value_0519], local_value_0933, local_value_0184)
        local_value_1181.append(ys)
        local_value_0933 = local_value_0934[-1]
    local_value_1181 = local_value_1650.cat(local_value_1181, dim=0)
    if local_value_0914:
        local_value_1181 = local_value_1181 + Ds * us
    local_value_1181 = local_value_1181.permute(1, 2, 3, 0).view(B, -1, L)
    return local_value_1181.to(local_value_0976) if not return_last_state else (local_value_1181.to(local_value_0976), local_value_0933.view(B, local_value_0122 * D, N).float())

def execute_step_1323(us, dts, local_value_0009, Bs, Cs, Ds, delta_bias=None, local_value_0696=False, return_last_state=False, local_value_0519=64):

    def execute_step_1317(us, dts, local_value_0009, Bs, Cs, local_value_0933):
        """
        us, dts: (L, B, G, D) # L is chunk_size
        As: (G, D, N)
        Bs, Cs: (L, B, G, N)
        Ds: (G, D)
        hprefix: (B, G, D, N)
        """
        local_value_1659 = dts.cumsum(dim=0)
        local_value_0011 = local_value_1650.einsum('gdn,lbgd->lbgdn', local_value_0009, local_value_1659).exp()
        local_value_1302 = 1
        local_value_1244 = local_value_0011 / local_value_1302
        local_value_0802 = dts * us
        local_value_0765 = local_value_1650.einsum('lbgd,lbgn->lbgdn', local_value_0802, Bs)
        local_value_0936 = local_value_1244 * (local_value_0765 / local_value_1244).cumsum(dim=0)
        local_value_0934 = local_value_0936 + local_value_0011 * local_value_0933.unsqueeze(0)
        ys = local_value_1650.einsum('lbgn,lbgdn->lbgd', Cs, local_value_0934)
        return (ys, local_value_0934)
    dtype = local_value_1650.float32
    local_value_0976 = us.dtype
    local_value_0914 = Ds is not None
    if local_value_0519 < 1:
        local_value_0519 = Bs.shape[-1]
    dts = dts.to(dtype)
    if delta_bias is not None:
        dts = dts + delta_bias.view(1, -1, 1).to(dtype)
    if local_value_0696:
        dts = local_value_1650.nn.functional.softplus(dts)
    if len(Bs.shape) == 3:
        Bs = Bs.unsqueeze(1)
    if len(Cs.shape) == 3:
        Cs = Cs.unsqueeze(1)
    B, local_value_0122, N, L = Bs.shape
    us = us.view(B, local_value_0122, -1, L).permute(3, 0, 1, 2).to(dtype)
    dts = dts.view(B, local_value_0122, -1, L).permute(3, 0, 1, 2).to(dtype)
    local_value_0009 = local_value_0009.view(local_value_0122, -1, N).to(dtype)
    Bs = Bs.permute(3, 0, 1, 2).to(dtype)
    Cs = Cs.permute(3, 0, 1, 2).to(dtype)
    Ds = Ds.view(local_value_0122, -1).to(dtype) if local_value_0914 else None
    D = local_value_0009.shape[1]
    local_value_1181 = []
    local_value_0933 = us.new_zeros((B, local_value_0122, D, N), dtype=dtype)
    for local_value_0939 in range(0, L, local_value_0519):
        ys, local_value_0934 = execute_step_1317(us[local_value_0939:local_value_0939 + local_value_0519], dts[local_value_0939:local_value_0939 + local_value_0519], local_value_0009, Bs[local_value_0939:local_value_0939 + local_value_0519], Cs[local_value_0939:local_value_0939 + local_value_0519], local_value_0933)
        local_value_1181.append(ys)
        local_value_0933 = local_value_0934[-1]
    local_value_1181 = local_value_1650.cat(local_value_1181, dim=0)
    if local_value_0914:
        local_value_1181 = local_value_1181 + Ds * us
    local_value_1181 = local_value_1181.permute(1, 2, 3, 0).view(B, -1, L)
    return local_value_1181.to(local_value_0976) if not return_last_state else (local_value_1181.to(local_value_0976), local_value_0933.view(B, local_value_0122 * D, N).float())
from engine_unit_030 import execute_step_1328
execute_step_1323 = execute_step_1328
from ssmtriton import selective_scan_easyv3 as execute_step_1328
execute_step_1325 = execute_step_1328

def execute_step_1625():
    local_value_0179 = 'sscore'
    local_value_1698 = local_value_1650.float32
    local_value_0996 = local_value_1650.float32
    local_value_0996 = local_value_1650.float16
    local_value_0993 = True
    local_value_0994 = True
    local_value_0914 = True
    local_value_0922 = False
    local_value_0916 = True
    local_value_1676 = 2
    local_value_1348 = 4096
    local_value_0437 = 128
    dim = 24
    dim = 96
    local_value_0759 = 8
    local_value_0759 = 1
    local_value_0696 = True
    device = 'cuda'
    local_value_0240 = 100
    import selective_scan_cuda_core as local_value_1320
    import selective_scan_cuda as local_value_1319
    local_value_1650.random.manual_seed(0)
    local_value_0989 = local_value_1698 == local_value_1650.complex64
    local_value_0000 = (-0.5 * local_value_1650.rand(dim, local_value_0759, device=device, dtype=local_value_1698)).requires_grad_()
    if not local_value_0993:
        local_value_0036 = (dim, local_value_0759)
    elif local_value_1676 == 1:
        local_value_0036 = (local_value_0437, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    else:
        local_value_0036 = (local_value_0437, local_value_1676, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    B = local_value_1650.randn(*local_value_0036, device=device, dtype=local_value_1698 if not local_value_0993 else local_value_0996, requires_grad=True)
    if not local_value_0994:
        local_value_0059 = (dim, local_value_0759)
    elif local_value_1676 == 1:
        local_value_0059 = (local_value_0437, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    else:
        local_value_0059 = (local_value_0437, local_value_1676, local_value_0759, local_value_1348 if not local_value_0989 else local_value_1348 * 2)
    local_value_0044 = local_value_1650.randn(*local_value_0059, device=device, dtype=local_value_1698 if not local_value_0994 else local_value_0996, requires_grad=True)
    if local_value_0914:
        D = local_value_1650.randn(dim, device=device, dtype=local_value_1650.float32, requires_grad=True)
    else:
        D = None
    if local_value_0922:
        local_value_1753 = local_value_1650.randn(local_value_0437, dim, local_value_1348, device=device, dtype=local_value_0996, requires_grad=True)
    else:
        local_value_1753 = None
    if local_value_0916:
        delta_bias = (0.5 * local_value_1650.rand(dim, device=device, dtype=local_value_1650.float32)).requires_grad_()
    else:
        delta_bias = None
    local_value_1660 = local_value_1650.randn(local_value_0437, dim, local_value_1348, device=device, dtype=local_value_0996, requires_grad=True)
    delta = (0.5 * local_value_1650.rand(local_value_0437, dim, local_value_1348, device=device, dtype=local_value_0996)).requires_grad_()
    local_value_0007 = local_value_0000.detach().clone().requires_grad_()
    local_value_0035 = B.detach().clone().requires_grad_()
    local_value_0058 = local_value_0044.detach().clone().requires_grad_()
    local_value_0110 = D.detach().clone().requires_grad_() if D is not None else None
    local_value_1756 = local_value_1753.detach().clone().requires_grad_() if local_value_1753 is not None else None
    local_value_1662 = local_value_1660.detach().clone().requires_grad_()
    local_value_0695 = delta.detach().clone().requires_grad_()
    local_value_0694 = delta_bias.detach().clone().requires_grad_() if delta_bias is not None else None
    local_value_1390 = []
    local_value_0828 = []
    local_value_1626 = [local_value_1197(execute_step_0459(local_value_1319, mode='mamba_ssm', local_value_1620='ori'), local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0696, return_last_state=True), local_value_1197(execute_step_1323, local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, return_last_state=True), local_value_1197(execute_step_1325, local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, return_last_state=True), local_value_1197(execute_step_0459(local_value_1319, mode='mamba_ssm', local_value_1620='ori'), local_value_1660, delta, local_value_0000, B, local_value_0044, D, local_value_1753, delta_bias, local_value_0696, return_last_state=True)]
    for local_value_1622 in local_value_1626:
        s = local_value_1630.time()
        for local_value_0272 in range(local_value_0240):
            with local_value_1650.no_grad():
                local_value_1622()
        local_value_1650.cuda.synchronize()
        local_value_1650.cuda.empty_cache()
        e = local_value_1630.time()
        local_value_1390.append(s)
        local_value_0828.append(e)
        print('fwd', local_value_1622.func.__repr__(), e - s, flush=True)
    for local_value_1622 in local_value_1626:
        s = local_value_1630.time()
        for local_value_0272 in range(local_value_0240):
            local_value_1177 = local_value_1622()
            local_value_1177[0].sum().backward()
        local_value_1650.cuda.synchronize()
        local_value_1650.cuda.empty_cache()
        e = local_value_1630.time()
        local_value_1390.append(s)
        local_value_0828.append(e)
        print('fwdbwd', local_value_1622.func.__repr__(), e - s, flush=True)
execute_step_1625()
