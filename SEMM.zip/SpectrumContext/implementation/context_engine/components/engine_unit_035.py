import os as local_value_1136
import time as local_value_1630
import math as local_value_1039
import copy as local_value_0536
import torch as local_value_1650
import torch.nn as local_value_1094
import torch.nn.functional as local_value_0117
import triton as local_value_1655
from functools import partial as local_value_1197
from collections import OrderedDict as local_value_0200
from context_blocks import local_value_0075, local_value_0069, local_value_0080, local_value_0073, local_value_0081, local_value_0074, local_value_0879
from context_blocks import local_value_0077, local_value_0071, local_value_0078
from context_blocks import ComponentUnit0247, ComponentUnit0202, ComponentUnit0187, ComponentUnit0871, ComponentUnit0169, ContextMixingBlock

class ComponentUnit0050:

    def execute_step_0508():
        try:
            from optional_checks.context_blocks.prior_backend import local_value_0244
            from optional_checks.context_blocks.validation_backend import ComponentUnit0247
        except:
            print('original ComponentUnit0247 and ValidationPrototype not found.', flush=True)
            return
        local_value_1650.manual_seed(local_value_1630.time())
        local_value_1650.cuda.manual_seed(local_value_1630.time())
        local_value_1130 = local_value_0244(depths=[2, 2, 6, 2]).half().cuda()
        local_value_1084 = ComponentUnit0247(depths=[2, 2, 6, 2]).half().cuda()
        local_value_1084.load_state_dict(local_value_1130.state_dict())
        input = local_value_1650.randn((12, 3, 224, 224)).half().cuda()
        local_value_1650.cuda.manual_seed(0)
        with local_value_1650.cuda.amp.autocast():
            local_value_1737 = local_value_1130.execute_step_0857(input)
        local_value_1650.cuda.manual_seed(0)
        with local_value_1650.cuda.amp.autocast():
            local_value_1738 = local_value_1084.execute_step_0857(input)
        print((local_value_1737 - local_value_1738).abs().sum())
        local_value_1650.cuda.manual_seed(0)
        with local_value_1650.cuda.amp.autocast():
            local_value_1737 = local_value_1130.forward(input)
        local_value_1650.cuda.manual_seed(0)
        with local_value_1650.cuda.amp.autocast():
            local_value_1738 = local_value_1084.forward(input)
        print((local_value_1737 - local_value_1738).abs().sum())
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1130 = local_value_0244(depths=[2, 2, 6, 2]).cuda()
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1084 = ComponentUnit0247(depths=[2, 2, 6, 2]).cuda()
        local_value_1048 = 0
        for k, local_value_1672 in local_value_1130.state_dict().items():
            local_value_1298 = (local_value_1130.state_dict()[k] == local_value_1084.state_dict()[k]).all()
            if not local_value_1298:
                print(k, local_value_1298)
                local_value_1048 += 1
        print('init miss align', local_value_1048)

    def execute_step_0506(forward_type='v0'):
        try:
            from optional_checks.context_blocks.validation_backend import ComponentUnit0247 as local_value_0248
        except:
            print('original ComponentUnit0247 and ValidationPrototype not found.', flush=True)
            return

        class ComponentUnit0250(ComponentUnit0247):

            @staticmethod
            def execute_step_0364(*local_value_0416, **local_value_1007):
                local_value_1014 = ComponentUnit0247._make_layer(*local_value_0416, **local_value_1007)
                dim = local_value_1007.get('dim', None)
                norm_layer = local_value_1007.get('norm_layer', None)
                downsample = local_value_1007.get('downsample', None)
                blocks = local_value_1014.blocks
                if True:

                    def execute_step_0353(local_value_1058: local_value_1094.Module):
                        for name, p in local_value_1058.named_parameters():
                            if name in ['member_slot_0381.weight']:
                                p = p.clone().detach_()
                                local_value_1094.init.kaiming_uniform_(p, a=local_value_1039.sqrt(5))
                    local_value_0450 = local_value_1094.Sequential(*local_value_0536.deepcopy(blocks))
                    local_value_0450.apply(execute_step_0353)
                downsample = ComponentUnit0202(dim, 2 * dim, norm_layer=norm_layer) if downsample is None else local_value_1094.Identity()
                return local_value_1094.Sequential(local_value_0200(blocks=local_value_1094.Sequential(*blocks), downsample=downsample))

            def execute_step_0857(local_value_1336, local_value_1699):
                local_value_1699 = local_value_1336.member_slot_0386(local_value_1699)
                for l in local_value_1336.member_slot_0333:
                    local_value_1699 = l(local_value_1699)
                return local_value_1699

            def execute_step_0856(local_value_1336, local_value_1699: local_value_1650.Tensor):
                local_value_1699 = local_value_1336.member_slot_0386(local_value_1699)
                for local_value_1014 in local_value_1336.member_slot_0333:
                    local_value_1699 = local_value_1014(local_value_1699)
                local_value_1699 = local_value_1336.member_slot_0208.norm(local_value_1699)
                local_value_1699 = local_value_1336.member_slot_0208.avgpool(local_value_1699.permute(0, 3, 1, 2).contiguous()).flatten(1)
                local_value_1699 = local_value_1336.member_slot_0208.head(local_value_1699)
                return local_value_1699
        local_value_0249 = local_value_1197(ComponentUnit0247, local_value_0736='v1', local_value_1202='v1', local_value_1054=0.0, ssm_ratio=2.0, forward_type=forward_type)
        ComponentUnit0247.forward_backbone = ComponentUnit0250.execute_step_0857
        ComponentUnit0247.forward1 = ComponentUnit0250.execute_step_0856
        local_value_0249 = local_value_1197(ComponentUnit0250, local_value_0736='none', local_value_1202='v1', local_value_1054=0.0, ssm_ratio=2.0, forward_type=forward_type)
        local_value_1650.manual_seed(local_value_1630.time())
        local_value_1650.cuda.manual_seed(local_value_1630.time())
        local_value_1130 = local_value_0248(depths=[2, 2, 6, 2]).half().cuda()
        local_value_1084 = local_value_0249(depths=[2, 2, 6, 2]).half().cuda()
        local_value_1084.load_state_dict(local_value_1130.state_dict())
        input = local_value_1650.randn((12, 3, 224, 224)).half().cuda()
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        with local_value_1650.cuda.amp.autocast():
            local_value_1737 = local_value_1130.execute_step_0857(input)
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        with local_value_1650.cuda.amp.autocast():
            local_value_1738 = local_value_1084.execute_step_0857(input)
        print((local_value_1737 - local_value_1738).abs().sum())
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        with local_value_1650.cuda.amp.autocast():
            local_value_1737 = local_value_1130.forward(input)
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        with local_value_1650.cuda.amp.autocast():
            local_value_1738 = local_value_1084.execute_step_0856(input)
        print((local_value_1737 - local_value_1738).abs().sum())
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        with local_value_1650.cuda.amp.autocast():
            local_value_1739 = local_value_1084.forward(input)
        print((local_value_1737 - local_value_1739).abs().sum())
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1130 = local_value_0248(depths=[2, 2, 6, 2]).cuda()
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1084 = local_value_0249(depths=[2, 2, 6, 2]).cuda()
        local_value_1048 = 0
        local_value_1131 = local_value_0536.deepcopy(local_value_1084)
        local_value_1131.load_state_dict(local_value_1130.state_dict())
        for k, local_value_1672 in local_value_1131.state_dict().items():
            local_value_1298 = (local_value_1131.state_dict()[k] == local_value_1084.state_dict()[k]).all()
            if not local_value_1298:
                print(k, local_value_1298)
                local_value_1048 += 1
        print('init miss align', local_value_1048)

    def execute_step_0507():
        local_value_0248 = local_value_1197(ComponentUnit0247, local_value_0736='v3', local_value_1202='v2', local_value_1054=4.0, ssm_ratio=2.0, forward_type='v2')
        local_value_0249 = local_value_1197(ComponentUnit0247, local_value_0736='v3', local_value_1202='v2', local_value_1054=4.0, ssm_ratio=2.0, forward_type='v01')
        local_value_1650.manual_seed(local_value_1630.time())
        local_value_1650.cuda.manual_seed(local_value_1630.time())
        local_value_1130 = local_value_0248(depths=[2, 2, 6, 2]).half().cuda()
        local_value_1084 = local_value_0249(depths=[2, 2, 6, 2]).half().cuda()
        local_value_1084.load_state_dict(local_value_1130.state_dict())
        local_value_0978 = local_value_1650.randn((12, 3, 224, 224)).half().cuda().requires_grad_()
        local_value_0979 = local_value_0978.detach().clone().requires_grad_()
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        with local_value_1650.cuda.amp.autocast():
            local_value_1737 = local_value_1130.forward(local_value_0978)
            local_value_1737.sum().backward()
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        with local_value_1650.cuda.amp.autocast():
            local_value_1738 = local_value_1084.forward(local_value_0979)
            local_value_1738.sum().backward()
        print((local_value_1737 - local_value_1738).abs().sum())
        print((local_value_0978.grad - local_value_0979.grad).abs().sum())
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1130 = local_value_0248(depths=[2, 2, 6, 2]).cuda()
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1084 = local_value_0249(depths=[2, 2, 6, 2]).cuda()
        local_value_1048 = 0
        local_value_1131 = local_value_0536.deepcopy(local_value_1084)
        local_value_1131.load_state_dict(local_value_1130.state_dict())
        for k, local_value_1672 in local_value_1131.state_dict().items():
            local_value_1298 = (local_value_1131.state_dict()[k] == local_value_1084.state_dict()[k]).all()
            if not local_value_1298:
                print(k, local_value_1298)
                local_value_1048 += 1
        print('init miss align', local_value_1048)

    def execute_step_0498():
        B, local_value_0044, H, W = (256, 192, 56, 57)
        dtype = local_value_1650.float16
        dtype = local_value_1650.float32
        local_value_1699 = local_value_1650.randn((B, local_value_0044, H, W), dtype=dtype, device=local_value_1650.device('cuda')).requires_grad_(True)
        y = local_value_1650.randn((B, 4, local_value_0044, H, W), dtype=dtype, device=local_value_1650.device('cuda')).requires_grad_(True)
        local_value_1701 = local_value_1699.clone().detach().requires_grad_(True)
        local_value_1737 = y.clone().detach().requires_grad_(True)

        def execute_step_0543(local_value_1699: local_value_1650.Tensor):
            B, local_value_0044, H, W = local_value_1699.shape
            L = H * W
            local_value_1733 = local_value_1650.stack([local_value_1699.view(B, local_value_0044, L), local_value_1650.transpose(local_value_1699, dim0=2, dim1=3).contiguous().view(B, local_value_0044, L), local_value_1650.flip(local_value_1699.contiguous().view(B, local_value_0044, L), dims=[-1]), local_value_1650.flip(local_value_1650.transpose(local_value_1699, dim0=2, dim1=3).contiguous().view(B, local_value_0044, L), dims=[-1])], dim=1).view(B, 4, local_value_0044, L)
            return local_value_1733

        def execute_step_0539(local_value_1169: local_value_1650.Tensor):
            B, local_value_0156, D, H, W = local_value_1169.shape
            L = H * W
            local_value_1169 = local_value_1169.view(B, local_value_0156, D, L)
            local_value_0987 = local_value_1650.flip(local_value_1169[:, 2:4], dims=[-1]).view(B, 2, -1, L)
            local_value_1690 = local_value_1650.transpose(local_value_1169[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)
            local_value_0988 = local_value_1650.transpose(local_value_0987[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)
            y = local_value_1169[:, 0] + local_value_0987[:, 0] + local_value_1690 + local_value_0988
            return y

        def execute_step_0545(local_value_1699: local_value_1650.Tensor):
            B, local_value_0156, local_value_0044, H, W = local_value_1699.shape
            L = H * W
            local_value_1733 = local_value_1650.stack([local_value_1699[:, 0].view(B, local_value_0044, L), local_value_1650.transpose(local_value_1699[:, 1], dim0=2, dim1=3).contiguous().view(B, local_value_0044, L), local_value_1650.flip(local_value_1699[:, 2].contiguous().view(B, local_value_0044, L), dims=[-1]), local_value_1650.flip(local_value_1650.transpose(local_value_1699[:, 3], dim0=2, dim1=3).contiguous().view(B, local_value_0044, L), dims=[-1])], dim=1).view(B, 4, local_value_0044, L)
            return local_value_1733

        def execute_step_1665(local_value_1699):
            B, local_value_0044, H, W = local_value_1699.shape
            local_value_1699 = local_value_1699.view(B, 1, local_value_0044, H * W).repeat(1, 4, 1, 1)
            return local_value_1699

        def execute_step_1664(ys):
            B, local_value_0156, local_value_0044, H, W = ys.shape
            return ys.view(B, 4, -1, H * W).sum(1)

        def execute_step_0444(local_value_1699):
            B, local_value_0044, H, W = local_value_1699.shape
            local_value_1699 = local_value_1699.view(B, 1, local_value_0044, H * W).repeat(1, 2, 1, 1)
            local_value_1699 = local_value_1650.cat([local_value_1699, local_value_1699.flip(dims=[-1])], dim=1)
            return local_value_1699

        def execute_step_0443(ys):
            B, local_value_0156, D, H, W = ys.shape
            ys = ys.view(B, local_value_0156, D, -1)
            ys = ys[:, 0:2] + ys[:, 2:4].flip(dims=[-1]).view(B, 2, D, -1)
            return ys.contiguous().sum(1)
        if True:
            local_value_1259 = local_value_1655.testing.do_bench(lambda: execute_step_0543(local_value_1699))
            local_value_1260 = local_value_1655.testing.do_bench(lambda: local_value_0075.apply(local_value_1699))
            local_value_1261 = local_value_1655.testing.do_bench(lambda: local_value_0077.apply(local_value_1699))
            local_value_1262 = local_value_1655.testing.do_bench(lambda: execute_step_0539(y))
            local_value_1263 = local_value_1655.testing.do_bench(lambda: local_value_0069.apply(y))
            local_value_1264 = local_value_1655.testing.do_bench(lambda: local_value_0071.apply(y))
            print(local_value_1259, local_value_1260, local_value_1261, local_value_1262, local_value_1263, local_value_1264)
            local_value_1259 = local_value_1655.testing.do_bench(lambda: execute_step_0543(local_value_1699).sum().backward())
            local_value_1260 = local_value_1655.testing.do_bench(lambda: local_value_0075.apply(local_value_1699).sum().backward())
            local_value_1261 = local_value_1655.testing.do_bench(lambda: local_value_0077.apply(local_value_1699).sum().backward())
            local_value_1262 = local_value_1655.testing.do_bench(lambda: execute_step_0539(y).sum().backward())
            local_value_1263 = local_value_1655.testing.do_bench(lambda: local_value_0069.apply(y).sum().backward())
            local_value_1264 = local_value_1655.testing.do_bench(lambda: local_value_0071.apply(y).sum().backward())
            print(local_value_1259, local_value_1260, local_value_1261, local_value_1262, local_value_1263, local_value_1264)
        print('test cross scan')
        for local_value_0549, local_value_0525, local_value_0550, local_value_0526 in [(execute_step_0543, execute_step_0539, local_value_0077, local_value_0071), (execute_step_1665, execute_step_1664, local_value_0879(1)[0], local_value_0879(1)[1]), (execute_step_0444, execute_step_0443, local_value_0879(2)[0], local_value_0879(2)[1])]:
            local_value_1699.grad, local_value_1701.grad, y.grad, local_value_1737.grad = (None, None, None, None)
            local_value_1114 = local_value_0549(local_value_1699)
            local_value_1115 = local_value_0550.apply(local_value_1701)
            local_value_1114.backward(y.view(B, 4, local_value_0044, H * W))
            local_value_1115.backward(y.view(B, 4, local_value_0044, H * W))
            print((local_value_1114 - local_value_1115).abs().max())
            print((local_value_1699.grad - local_value_1701.grad).abs().max())
            local_value_1114 = local_value_0525(y)
            local_value_1115 = local_value_0526.apply(local_value_1737)
            local_value_1114.backward(local_value_1699.view(B, local_value_0044, H * W))
            local_value_1115.backward(local_value_1699.view(B, local_value_0044, H * W))
            print((local_value_1114 - local_value_1115).abs().max())
            print((y.grad - local_value_1737.grad).abs().max())
            local_value_1699.grad, local_value_1701.grad, y.grad, local_value_1737.grad = (None, None, None, None)
        print('test cross scan one by one')
        if True:
            local_value_1114 = execute_step_0545(y)
            local_value_1115 = local_value_0078.apply(local_value_1737)
            local_value_1114.backward(y.view(B, 4, local_value_0044, H * W))
            local_value_1115.backward(y.view(B, 4, local_value_0044, H * W))
            print((local_value_1114 - local_value_1115).abs().max())
            print((y.grad - local_value_1737.grad).abs().max())
            local_value_1699.grad, local_value_1701.grad, y.grad, local_value_1737.grad = (None, None, None, None)
        local_value_1699 = local_value_1650.arange(0, 16, 1).view(1, 1, 4, 4)
        print(local_value_1699)
        print(execute_step_0543(local_value_1699))
        print(execute_step_0539(execute_step_0543(local_value_1699).view(1, 4, 1, 4, 4)))
        local_value_1699 = local_value_1650.arange(0, 16, 1).view(1, 4, 1, 2, 2)
        print(local_value_1699)
        print(execute_step_0545(local_value_1699))

    def execute_step_0499():
        B, D, L, local_value_0207, local_value_0156 = (128, 192, 56 * 56, 12, 4)
        local_value_1113 = local_value_1650.randn((B, local_value_0156 * D, L)).cuda()
        local_value_1699 = local_value_1650.randn((B, local_value_0156, local_value_0207, L)).cuda().requires_grad_(True)
        local_value_1683 = local_value_1650.randn((local_value_0156, D, local_value_0207)).cuda().requires_grad_(True)
        local_value_1701 = local_value_1699.clone().detach().requires_grad_(True)
        local_value_1684 = local_value_1683.clone().detach().requires_grad_(True)
        local_value_1737 = local_value_1650.einsum('bkrl,kdr->bkdl', local_value_1699, local_value_1683).contiguous().view(B, -1, L)
        local_value_1738 = local_value_0117.conv1d(local_value_1701.view(B, -1, L), local_value_1684.view(local_value_0156 * D, local_value_0207, 1), None, groups=local_value_0156).contiguous().view(B, -1, L)
        print((local_value_1737 - local_value_1738).abs().max())
        local_value_1737.backward(local_value_1113)
        local_value_1738.backward(local_value_1113)
        print((local_value_1699.grad - local_value_1701.grad).abs().max())

    def execute_step_0505():
        import triton as local_value_1655
        from torchvision.models.vision_transformer import EncoderBlock as local_value_0116
        local_value_1677 = ContextMixingBlock(hidden_dim=16, local_value_0752=0.0, norm_layer=local_value_1094.LayerNorm, local_value_1380=1, ssm_ratio=2, local_value_1382='auto', local_value_1377=local_value_1094.SiLU, local_value_1378=3, local_value_1379=False, local_value_1381=0.0, local_value_1383='v0', forward_type='v2', local_value_1054=4, local_value_1051=local_value_1094.GELU, local_value_1052=0.0, local_value_1670=False).cuda()
        local_value_1654 = local_value_0116(num_heads=1, hidden_dim=16, mlp_dim=int(4.0 * 16), dropout=0.0, attention_dropout=0.0, norm_layer=local_value_1094.LayerNorm).cuda()
        local_value_0974 = local_value_1650.randn((16, 128, 128, 16)).cuda().requires_grad_()
        local_value_0975 = local_value_0974.detach().cuda().view(16, -1, 16).requires_grad_()
        local_value_0849 = lambda: local_value_1677(local_value_0974)
        local_value_1060 = local_value_1655.testing.do_bench(local_value_0849, warmup=100)
        print(local_value_1060)
        local_value_0849 = lambda: local_value_1654(local_value_0975)
        local_value_1060 = local_value_1655.testing.do_bench(local_value_0849, warmup=100)
        print(local_value_1060)
        local_value_0849 = lambda: local_value_1677(local_value_0974).sum().backward()
        local_value_1060 = local_value_1655.testing.do_bench(local_value_0849, warmup=100)
        print(local_value_1060)
        local_value_0849 = lambda: local_value_1654(local_value_0975).sum().backward()
        local_value_1060 = local_value_1655.testing.do_bench(local_value_0849, warmup=100)
        print(local_value_1060)
        import time as local_value_1630
        local_value_1630.sleep(10000)

    def execute_step_0502():
        import triton as local_value_1655
        B, local_value_0044, H, W = (128, 8192, 7, 7)
        local_value_0974 = local_value_1650.randn((B, local_value_0044, H, W)).cuda().requires_grad_()
        local_value_0975 = local_value_0974.detach().permute(0, 2, 3, 1).clone().requires_grad_()
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1067 = ComponentUnit0169(local_value_0044).cuda()
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1068 = local_value_1094.LayerNorm(local_value_0044).cuda()
        local_value_1115 = local_value_1067(local_value_0974)
        local_value_1116 = local_value_1068(local_value_0975)
        print((local_value_1115.permute(0, 2, 3, 1) - local_value_1116).abs().max())
        local_value_1115.backward(local_value_0974.data)
        local_value_1116.backward(local_value_0974.data.permute(0, 2, 3, 1))
        print((local_value_0974.grad.permute(0, 2, 3, 1) - local_value_0975.grad).abs().max())
        local_value_1061 = local_value_1655.testing.do_bench(lambda: local_value_1067(local_value_0974))
        local_value_1062 = local_value_1655.testing.do_bench(lambda: local_value_1068(local_value_0975))
        local_value_1063 = local_value_1655.testing.do_bench(lambda: local_value_1067(local_value_0974))
        print(local_value_1061, local_value_1062, local_value_1063)

    def execute_step_0501():
        import triton as local_value_1655
        local_value_0974 = local_value_1650.randn((64, 192, 56, 57)).cuda().requires_grad_()
        local_value_0975 = local_value_0974.detach().permute(0, 2, 3, 1).clone().requires_grad_()
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1067 = ComponentUnit0187(192, 4 * 192, 384, channels_first=True).cuda()
        local_value_0477 = local_value_1650.randn((1,))
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1068 = ComponentUnit0187(192, 4 * 192, 384, channels_first=False).cuda()
        local_value_0478 = local_value_1650.randn((1,))
        print(local_value_0477, local_value_0478)
        with local_value_1650.cuda.amp.autocast():
            local_value_1115 = local_value_1067(local_value_0974)
            local_value_1116 = local_value_1068(local_value_0975)
        print((local_value_1115.permute(0, 2, 3, 1) - local_value_1116).abs().max())
        local_value_1115.sum().backward()
        local_value_1116.sum().backward()
        print((local_value_0974.grad.permute(0, 2, 3, 1) - local_value_0975.grad).abs().max())
        local_value_0940, local_value_0941 = (local_value_0974.float(), local_value_0975.float())
        local_value_1062 = local_value_1655.testing.do_bench(lambda: local_value_1068(local_value_0941))
        local_value_1061 = local_value_1655.testing.do_bench(lambda: local_value_1067(local_value_0940))
        local_value_1064 = local_value_1655.testing.do_bench(lambda: local_value_1068(local_value_0941).sum().backward())
        local_value_1063 = local_value_1655.testing.do_bench(lambda: local_value_1067(local_value_0940).sum().backward())
        print(local_value_1061, local_value_1062, local_value_1063, local_value_1064)

    def execute_step_0500():
        import triton as local_value_1655
        local_value_0974 = local_value_1650.randn((64, 192, 56, 57)).cuda().requires_grad_()
        local_value_0975 = local_value_0974.detach().permute(0, 2, 3, 1).clone().requires_grad_()
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1067 = ComponentUnit0187(192, 4 * 192, 384, channels_first=True).cuda()
        local_value_0477 = local_value_1650.randn((1,))
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1068 = ComponentUnit0871(192, 2 * 192, 384, channels_first=False).cuda()
        local_value_0478 = local_value_1650.randn((1,))
        print(local_value_0477, local_value_0478)
        with local_value_1650.cuda.amp.autocast():
            local_value_1115 = local_value_1067(local_value_0974)
            local_value_1116 = local_value_1068(local_value_0975)
        print((local_value_1115.permute(0, 2, 3, 1) - local_value_1116).abs().max())
        local_value_1115.sum().backward()
        local_value_1116.sum().backward()
        print((local_value_0974.grad.permute(0, 2, 3, 1) - local_value_0975.grad).abs().max())
        local_value_0940, local_value_0941 = (local_value_0974.float(), local_value_0975.float())
        local_value_1062 = local_value_1655.testing.do_bench(lambda: local_value_1068(local_value_0941))
        local_value_1061 = local_value_1655.testing.do_bench(lambda: local_value_1067(local_value_0940))
        local_value_1064 = local_value_1655.testing.do_bench(lambda: local_value_1068(local_value_0941).sum().backward())
        local_value_1063 = local_value_1655.testing.do_bench(lambda: local_value_1067(local_value_0940).sum().backward())
        print(local_value_1061, local_value_1062, local_value_1063, local_value_1064)

    def execute_step_0496():
        import triton as local_value_1655
        local_value_0974 = local_value_1650.randn((64, 3, 224, 224)).cuda().half().requires_grad_()
        local_value_0975 = local_value_0974.detach().clone().requires_grad_()
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1067 = ComponentUnit0247(norm_layer='ln').cuda()
        local_value_0477 = local_value_1650.randn((1,))
        local_value_1650.manual_seed(0)
        local_value_1650.cuda.manual_seed(0)
        local_value_1068 = ComponentUnit0247(norm_layer='ln2d').cuda()
        local_value_0478 = local_value_1650.randn((1,))
        print(local_value_0477, local_value_0478)
        with local_value_1650.cuda.amp.autocast():
            local_value_1115 = local_value_1067(local_value_0974)
            local_value_1116 = local_value_1068(local_value_0975)
        print((local_value_1115 - local_value_1116).abs().max())
        local_value_1115.sum().backward()
        local_value_1116.sum().backward()
        print((local_value_0974.grad - local_value_0975.grad).abs().max())
        local_value_0940, local_value_0941 = (local_value_0974.float(), local_value_0975.float())
        local_value_1062 = local_value_1655.testing.do_bench(lambda: local_value_1068(local_value_0941))
        local_value_1061 = local_value_1655.testing.do_bench(lambda: local_value_1067(local_value_0940))
        local_value_1064 = local_value_1655.testing.do_bench(lambda: local_value_1068(local_value_0941).sum().backward())
        local_value_1063 = local_value_1655.testing.do_bench(lambda: local_value_1067(local_value_0940).sum().backward())
        print(local_value_1061, local_value_1062, local_value_1063, local_value_1064)

    def execute_step_0504():
        local_value_1682 = ComponentUnit0247(depths=[1], dims=1024).half().cuda()
        input = local_value_1650.randn((128, 3, 56, 56)).half().cuda()
        local_value_1650.cuda.manual_seed(0)

        def execute_step_1652(local_value_1230: local_value_1650.profiler.profile):
            print(local_value_1230.key_averages().table(sort_by='self_cuda_time_total', row_limit=-1))
        with local_value_1650.cuda.amp.autocast():
            with local_value_1650.profiler.profile(with_modules=True, with_stack=True, profile_memory=True, activities=[local_value_1650.profiler.ProfilerActivity.CPU, local_value_1650.profiler.ProfilerActivity.CUDA], schedule=local_value_1650.profiler.schedule(wait=1, warmup=1, active=2, repeat=1), on_trace_ready=execute_step_1652) as local_value_1230:
                for iter in range(1000):
                    local_value_1699 = input
                    local_value_1230.step()

    def execute_step_1023():
        if False:
            local_value_1255 = [k for k in state_dict.keys() if 'relative_position_index' in k]
            for k in local_value_1255:
                del state_dict[k]
            local_value_1255 = [k for k in state_dict.keys() if 'relative_coords_table' in k]
            for k in local_value_1255:
                del state_dict[k]
            local_value_0423 = [k for k in state_dict.keys() if 'attn_mask' in k]
            for k in local_value_0423:
                del state_dict[k]
            local_value_1252 = [k for k in state_dict.keys() if 'relative_position_bias_table' in k]
            for k in local_value_1252:
                local_value_1253 = state_dict[k]
                local_value_1251 = model.state_dict()[k]
                local_value_0164, local_value_1069 = local_value_1253.size()
                local_value_0165, local_value_1070 = local_value_1251.size()
                if local_value_1069 != local_value_1070:
                    logger.warning(f'Error in loading {k}, passing......')
                elif local_value_0164 != local_value_0165:
                    local_value_0215 = int(local_value_0164 ** 0.5)
                    local_value_0216 = int(local_value_0165 ** 0.5)
                    local_value_1254 = local_value_1650.nn.functional.interpolate(local_value_1253.permute(1, 0).view(1, local_value_1069, local_value_0215, local_value_0215), size=(local_value_0216, local_value_0216), mode='bicubic')
                    state_dict[k] = local_value_1254.view(local_value_1070, local_value_0165).permute(1, 0)
            local_value_0406 = [k for k in state_dict.keys() if 'absolute_pos_embed' in k]
            for k in local_value_0406:
                local_value_0407 = state_dict[k]
                local_value_0405 = model.state_dict()[k]
                local_value_0272, local_value_0164, local_value_0045 = local_value_0407.size()
                local_value_0272, local_value_0165, local_value_0046 = local_value_0405.size()
                if local_value_0045 != local_value_0045:
                    logger.warning(f'Error in loading {k}, passing......')
                elif local_value_0164 != local_value_0165:
                    local_value_0215 = int(local_value_0164 ** 0.5)
                    local_value_0216 = int(local_value_0165 ** 0.5)
                    local_value_0407 = local_value_0407.reshape(-1, local_value_0215, local_value_0215, local_value_0045)
                    local_value_0407 = local_value_0407.permute(0, 3, 1, 2)
                    local_value_0408 = local_value_1650.nn.functional.interpolate(local_value_0407, size=(local_value_0216, local_value_0216), mode='bicubic')
                    local_value_0408 = local_value_0408.permute(0, 2, 3, 1)
                    local_value_0408 = local_value_0408.flatten(1, 2)
                    state_dict[k] = local_value_0408
            local_value_0924 = state_dict['head.bias']
            local_value_0196 = local_value_0924.shape[0]
            local_value_0197 = model.head.bias.shape[0]
            if local_value_0196 != local_value_0197:
                if local_value_0196 == 21841 and local_value_0197 == 1000:
                    logger.info('loading ImageNet-22K weight to ImageNet-1K ......')
                    local_value_1037 = f'data/map22kto1k.txt'
                    with open(local_value_1037) as local_value_0834:
                        local_value_1036 = local_value_0834.readlines()
                    local_value_1036 = [int(local_value_0948.strip()) for local_value_0948 in local_value_1036]
                    state_dict['head.weight'] = state_dict['head.weight'][local_value_1036, :]
                    state_dict['head.bias'] = state_dict['head.bias'][local_value_1036]
                else:
                    local_value_1650.nn.init.constant_(model.head.bias, 0.0)
                    local_value_1650.nn.init.constant_(model.head.weight, 0.0)
                    del state_dict['head.weight']
                    del state_dict['head.bias']
                    logger.warning(f'Error in loading classifier head, re-init classifier head to 0')
if __name__ == '__main__':
    ComponentUnit0050.execute_step_0498()
