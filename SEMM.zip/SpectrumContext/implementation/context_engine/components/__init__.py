import os as local_value_1136
from functools import partial as local_value_1197
import torch as local_value_1650
from .context_blocks import ComponentUnit0247

def execute_step_0460(local_value_0531, **local_value_1007):
    local_value_1057 = local_value_0531.MODEL.TYPE
    if local_value_1057 in ['vssm']:
        model = ComponentUnit0247(local_value_1200=local_value_0531.MODEL.ComponentUnit0247.PATCH_SIZE, local_value_0958=local_value_0531.MODEL.ComponentUnit0247.IN_CHANS, local_value_1109=local_value_0531.MODEL.NUM_CLASSES, depths=local_value_0531.MODEL.ComponentUnit0247.DEPTHS, dims=local_value_0531.MODEL.ComponentUnit0247.EMBED_DIM, local_value_1380=local_value_0531.MODEL.ComponentUnit0247.SSM_D_STATE, ssm_ratio=local_value_0531.MODEL.ComponentUnit0247.SSM_RATIO, ssm_rank_ratio=local_value_0531.MODEL.ComponentUnit0247.SSM_RANK_RATIO, local_value_1382='auto' if local_value_0531.MODEL.ComponentUnit0247.SSM_DT_RANK == 'auto' else int(local_value_0531.MODEL.ComponentUnit0247.SSM_DT_RANK), local_value_1377=local_value_0531.MODEL.ComponentUnit0247.SSM_ACT_LAYER, local_value_1378=local_value_0531.MODEL.ComponentUnit0247.SSM_CONV, local_value_1379=local_value_0531.MODEL.ComponentUnit0247.SSM_CONV_BIAS, local_value_1381=local_value_0531.MODEL.ComponentUnit0247.SSM_DROP_RATE, local_value_1383=local_value_0531.MODEL.ComponentUnit0247.SSM_INIT, forward_type=local_value_0531.MODEL.ComponentUnit0247.SSM_FORWARDTYPE, local_value_1054=local_value_0531.MODEL.ComponentUnit0247.MLP_RATIO, local_value_1051=local_value_0531.MODEL.ComponentUnit0247.MLP_ACT_LAYER, local_value_1052=local_value_0531.MODEL.ComponentUnit0247.MLP_DROP_RATE, local_value_0753=local_value_0531.MODEL.DROP_PATH_RATE, local_value_1199=local_value_0531.MODEL.ComponentUnit0247.PATCH_NORM, norm_layer=local_value_0531.MODEL.ComponentUnit0247.NORM_LAYER, local_value_0736=local_value_0531.MODEL.ComponentUnit0247.DOWNSAMPLE, local_value_1202=local_value_0531.MODEL.ComponentUnit0247.PATCHEMBED, local_value_0895=local_value_0531.MODEL.ComponentUnit0247.GMLP, local_value_1670=local_value_0531.TRAIN.USE_CHECKPOINT, local_value_1218=local_value_0531.MODEL.ComponentUnit0247.POSEMBED, local_value_0955=local_value_0531.DATA.IMG_SIZE)
        return model
    return None

def execute_step_0458(local_value_0531, local_value_0991=False):
    model = None
    if model is None:
        model = execute_step_0460(local_value_0531)
    if model is None:
        from .optional_backend import local_value_1353
        model = local_value_1353(local_value_0531.MODEL.TYPE)
    return model
