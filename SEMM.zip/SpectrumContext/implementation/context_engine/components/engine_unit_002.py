import torch as local_value_1650
import warnings as local_value_1686
local_value_0258 = True
try:
    import triton as local_value_1655
    import triton.language as local_value_1631
except:
    local_value_0258 = False
    local_value_1686.warn('Triton not installed, fall back to pytorch implements.')
if local_value_0258:
    try:
        from functools import cached_property as local_value_0470
    except:
        local_value_1686.warn('if you are using py37, add this line to functools.py: cached_property = lambda func: property(lru_cache()(func))')

def execute_step_0547(local_value_1699: local_value_1650.Tensor, in_channel_first=True, out_channel_first=True, local_value_1308=0):
    if in_channel_first:
        B, local_value_0044, H, W = local_value_1699.shape
        if local_value_1308 == 0:
            y = local_value_1699.new_empty((B, 4, local_value_0044, H * W))
            y[:, 0, :, :] = local_value_1699.flatten(2, 3)
            y[:, 1, :, :] = local_value_1699.transpose(dim0=2, dim1=3).flatten(2, 3)
            y[:, 2:4, :, :] = local_value_1650.flip(y[:, 0:2, :, :], dims=[-1])
        elif local_value_1308 == 1:
            y = local_value_1699.view(B, 1, local_value_0044, H * W).repeat(1, 4, 1, 1)
        elif local_value_1308 == 2:
            y = local_value_1699.view(B, 1, local_value_0044, H * W).repeat(1, 2, 1, 1)
            y = local_value_1650.cat([y, y.flip(dims=[-1])], dim=1)
    else:
        B, H, W, local_value_0044 = local_value_1699.shape
        if local_value_1308 == 0:
            y = local_value_1699.new_empty((B, H * W, 4, local_value_0044))
            y[:, :, 0, :] = local_value_1699.flatten(1, 2)
            y[:, :, 1, :] = local_value_1699.transpose(dim0=1, dim1=2).flatten(1, 2)
            y[:, :, 2:4, :] = local_value_1650.flip(y[:, :, 0:2, :], dims=[1])
        elif local_value_1308 == 1:
            y = local_value_1699.view(B, H * W, 1, local_value_0044).repeat(1, 1, 4, 1)
        elif local_value_1308 == 2:
            y = local_value_1699.view(B, H * W, 1, local_value_0044).repeat(1, 1, 2, 1)
            y = local_value_1650.cat([y, y.flip(dims=[1])], dim=2)
    if in_channel_first and (not out_channel_first):
        y = y.permute(0, 3, 1, 2).contiguous()
    elif not in_channel_first and out_channel_first:
        y = y.permute(0, 2, 3, 1).contiguous()
    return y

def execute_step_0542(y: local_value_1650.Tensor, in_channel_first=True, out_channel_first=True, local_value_1308=0):
    if out_channel_first:
        B, local_value_0156, D, H, W = y.shape
        y = y.view(B, local_value_0156, D, -1)
        if local_value_1308 == 0:
            y = y[:, 0:2] + y[:, 2:4].flip(dims=[-1]).view(B, 2, D, -1)
            y = y[:, 0] + y[:, 1].view(B, -1, W, H).transpose(dim0=2, dim1=3).contiguous().view(B, D, -1)
        elif local_value_1308 == 1:
            y = y.sum(1)
        elif local_value_1308 == 2:
            y = y[:, 0:2] + y[:, 2:4].flip(dims=[-1]).view(B, 2, D, -1)
            y = y.sum(1)
    else:
        B, H, W, local_value_0156, D = y.shape
        y = y.view(B, -1, local_value_0156, D)
        if local_value_1308 == 0:
            y = y[:, :, 0:2] + y[:, :, 2:4].flip(dims=[1]).view(B, -1, 2, D)
            y = y[:, :, 0] + y[:, :, 1].view(B, W, H, -1).transpose(dim0=1, dim1=2).contiguous().view(B, -1, D)
        elif local_value_1308 == 1:
            y = y.sum(2)
        elif local_value_1308 == 2:
            y = y[:, :, 0:2] + y[:, :, 2:4].flip(dims=[1]).view(B, -1, 2, D)
            y = y.sum(2)
    if in_channel_first and (not out_channel_first):
        y = y.permute(0, 2, 1).contiguous()
    elif not in_channel_first and out_channel_first:
        y = y.permute(0, 2, 1).contiguous()
    return y

def execute_step_0544(local_value_1699: local_value_1650.Tensor, in_channel_first=True, out_channel_first=True, local_value_1308=0):
    if in_channel_first:
        B, local_value_0272, local_value_0044, H, W = local_value_1699.shape
        if local_value_1308 == 0:
            y = local_value_1650.stack([local_value_1699[:, 0].flatten(2, 3), local_value_1699[:, 1].transpose(dim0=2, dim1=3).flatten(2, 3), local_value_1650.flip(local_value_1699[:, 2].flatten(2, 3), dims=[-1]), local_value_1650.flip(local_value_1699[:, 3].transpose(dim0=2, dim1=3).flatten(2, 3), dims=[-1])], dim=1)
        elif local_value_1308 == 1:
            y = local_value_1699.flatten(2, 3)
        elif local_value_1308 == 2:
            y = local_value_1650.stack([local_value_1699[:, 0].flatten(2, 3), local_value_1699[:, 1].flatten(2, 3), local_value_1650.flip(local_value_1699[:, 2].flatten(2, 3), dims=[-1]), local_value_1650.flip(local_value_1699[:, 3].flatten(2, 3), dims=[-1])], dim=1)
    else:
        B, H, W, local_value_0272, local_value_0044 = local_value_1699.shape
        if local_value_1308 == 0:
            y = local_value_1650.stack([local_value_1699[:, :, :, 0].flatten(1, 2), local_value_1699[:, :, :, 1].transpose(dim0=1, dim1=2).flatten(1, 2), local_value_1650.flip(local_value_1699[:, :, :, 2].flatten(1, 2), dims=[1]), local_value_1650.flip(local_value_1699[:, :, :, 3].transpose(dim0=1, dim1=2).flatten(1, 2), dims=[1])], dim=2)
        elif local_value_1308 == 1:
            y = local_value_1699.flatten(1, 2)
        elif local_value_1308 == 2:
            y = local_value_1650.stack([local_value_1699[:, 0].flatten(1, 2), local_value_1699[:, 1].flatten(1, 2), local_value_1650.flip(local_value_1699[:, 2].flatten(1, 2), dims=[-1]), local_value_1650.flip(local_value_1699[:, 3].flatten(1, 2), dims=[-1])], dim=2)
    if in_channel_first and (not out_channel_first):
        y = y.permute(0, 3, 1, 2).contiguous()
    elif not in_channel_first and out_channel_first:
        y = y.permute(0, 2, 3, 1).contiguous()
    return y

def execute_step_0540(y: local_value_1650.Tensor, in_channel_first=True, out_channel_first=True, local_value_1308=0):
    if out_channel_first:
        B, local_value_0156, D, H, W = y.shape
        y = y.view(B, local_value_0156, D, -1)
        if local_value_1308 == 0:
            y = local_value_1650.stack([y[:, 0], y[:, 1].view(B, -1, W, H).transpose(dim0=2, dim1=3).flatten(2, 3), local_value_1650.flip(y[:, 2], dims=[-1]), local_value_1650.flip(y[:, 3].view(B, -1, W, H).transpose(dim0=2, dim1=3).flatten(2, 3), dims=[-1])], dim=1)
        elif local_value_1308 == 1:
            y = y
        elif local_value_1308 == 2:
            y = local_value_1650.stack([y[:, 0], y[:, 1], local_value_1650.flip(y[:, 2], dims=[-1]), local_value_1650.flip(y[:, 3], dims=[-1])], dim=1)
    else:
        B, H, W, local_value_0156, D = y.shape
        y = y.view(B, -1, local_value_0156, D)
        if local_value_1308 == 0:
            y = local_value_1650.stack([y[:, :, 0], y[:, :, 1].view(B, W, H, -1).transpose(dim0=1, dim1=2).flatten(1, 2), local_value_1650.flip(y[:, :, 2], dims=[1]), local_value_1650.flip(y[:, :, 3].view(B, W, H, -1).transpose(dim0=1, dim1=2).flatten(1, 2), dims=[1])], dim=2)
        elif local_value_1308 == 1:
            y = y
        elif local_value_1308 == 2:
            y = local_value_1650.stack([y[:, :, 0], y[:, :, 1], local_value_1650.flip(y[:, :, 2], dims=[1]), local_value_1650.flip(y[:, :, 3], dims=[1])], dim=2)
    if out_channel_first and (not in_channel_first):
        y = y.permute(0, 3, 1, 2).contiguous()
    elif not out_channel_first and in_channel_first:
        y = y.permute(0, 2, 3, 1).contiguous()
    return y

class ComponentUnit0076(local_value_1650.autograd.Function):

    @staticmethod
    def forward(local_value_0551, local_value_1699: local_value_1650.Tensor, in_channel_first=True, out_channel_first=True, local_value_1132=False, local_value_1308=0):
        local_value_0551.in_channel_first = in_channel_first
        local_value_0551.out_channel_first = out_channel_first
        local_value_0551.local_value_1132 = local_value_1132
        local_value_0551.local_value_1308 = local_value_1308
        if local_value_1132:
            B, local_value_0156, local_value_0044, H, W = local_value_1699.shape
            if not in_channel_first:
                B, H, W, local_value_0156, local_value_0044 = local_value_1699.shape
        else:
            B, local_value_0044, H, W = local_value_1699.shape
            if not in_channel_first:
                B, H, W, local_value_0044 = local_value_1699.shape
        local_value_0551.shape = (B, local_value_0044, H, W)
        local_value_0339 = execute_step_0544 if local_value_1132 else execute_step_0547
        y = local_value_0339(local_value_1699, in_channel_first, out_channel_first, local_value_1308)
        return y

    @staticmethod
    def backward(local_value_0551, ys: local_value_1650.Tensor):
        in_channel_first = local_value_0551.in_channel_first
        out_channel_first = local_value_0551.out_channel_first
        local_value_1132 = local_value_0551.local_value_1132
        local_value_1308 = local_value_0551.local_value_1308
        B, local_value_0044, H, W = local_value_0551.shape
        ys = ys.view(B, -1, local_value_0044, H, W) if out_channel_first else ys.view(B, H, W, -1, local_value_0044)
        local_value_0339 = execute_step_0540 if local_value_1132 else execute_step_0542
        y = local_value_0339(ys, in_channel_first, out_channel_first, local_value_1308)
        if local_value_1132:
            y = y.view(B, 4, -1, H, W) if in_channel_first else y.view(B, H, W, 4, -1)
        else:
            y = y.view(B, -1, H, W) if in_channel_first else y.view(B, H, W, -1)
        return (y, None, None, None, None)

class ComponentUnit0070(local_value_1650.autograd.Function):

    @staticmethod
    def forward(local_value_0551, ys: local_value_1650.Tensor, in_channel_first=True, out_channel_first=True, local_value_1132=False, local_value_1308=0):
        local_value_0551.in_channel_first = in_channel_first
        local_value_0551.out_channel_first = out_channel_first
        local_value_0551.local_value_1132 = local_value_1132
        local_value_0551.local_value_1308 = local_value_1308
        B, local_value_0156, local_value_0044, H, W = ys.shape
        if not out_channel_first:
            B, H, W, local_value_0156, local_value_0044 = ys.shape
        local_value_0551.shape = (B, local_value_0044, H, W)
        local_value_0339 = execute_step_0540 if local_value_1132 else execute_step_0542
        y = local_value_0339(ys, in_channel_first, out_channel_first, local_value_1308)
        return y

    @staticmethod
    def backward(local_value_0551, local_value_1699: local_value_1650.Tensor):
        in_channel_first = local_value_0551.in_channel_first
        out_channel_first = local_value_0551.out_channel_first
        local_value_1132 = local_value_0551.local_value_1132
        local_value_1308 = local_value_0551.local_value_1308
        B, local_value_0044, H, W = local_value_0551.shape
        if not local_value_1132:
            if in_channel_first:
                local_value_1699 = local_value_1699.view(B, local_value_0044, H, W)
            else:
                local_value_1699 = local_value_1699.view(B, H, W, local_value_0044)
        elif in_channel_first:
            local_value_1699 = local_value_1699.view(B, 4, local_value_0044, H, W)
        else:
            local_value_1699 = local_value_1699.view(B, H, W, 4, local_value_0044)
        local_value_0339 = execute_step_0544 if local_value_1132 else execute_step_0547
        local_value_1699 = local_value_0339(local_value_1699, in_channel_first, out_channel_first, local_value_1308)
        local_value_1699 = local_value_1699.view(B, 4, local_value_0044, H, W) if out_channel_first else local_value_1699.view(B, H, W, 4, local_value_0044)
        return (local_value_1699, None, None, None, None)

@local_value_1655.jit
def execute_step_1656(local_value_1699: local_value_1631.tensor, y: local_value_1631.tensor, local_value_1715: local_value_1631.constexpr, local_value_1744: local_value_1631.constexpr, local_value_1134: local_value_1631.constexpr, local_value_1133: local_value_1631.constexpr, local_value_1308: local_value_1631.constexpr, local_value_0017: local_value_1631.constexpr, local_value_0018: local_value_1631.constexpr, local_value_0032: local_value_1631.constexpr, local_value_0087: local_value_1631.constexpr, local_value_0089: local_value_1631.constexpr, local_value_0098: local_value_1631.constexpr, local_value_0190: local_value_1631.constexpr, local_value_0195: local_value_1631.constexpr):
    local_value_0945, local_value_0943, local_value_0942 = (local_value_1631.program_id(0), local_value_1631.program_id(1), local_value_1631.program_id(2))
    local_value_0944, local_value_0947 = (local_value_0945 // local_value_0195, local_value_0945 % local_value_0195)
    local_value_0370 = local_value_0944 * local_value_0018 + local_value_1631.arange(0, local_value_0018) < local_value_0089
    local_value_0373 = local_value_0947 * local_value_0032 + local_value_1631.arange(0, local_value_0032) < local_value_0098
    local_value_0371 = local_value_0370[:, None] & local_value_0373[None, :]
    local_value_0340 = min(local_value_0087 - local_value_0943 * local_value_0017, local_value_0017)
    local_value_1216 = local_value_0944 * local_value_0018 + local_value_1631.arange(0, local_value_0018)[:, None]
    local_value_1217 = local_value_0947 * local_value_0032 + local_value_1631.arange(0, local_value_0032)[None, :]
    local_value_1080 = local_value_0089 - local_value_0944 * local_value_0018 - 1 - local_value_1631.arange(0, local_value_0018)[:, None]
    local_value_1081 = local_value_0098 - local_value_0947 * local_value_0032 - 1 - local_value_1631.arange(0, local_value_0032)[None, :]
    if local_value_1308 == 0:
        local_value_0145 = local_value_1216 * local_value_0098 + local_value_1217
        local_value_0146 = local_value_1217 * local_value_0089 + local_value_1216
        local_value_0147 = local_value_1080 * local_value_0098 + local_value_1081
        local_value_0148 = local_value_1081 * local_value_0089 + local_value_1080
    elif local_value_1308 == 1:
        local_value_0145 = local_value_1216 * local_value_0098 + local_value_1217
        local_value_0146 = local_value_0145
        local_value_0147 = local_value_0145
        local_value_0148 = local_value_0145
    elif local_value_1308 == 2:
        local_value_0145 = local_value_1216 * local_value_0098 + local_value_1217
        local_value_0146 = local_value_0145
        local_value_0147 = local_value_1080 * local_value_0098 + local_value_1081
        local_value_0148 = local_value_0147
    local_value_0393 = local_value_0087 * local_value_0089 * local_value_0098
    local_value_1746 = y + local_value_0942 * 4 * local_value_0393 + (local_value_0943 * local_value_0017 * local_value_0089 * local_value_0098 if local_value_1744 == 0 else local_value_0943 * local_value_0017)
    if local_value_1744 == 0:
        local_value_1188 = local_value_1746 + local_value_0145
        local_value_1189 = local_value_1746 + local_value_0393 + local_value_0146
        local_value_1190 = local_value_1746 + 2 * local_value_0393 + local_value_0147
        local_value_1191 = local_value_1746 + 3 * local_value_0393 + local_value_0148
    else:
        local_value_1188 = local_value_1746 + local_value_0145 * 4 * local_value_0087
        local_value_1189 = local_value_1746 + local_value_0087 + local_value_0146 * 4 * local_value_0087
        local_value_1190 = local_value_1746 + 2 * local_value_0087 + local_value_0147 * 4 * local_value_0087
        local_value_1191 = local_value_1746 + 3 * local_value_0087 + local_value_0148 * 4 * local_value_0087
    if local_value_1133 == 0:
        local_value_1721 = local_value_1699 + local_value_0942 * local_value_0393 + (local_value_0943 * local_value_0017 * local_value_0089 * local_value_0098 if local_value_1715 == 0 else local_value_0943 * local_value_0017)
        if local_value_1715 == 0:
            local_value_1183 = local_value_1721 + local_value_0145
        else:
            local_value_1183 = local_value_1721 + local_value_0145 * local_value_0087
        if local_value_1134 == 0:
            for local_value_0952 in range(local_value_0340):
                local_value_0351 = local_value_0952 * local_value_0089 * local_value_0098 if local_value_1715 == 0 else local_value_0952
                local_value_0352 = local_value_0952 * local_value_0089 * local_value_0098 if local_value_1744 == 0 else local_value_0952
                local_value_0397 = local_value_1631.load(local_value_1183 + local_value_0351, mask=local_value_0371)
                local_value_1631.store(local_value_1188 + local_value_0352, local_value_0397, mask=local_value_0371)
                local_value_1631.store(local_value_1189 + local_value_0352, local_value_0397, mask=local_value_0371)
                local_value_1631.store(local_value_1190 + local_value_0352, local_value_0397, mask=local_value_0371)
                local_value_1631.store(local_value_1191 + local_value_0352, local_value_0397, mask=local_value_0371)
        elif local_value_1134 == 1:
            for local_value_0952 in range(local_value_0340):
                local_value_0351 = local_value_0952 * local_value_0089 * local_value_0098 if local_value_1715 == 0 else local_value_0952
                local_value_0352 = local_value_0952 * local_value_0089 * local_value_0098 if local_value_1744 == 0 else local_value_0952
                local_value_0398 = local_value_1631.load(local_value_1188 + local_value_0352, mask=local_value_0371)
                local_value_0399 = local_value_1631.load(local_value_1189 + local_value_0352, mask=local_value_0371)
                local_value_0400 = local_value_1631.load(local_value_1190 + local_value_0352, mask=local_value_0371)
                local_value_0401 = local_value_1631.load(local_value_1191 + local_value_0352, mask=local_value_0371)
                local_value_1631.store(local_value_1183 + local_value_0351, local_value_0398 + local_value_0399 + local_value_0400 + local_value_0401, mask=local_value_0371)
    else:
        local_value_1721 = local_value_1699 + local_value_0942 * 4 * local_value_0393 + (local_value_0943 * local_value_0017 * local_value_0089 * local_value_0098 if local_value_1715 == 0 else local_value_0943 * local_value_0017)
        if local_value_1715 == 0:
            local_value_1184 = local_value_1721 + local_value_0145
            local_value_1185 = local_value_1184 + local_value_0393
            local_value_1186 = local_value_1185 + local_value_0393
            local_value_1187 = local_value_1186 + local_value_0393
        else:
            local_value_1184 = local_value_1721 + local_value_0145 * 4 * local_value_0087
            local_value_1185 = local_value_1184 + local_value_0087
            local_value_1186 = local_value_1185 + local_value_0087
            local_value_1187 = local_value_1186 + local_value_0087
        if local_value_1134 == 0:
            for local_value_0952 in range(local_value_0340):
                local_value_0351 = local_value_0952 * local_value_0089 * local_value_0098 if local_value_1715 == 0 else local_value_0952
                local_value_0352 = local_value_0952 * local_value_0089 * local_value_0098 if local_value_1744 == 0 else local_value_0952
                local_value_1631.store(local_value_1188 + local_value_0352, local_value_1631.load(local_value_1184 + local_value_0351, mask=local_value_0371), mask=local_value_0371)
                local_value_1631.store(local_value_1189 + local_value_0352, local_value_1631.load(local_value_1185 + local_value_0351, mask=local_value_0371), mask=local_value_0371)
                local_value_1631.store(local_value_1190 + local_value_0352, local_value_1631.load(local_value_1186 + local_value_0351, mask=local_value_0371), mask=local_value_0371)
                local_value_1631.store(local_value_1191 + local_value_0352, local_value_1631.load(local_value_1187 + local_value_0351, mask=local_value_0371), mask=local_value_0371)
        else:
            for local_value_0952 in range(local_value_0340):
                local_value_0351 = local_value_0952 * local_value_0089 * local_value_0098 if local_value_1715 == 0 else local_value_0952
                local_value_0352 = local_value_0952 * local_value_0089 * local_value_0098 if local_value_1744 == 0 else local_value_0952
                local_value_1631.store(local_value_1184 + local_value_0351, local_value_1631.load(local_value_1188 + local_value_0352), mask=local_value_0371)
                local_value_1631.store(local_value_1185 + local_value_0351, local_value_1631.load(local_value_1189 + local_value_0352), mask=local_value_0371)
                local_value_1631.store(local_value_1186 + local_value_0351, local_value_1631.load(local_value_1190 + local_value_0352), mask=local_value_0371)
                local_value_1631.store(local_value_1187 + local_value_0351, local_value_1631.load(local_value_1191 + local_value_0352), mask=local_value_0371)

class ComponentUnit0079(local_value_1650.autograd.Function):

    @staticmethod
    def forward(local_value_0551, local_value_1699: local_value_1650.Tensor, in_channel_first=True, out_channel_first=True, local_value_1132=False, local_value_1308=0):
        if local_value_1132:
            if in_channel_first:
                B, local_value_0272, local_value_0044, H, W = local_value_1699.shape
            else:
                B, H, W, local_value_0272, local_value_0044 = local_value_1699.shape
        elif in_channel_first:
            B, local_value_0044, H, W = local_value_1699.shape
        else:
            B, H, W, local_value_0044 = local_value_1699.shape
        B, local_value_0044, H, W = (int(B), int(local_value_0044), int(H), int(W))
        local_value_0017, local_value_0018, local_value_0032 = (1, 32, 32)
        local_value_0190, local_value_0195, local_value_0189 = (local_value_1655.cdiv(H, local_value_0018), local_value_1655.cdiv(W, local_value_0032), local_value_1655.cdiv(local_value_0044, local_value_0017))
        local_value_0551.in_channel_first = in_channel_first
        local_value_0551.out_channel_first = out_channel_first
        local_value_0551.local_value_1132 = local_value_1132
        local_value_0551.local_value_1308 = local_value_1308
        local_value_0551.shape = (B, local_value_0044, H, W)
        local_value_0551.member_slot_0467 = (local_value_0017, local_value_0018, local_value_0032, local_value_0189, local_value_0190, local_value_0195)
        y = local_value_1699.new_empty((B, 4, local_value_0044, H * W)) if out_channel_first else local_value_1699.new_empty((B, H * W, 4, local_value_0044))
        execute_step_1656[local_value_0190 * local_value_0195, local_value_0189, B](local_value_1699.contiguous(), y, 0 if in_channel_first else 1, 0 if out_channel_first else 1, 0, 0 if not local_value_1132 else 1, local_value_1308, local_value_0017, local_value_0018, local_value_0032, local_value_0044, H, W, local_value_0190, local_value_0195)
        return y

    @staticmethod
    def backward(local_value_0551, y: local_value_1650.Tensor):
        in_channel_first = local_value_0551.in_channel_first
        out_channel_first = local_value_0551.out_channel_first
        local_value_1132 = local_value_0551.local_value_1132
        local_value_1308 = local_value_0551.local_value_1308
        B, local_value_0044, H, W = local_value_0551.shape
        local_value_0017, local_value_0018, local_value_0032, local_value_0189, local_value_0190, local_value_0195 = local_value_0551.member_slot_0467
        if local_value_1132:
            local_value_1699 = y.new_empty((B, 4, local_value_0044, H, W)) if in_channel_first else y.new_empty((B, H, W, 4, local_value_0044))
        else:
            local_value_1699 = y.new_empty((B, local_value_0044, H, W)) if in_channel_first else y.new_empty((B, H, W, local_value_0044))
        execute_step_1656[local_value_0190 * local_value_0195, local_value_0189, B](local_value_1699, y.contiguous(), 0 if in_channel_first else 1, 0 if out_channel_first else 1, 1, 0 if not local_value_1132 else 1, local_value_1308, local_value_0017, local_value_0018, local_value_0032, local_value_0044, H, W, local_value_0190, local_value_0195)
        return (local_value_1699, None, None, None, None)

class ComponentUnit0072(local_value_1650.autograd.Function):

    @staticmethod
    def forward(local_value_0551, y: local_value_1650.Tensor, in_channel_first=True, out_channel_first=True, local_value_1132=False, local_value_1308=0):
        if out_channel_first:
            B, local_value_0272, local_value_0044, H, W = y.shape
        else:
            B, H, W, local_value_0272, local_value_0044 = y.shape
        B, local_value_0044, H, W = (int(B), int(local_value_0044), int(H), int(W))
        local_value_0017, local_value_0018, local_value_0032 = (1, 32, 32)
        local_value_0190, local_value_0195, local_value_0189 = (local_value_1655.cdiv(H, local_value_0018), local_value_1655.cdiv(W, local_value_0032), local_value_1655.cdiv(local_value_0044, local_value_0017))
        local_value_0551.in_channel_first = in_channel_first
        local_value_0551.out_channel_first = out_channel_first
        local_value_0551.local_value_1132 = local_value_1132
        local_value_0551.local_value_1308 = local_value_1308
        local_value_0551.shape = (B, local_value_0044, H, W)
        local_value_0551.member_slot_0467 = (local_value_0017, local_value_0018, local_value_0032, local_value_0189, local_value_0190, local_value_0195)
        if local_value_1132:
            local_value_1699 = y.new_empty((B, 4, local_value_0044, H * W)) if in_channel_first else y.new_empty((B, H * W, 4, local_value_0044))
        else:
            local_value_1699 = y.new_empty((B, local_value_0044, H * W)) if in_channel_first else y.new_empty((B, H * W, local_value_0044))
        execute_step_1656[local_value_0190 * local_value_0195, local_value_0189, B](local_value_1699, y.contiguous(), 0 if in_channel_first else 1, 0 if out_channel_first else 1, 1, 0 if not local_value_1132 else 1, local_value_1308, local_value_0017, local_value_0018, local_value_0032, local_value_0044, H, W, local_value_0190, local_value_0195)
        return local_value_1699

    @staticmethod
    def backward(local_value_0551, local_value_1699: local_value_1650.Tensor):
        in_channel_first = local_value_0551.in_channel_first
        out_channel_first = local_value_0551.out_channel_first
        local_value_1132 = local_value_0551.local_value_1132
        local_value_1308 = local_value_0551.local_value_1308
        B, local_value_0044, H, W = local_value_0551.shape
        local_value_0017, local_value_0018, local_value_0032, local_value_0189, local_value_0190, local_value_0195 = local_value_0551.member_slot_0467
        y = local_value_1699.new_empty((B, 4, local_value_0044, H, W)) if out_channel_first else local_value_1699.new_empty((B, H, W, 4, local_value_0044))
        execute_step_1656[local_value_0190 * local_value_0195, local_value_0189, B](local_value_1699.contiguous(), y, 0 if in_channel_first else 1, 0 if out_channel_first else 1, 0, 0 if not local_value_1132 else 1, local_value_1308, local_value_0017, local_value_0018, local_value_0032, local_value_0044, H, W, local_value_0190, local_value_0195)
        return (y, None, None, None, None, None)

def execute_step_0546(local_value_1699: local_value_1650.Tensor, in_channel_first=True, out_channel_first=True, local_value_1132=False, local_value_1308=0, local_value_0854=False):
    local_value_0053 = ComponentUnit0079 if local_value_0258 and local_value_1699.is_cuda and (not local_value_0854) else ComponentUnit0076
    with local_value_1650.cuda.device(local_value_1699.device):
        return local_value_0053.apply(local_value_1699, in_channel_first, out_channel_first, local_value_1132, local_value_1308)

def execute_step_0541(y: local_value_1650.Tensor, in_channel_first=True, out_channel_first=True, local_value_1132=False, local_value_1308=0, local_value_0854=False):
    local_value_0051 = ComponentUnit0072 if local_value_0258 and y.is_cuda and (not local_value_0854) else ComponentUnit0070
    with local_value_1650.cuda.device(y.device):
        return local_value_0051.apply(y, in_channel_first, out_channel_first, local_value_1132, local_value_1308)

class ComponentUnit0049:

    def execute_step_0498():
        B, local_value_0044, H, W = (256, 192, 56, 57)
        dtype = local_value_1650.float16
        dtype = local_value_1650.float32
        local_value_1699 = local_value_1650.randn((B, local_value_0044, H, W), dtype=dtype, device=local_value_1650.device('cuda')).requires_grad_(True)
        y = local_value_1650.randn((B, 4, local_value_0044, H, W), dtype=dtype, device=local_value_1650.device('cuda')).requires_grad_(True)
        local_value_1701 = local_value_1699.clone().detach().requires_grad_(True)
        local_value_1737 = y.clone().detach().requires_grad_(True)

        def execute_step_0543(local_value_1699: local_value_1650.Tensor):
            B, local_value_0044, H, W = local_value_1699.shape
            L = H * W
            local_value_1733 = local_value_1650.stack([local_value_1699.view(B, local_value_0044, L), local_value_1650.transpose(local_value_1699, dim0=2, dim1=3).contiguous().view(B, local_value_0044, L), local_value_1650.flip(local_value_1699.contiguous().view(B, local_value_0044, L), dims=[-1]), local_value_1650.flip(local_value_1650.transpose(local_value_1699, dim0=2, dim1=3).contiguous().view(B, local_value_0044, L), dims=[-1])], dim=1).view(B, 4, local_value_0044, L)
            return local_value_1733

        def execute_step_0539(local_value_1169: local_value_1650.Tensor):
            B, local_value_0156, D, H, W = local_value_1169.shape
            L = H * W
            local_value_1169 = local_value_1169.view(B, local_value_0156, D, L)
            local_value_0987 = local_value_1650.flip(local_value_1169[:, 2:4], dims=[-1]).view(B, 2, -1, L)
            local_value_1690 = local_value_1650.transpose(local_value_1169[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)
            local_value_0988 = local_value_1650.transpose(local_value_0987[:, 1].view(B, -1, W, H), dim0=2, dim1=3).contiguous().view(B, -1, L)
            y = local_value_1169[:, 0] + local_value_0987[:, 0] + local_value_1690 + local_value_0988
            return y

        def execute_step_0545(local_value_1699: local_value_1650.Tensor):
            B, local_value_0156, local_value_0044, H, W = local_value_1699.shape
            L = H * W
            local_value_1733 = local_value_1650.stack([local_value_1699[:, 0].view(B, local_value_0044, L), local_value_1650.transpose(local_value_1699[:, 1], dim0=2, dim1=3).contiguous().view(B, local_value_0044, L), local_value_1650.flip(local_value_1699[:, 2].contiguous().view(B, local_value_0044, L), dims=[-1]), local_value_1650.flip(local_value_1650.transpose(local_value_1699[:, 3], dim0=2, dim1=3).contiguous().view(B, local_value_0044, L), dims=[-1])], dim=1).view(B, 4, local_value_0044, L)
            return local_value_1733

        def execute_step_1665(local_value_1699):
            B, local_value_0044, H, W = local_value_1699.shape
            local_value_1699 = local_value_1699.view(B, 1, local_value_0044, H * W).repeat(1, 4, 1, 1)
            return local_value_1699

        def execute_step_1664(ys):
            B, local_value_0156, local_value_0044, H, W = ys.shape
            return ys.view(B, 4, -1, H * W).sum(1)

        def execute_step_0444(local_value_1699):
            B, local_value_0044, H, W = local_value_1699.shape
            local_value_1699 = local_value_1699.view(B, 1, local_value_0044, H * W).repeat(1, 2, 1, 1)
            local_value_1699 = local_value_1650.cat([local_value_1699, local_value_1699.flip(dims=[-1])], dim=1)
            return local_value_1699

        def execute_step_0443(ys):
            B, local_value_0156, D, H, W = ys.shape
            ys = ys.view(B, local_value_0156, D, -1)
            ys = ys[:, 0:2] + ys[:, 2:4].flip(dims=[-1]).view(B, 2, D, -1)
            return ys.contiguous().sum(1)
        if True:
            local_value_1259 = local_value_1655.testing.do_bench(lambda: execute_step_0543(local_value_1699))
            local_value_1260 = local_value_1655.testing.do_bench(lambda: execute_step_0546(local_value_1699, True, True, False))
            local_value_1262 = local_value_1655.testing.do_bench(lambda: execute_step_0539(y))
            local_value_1263 = local_value_1655.testing.do_bench(lambda: execute_step_0541(y, True, True, False))
            print(local_value_1259, local_value_1260, local_value_1262, local_value_1263)
            local_value_1259 = local_value_1655.testing.do_bench(lambda: execute_step_0543(local_value_1699).sum().backward())
            local_value_1260 = local_value_1655.testing.do_bench(lambda: execute_step_0546(local_value_1699, True, True, False).sum().backward())
            local_value_1262 = local_value_1655.testing.do_bench(lambda: execute_step_0539(y).sum().backward())
            local_value_1263 = local_value_1655.testing.do_bench(lambda: execute_step_0541(y, True, True, False).sum().backward())
            print(local_value_1259, local_value_1260, local_value_1262, local_value_1263)
        print('test cross scan')
        for local_value_0549, local_value_0525, local_value_0550, local_value_0526 in [(execute_step_0543, execute_step_0539, execute_step_0546, execute_step_0541), (execute_step_1665, execute_step_1664, lambda local_value_1699: execute_step_0546(local_value_1699, local_value_1308=1), lambda local_value_1699: execute_step_0541(local_value_1699, local_value_1308=1)), (execute_step_0444, execute_step_0443, lambda local_value_1699: execute_step_0546(local_value_1699, local_value_1308=2), lambda local_value_1699: execute_step_0541(local_value_1699, local_value_1308=2)), (execute_step_0543, execute_step_0539, lambda local_value_1699: execute_step_0546(local_value_1699.permute(0, 2, 3, 1), in_channel_first=False), lambda local_value_1699: execute_step_0541(local_value_1699, in_channel_first=False).permute(0, 2, 1)), (execute_step_0543, execute_step_0539, lambda local_value_1699: execute_step_0546(local_value_1699, out_channel_first=False).permute(0, 2, 3, 1), lambda local_value_1699: execute_step_0541(local_value_1699.permute(0, 3, 4, 1, 2), out_channel_first=False)), (execute_step_0543, execute_step_0539, lambda local_value_1699: execute_step_0546(local_value_1699.permute(0, 2, 3, 1), in_channel_first=False, out_channel_first=False).permute(0, 2, 3, 1), lambda local_value_1699: execute_step_0541(local_value_1699.permute(0, 3, 4, 1, 2), in_channel_first=False, out_channel_first=False).permute(0, 2, 1))]:
            local_value_1699.grad, local_value_1701.grad, y.grad, local_value_1737.grad = (None, None, None, None)
            local_value_1114 = local_value_0549(local_value_1699)
            local_value_1115 = local_value_0550(local_value_1701)
            local_value_1114.backward(y.view(B, 4, local_value_0044, H * W))
            local_value_1115.backward(y.view(B, 4, local_value_0044, H * W))
            print((local_value_1114 - local_value_1115).abs().max())
            print((local_value_1699.grad - local_value_1701.grad).abs().max())
            local_value_1114 = local_value_0525(y)
            local_value_1115 = local_value_0526(local_value_1737)
            local_value_1114.backward(local_value_1699.view(B, local_value_0044, H * W))
            local_value_1115.backward(local_value_1699.view(B, local_value_0044, H * W))
            print((local_value_1114 - local_value_1115).abs().max())
            print((y.grad - local_value_1737.grad).abs().max())
            local_value_1699.grad, local_value_1701.grad, y.grad, local_value_1737.grad = (None, None, None, None)
            print('===============', flush=True)
        print('test cross scan one by one')
        for local_value_0549, local_value_0550 in [(execute_step_0545, lambda local_value_1699: execute_step_0546(local_value_1699, local_value_1132=True))]:
            local_value_1114 = local_value_0549(y)
            local_value_1115 = local_value_0550(local_value_1737)
            local_value_1114.backward(y.view(B, 4, local_value_0044, H * W))
            local_value_1115.backward(y.view(B, 4, local_value_0044, H * W))
            print((local_value_1114 - local_value_1115).abs().max())
            print((y.grad - local_value_1737.grad).abs().max())
            local_value_1699.grad, local_value_1701.grad, y.grad, local_value_1737.grad = (None, None, None, None)
            print('===============', flush=True)

    def execute_step_0497():
        if False:
            local_value_1699 = local_value_1650.arange(0, 16).view(1, 1, 4, 4).cuda()
            local_value_1140 = execute_step_0546(local_value_1699, local_value_1308=3, local_value_0854=True).view(1, 4, 1, 4, 4)
            local_value_1142 = execute_step_0541(local_value_1140, local_value_1308=3, local_value_0854=True).view(1, 1, 4, 4)
            local_value_1144 = execute_step_0541(local_value_1140, local_value_1132=True, local_value_1308=3, local_value_0854=True).view(1, 4, 1, 4, 4)
            local_value_1143 = execute_step_0546(local_value_1144, local_value_1132=True, local_value_1308=3, local_value_0854=True).view(1, 4, 1, 4, 4)
            local_value_1145 = execute_step_0546(local_value_1699.view(1, 4, 4, 1), in_channel_first=False, out_channel_first=False, local_value_1308=3, local_value_0854=True).view(1, 4, 4, 4, 1)
            local_value_1146 = execute_step_0541(local_value_1145, in_channel_first=False, out_channel_first=False, local_value_1308=3, local_value_0854=True).view(1, 4, 4, 1)
            local_value_1148 = execute_step_0541(local_value_1145, in_channel_first=False, out_channel_first=False, local_value_1132=True, local_value_1308=3, local_value_0854=True).view(1, 4, 4, 4, 1)
            local_value_1147 = execute_step_0546(local_value_1148, in_channel_first=False, out_channel_first=False, local_value_1132=True, local_value_1308=3, local_value_0854=True).view(1, 4, 4, 4, 1)
            print(local_value_1140.view(4, -1))
            print(local_value_1142.view(-1))
            print(local_value_1143.view(4, -1))
            print(local_value_1144.view(4, -1))
            print(local_value_1145.view(-1, 4).t())
            print(local_value_1146.view(-1))
            print(local_value_1147.view(-1, 4).t())
            print(local_value_1148.view(-1, 4).t())
        B, local_value_0044, H, W = (27, 253, 57, 58)
        local_value_1699 = local_value_1650.randn((B, local_value_0044, H, W)).cuda()
        for local_value_1308 in [0, 1, 2, 3]:
            local_value_1115 = execute_step_0546(local_value_1699, local_value_1308=local_value_1308, local_value_0854=True).view(B, 4, local_value_0044, H, W)
            print((execute_step_0546(local_value_1699, local_value_1308=local_value_1308) == execute_step_0546(local_value_1699, local_value_1308=local_value_1308, local_value_0854=True)).all())
            print((execute_step_0541(local_value_1115, local_value_1308=local_value_1308) == execute_step_0541(local_value_1115, local_value_1308=local_value_1308, local_value_0854=True)).all())
            local_value_1007 = dict(in_channel_first=False, out_channel_first=False)
            local_value_1702 = local_value_1699.permute(0, 2, 3, 1).contiguous()
            local_value_1116 = local_value_1115.permute(0, 3, 4, 1, 2).contiguous()
            print((execute_step_0546(local_value_1699, local_value_1308=local_value_1308, **local_value_1007) == execute_step_0546(local_value_1699, local_value_1308=local_value_1308, local_value_0854=True, **local_value_1007)).all())
            print((execute_step_0541(local_value_1116, local_value_1308=local_value_1308, **local_value_1007) == execute_step_0541(local_value_1116, local_value_1308=local_value_1308, local_value_0854=True, **local_value_1007)).all())
        breakpoint()
if __name__ == '__main__':
    ComponentUnit0049.execute_step_0497()
    ComponentUnit0049.execute_step_0498()
