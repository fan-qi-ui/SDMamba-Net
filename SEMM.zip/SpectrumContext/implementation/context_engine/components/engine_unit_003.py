import time as local_value_1630
import torch as local_value_1650
import warnings as local_value_1686
from .tensor_primitives import *
local_value_0257 = True
local_value_0255 = False
local_value_0256 = True
try:
    import selective_scan_cuda_oflex as local_value_1321
except ImportError:
    local_value_0257 = False
    local_value_1686.warn('Can not import selective_scan_cuda_oflex. This affects speed.')
    print('Can not import selective_scan_cuda_oflex. This affects speed.', flush=True)
try:
    import selective_scan_cuda_core as local_value_1320
except ImportError:
    local_value_0255 = False
try:
    import selective_scan_cuda as local_value_1319
except ImportError:
    local_value_0256 = False

def execute_step_1333(local_value_1660: local_value_1650.Tensor, delta: local_value_1650.Tensor, local_value_0000: local_value_1650.Tensor, B: local_value_1650.Tensor, local_value_0044: local_value_1650.Tensor, D: local_value_1650.Tensor=None, delta_bias: local_value_1650.Tensor=None, local_value_0696=True, oflex=True, *local_value_0416, **local_value_1007):
    local_value_0799 = local_value_1660.dtype
    local_value_0039, local_value_0156, N, L = B.shape
    local_value_0157 = local_value_1660.shape[1]
    local_value_0063 = int(local_value_0157 / local_value_0156)
    assert local_value_1660.shape == (local_value_0039, local_value_0157, L)
    assert delta.shape == (local_value_0039, local_value_0157, L)
    assert local_value_0000.shape == (local_value_0157, N)
    assert local_value_0044.shape == B.shape
    if delta_bias is not None:
        delta = delta + delta_bias[..., None]
    if local_value_0696:
        delta = local_value_1650.nn.functional.softplus(delta)
    local_value_1660, delta, local_value_0000, B, local_value_0044 = (local_value_1660.float(), delta.float(), local_value_0000.float(), B.float(), local_value_0044.float())
    B = B.view(local_value_0039, local_value_0156, 1, N, L).repeat(1, 1, local_value_0063, 1, 1).view(local_value_0039, local_value_0157, N, L)
    local_value_0044 = local_value_0044.view(local_value_0039, local_value_0156, 1, N, L).repeat(1, 1, local_value_0063, 1, 1).view(local_value_0039, local_value_0157, N, L)
    local_value_0690 = local_value_1650.exp(local_value_1650.einsum('bdl,dn->bdln', delta, local_value_0000))
    local_value_0691 = local_value_1650.einsum('bdl,bdnl,bdl->bdln', delta, B, local_value_1660)
    if True:
        local_value_1699 = local_value_0000.new_zeros((local_value_0039, local_value_0157, N))
        ys = []
        for local_value_0939 in range(L):
            local_value_1699 = local_value_0690[:, :, local_value_0939, :] * local_value_1699 + local_value_0691[:, :, local_value_0939, :]
            y = local_value_1650.einsum('bdn,bdn->bd', local_value_1699, local_value_0044[:, :, :, local_value_0939])
            ys.append(y)
        y = local_value_1650.stack(ys, dim=2)
    out = y if D is None else y + local_value_1660 * D.unsqueeze(-1)
    return out if oflex else out.to(dtype=local_value_0799)

class ComponentUnit0230(local_value_1650.autograd.Function):

    @staticmethod
    @local_value_1650.cuda.amp.custom_fwd
    def forward(local_value_0551, local_value_1660, delta, local_value_0000, B, local_value_0044, D=None, delta_bias=None, local_value_0696=False, oflex=True, local_value_0430=None):
        local_value_0551.local_value_0696 = local_value_0696
        local_value_0430 = 'oflex' if local_value_0257 and local_value_0430 is None else local_value_0430
        local_value_0430 = 'core' if local_value_0255 and local_value_0430 is None else local_value_0430
        local_value_0430 = 'mamba' if local_value_0256 and local_value_0430 is None else local_value_0430
        local_value_0551.local_value_0430 = local_value_0430
        if local_value_0430 == 'oflex':
            out, local_value_1699, *local_value_1273 = local_value_1321.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, 1, oflex)
        elif local_value_0430 == 'core':
            out, local_value_1699, *local_value_1273 = local_value_1320.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, 1)
        elif local_value_0430 == 'mamba':
            out, local_value_1699, *local_value_1273 = local_value_1319.fwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, None, delta_bias, local_value_0696)
        local_value_0551.save_for_backward(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_1699)
        return out

    @staticmethod
    @local_value_1650.cuda.amp.custom_bwd
    def backward(local_value_0551, local_value_0723, *local_value_0416):
        local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_1699 = local_value_0551.saved_tensors
        local_value_0430 = local_value_0551.local_value_0430
        if local_value_0723.stride(-1) != 1:
            local_value_0723 = local_value_0723.contiguous()
        if local_value_0430 == 'oflex':
            local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, *local_value_1273 = local_value_1321.bwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0723, local_value_1699, local_value_0551.local_value_0696, 1)
        elif local_value_0430 == 'core':
            local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, *local_value_1273 = local_value_1320.bwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0723, local_value_1699, local_value_0551.local_value_0696, 1)
        elif local_value_0430 == 'mamba':
            local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, *local_value_1273 = local_value_1319.bwd(local_value_1660, delta, local_value_0000, B, local_value_0044, D, None, delta_bias, local_value_0723, local_value_1699, None, None, local_value_0551.local_value_0696, False)
        return (local_value_0800, local_value_0670, local_value_0564, local_value_0582, local_value_0585, local_value_0589, local_value_0671, None, None, None)

def execute_step_1330(local_value_1660: local_value_1650.Tensor, delta: local_value_1650.Tensor, local_value_0000: local_value_1650.Tensor, B: local_value_1650.Tensor, local_value_0044: local_value_1650.Tensor, D: local_value_1650.Tensor=None, delta_bias: local_value_1650.Tensor=None, local_value_0696=True, oflex=True, local_value_0430=None):
    local_value_0254 = local_value_0257 or local_value_0255 or local_value_0256
    local_value_0849 = execute_step_1333 if local_value_0430 == 'torch' or not local_value_0254 else ComponentUnit0230.apply
    return local_value_0849(local_value_1660, delta, local_value_0000, B, local_value_0044, D, delta_bias, local_value_0696, oflex, local_value_0430)

def execute_step_1228(inputs):
    print('input execute_step_1195: ', end=' ', flush=True)
    try:
        for local_value_0939 in range(10):
            print(inputs[local_value_0939].debugName(), end=' ', flush=True)
    except Exception as e:
        pass
    print('', flush=True)

def execute_step_0847(B=1, L=256, D=768, N=16, with_D=True, with_Z=False, local_value_1695=False):
    assert not local_value_1695
    execute_step_0845 = 9 * B * L * D * N
    if with_D:
        execute_step_0845 += B * D * L
    if with_Z:
        execute_step_0845 += B * D * L
    return execute_step_0845

def execute_step_0848(B=1, L=256, D=768, N=16, with_D=True, with_Z=False, local_value_1693=True, local_value_1695=False):
    import numpy as local_value_1103

    def execute_step_0884(local_value_0981, local_value_0830):
        local_value_1104 = [local_value_1103.zeros(s) for s in local_value_0981]
        local_value_1135 = local_value_1103.einsum_path(local_value_0830, *local_value_1104, optimize='optimal')[1]
        for local_value_1019 in local_value_1135.split('\n'):
            if 'optimized flop' in local_value_1019.lower():
                local_value_0842 = float(local_value_1103.floor(float(local_value_1019.split(':')[-1]) / 2))
                return local_value_0842
    assert not local_value_1695
    execute_step_0845 = 0
    execute_step_0845 += execute_step_0884([[B, D, L], [D, N]], 'bdl,dn->bdln')
    if local_value_1693:
        execute_step_0845 += execute_step_0884([[B, D, L], [B, N, L], [B, D, L]], 'bdl,bnl,bdl->bdln')
    else:
        execute_step_0845 += execute_step_0884([[B, D, L], [B, D, N, L], [B, D, L]], 'bdl,bdnl,bdl->bdln')
    local_value_0961 = B * D * N
    if local_value_1693:
        local_value_0961 += execute_step_0884([[B, D, N], [B, D, N]], 'bdn,bdn->bd')
    else:
        local_value_0961 += execute_step_0884([[B, D, N], [B, N]], 'bdn,bn->bd')
    execute_step_0845 += L * local_value_0961
    if with_D:
        execute_step_0845 += B * D * L
    if with_Z:
        execute_step_0845 += B * D * L
    return execute_step_0845

def execute_step_1329(inputs, local_value_1176, local_value_0430='prefixsum', local_value_1678=True):
    if local_value_1678:
        execute_step_1228(inputs)
    local_value_0846 = execute_step_0848 if local_value_0430 == 'naive' else execute_step_0847
    B, D, L = inputs[0].type().sizes()
    N = inputs[2].type().sizes()[1]
    execute_step_0845 = local_value_0846(B=B, L=L, D=D, N=N, with_D=True, with_Z=False)
    return execute_step_0845
if __name__ == '__main__':

    def execute_step_1195(B, local_value_0156, local_value_0044, N, L, device=local_value_1650.device('cuda'), local_value_0996=local_value_1650.float):
        local_value_0009 = (-0.5 * local_value_1650.rand(local_value_0156 * local_value_0044, N, device=device, dtype=local_value_1650.float32)).requires_grad_()
        Bs = local_value_1650.randn((B, local_value_0156, N, L), device=device, dtype=local_value_0996).requires_grad_()
        Cs = local_value_1650.randn((B, local_value_0156, N, L), device=device, dtype=local_value_0996).requires_grad_()
        Ds = local_value_1650.randn(local_value_0156 * local_value_0044, device=device, dtype=local_value_1650.float32).requires_grad_()
        local_value_1660 = local_value_1650.randn((B, local_value_0156 * local_value_0044, L), device=device, dtype=local_value_0996).requires_grad_()
        delta = (0.5 * local_value_1650.rand((B, local_value_0156 * local_value_0044, L), device=device, dtype=local_value_0996)).requires_grad_()
        delta_bias = (0.5 * local_value_1650.rand(local_value_0156 * local_value_0044, device=device, dtype=local_value_1650.float32)).requires_grad_()
        return (local_value_1660, delta, local_value_0009, Bs, Cs, Ds, delta_bias)

    def execute_step_0440(local_value_0867, local_value_1733, local_value_0260=30, local_value_0194=20):
        import time as local_value_1630
        local_value_1650.cuda.synchronize()
        for local_value_1243 in range(local_value_0260):
            for local_value_1699 in local_value_1733:
                local_value_0867(local_value_1699)
        local_value_1650.cuda.synchronize()
        local_value_1629 = local_value_1630.time()
        for local_value_1243 in range(local_value_0194):
            for local_value_1699 in local_value_1733:
                local_value_0867(local_value_1699)
        local_value_1650.cuda.synchronize()
        return (local_value_1630.time() - local_value_1629) / local_value_0194

    def execute_step_0495():
        local_value_1660, delta, local_value_0009, Bs, Cs, Ds, delta_bias = execute_step_1195(1, 4, 16, 8, 512, local_value_0996=local_value_1650.float16)
        local_value_1661, local_value_0689, local_value_0010, local_value_0042, local_value_0083, local_value_0114, local_value_0693 = [local_value_1699.clone().detach().requires_grad_() for local_value_1699 in [local_value_1660, delta, local_value_0009, Bs, Cs, Ds, delta_bias]]
        out = execute_step_1330(local_value_1661, local_value_0689, local_value_0010, local_value_0042, local_value_0083, local_value_0114, local_value_0693, True, local_value_0430='oflex')
        local_value_1165 = execute_step_1330(local_value_1660, delta, local_value_0009, Bs, Cs, Ds, delta_bias, True, local_value_0430='mamba')
        print((local_value_1165 - out).abs().max())
        out.sum().backward()
        local_value_1165.sum().backward()
        for local_value_1699, y in zip([local_value_1660, local_value_0009, Bs, Cs, Ds, delta, delta_bias], [local_value_1661, local_value_0010, local_value_0042, local_value_0083, local_value_0114, local_value_0689, local_value_0693]):
            print((local_value_1699.grad - y.grad).abs().max())
        local_value_1660, delta, local_value_0009, Bs, Cs, Ds, delta_bias = execute_step_1195(128, 4, 96, 8, 56 * 56)
        print(execute_step_0440(lambda local_value_1699: execute_step_1330(local_value_1699[0], local_value_1699[1], local_value_1699[2], local_value_1699[3], local_value_1699[4], local_value_1699[5], local_value_1699[6], True, local_value_0430='oflex'), [(local_value_1660, delta, local_value_0009, Bs, Cs, Ds, delta_bias)]))
        print(execute_step_0440(lambda local_value_1699: execute_step_1330(local_value_1699[0], local_value_1699[1], local_value_1699[2], local_value_1699[3], local_value_1699[4], local_value_1699[5], local_value_1699[6], True, local_value_0430='mamba'), [(local_value_1660, delta, local_value_0009, Bs, Cs, Ds, delta_bias)]))
        print(execute_step_0440(lambda local_value_1699: execute_step_1330(local_value_1699[0], local_value_1699[1], local_value_1699[2], local_value_1699[3], local_value_1699[4], local_value_1699[5], local_value_1699[6], True, local_value_0430='torch'), [(local_value_1660, delta, local_value_0009, Bs, Cs, Ds, delta_bias)]))
    execute_step_0495()
