import torch as runtime_core
if __package__:
    from .implementation.components.operators.spectral_candidates import SpectralDetailGate as DetailKernel
    from .implementation.context_engine.components.context_blocks import ContextMixingBlock as ContextKernel
else:
    from implementation.components.operators.spectral_candidates import SpectralDetailGate as DetailKernel
    from implementation.context_engine.components.context_blocks import ContextMixingBlock as ContextKernel


class SpectralContextUnit(runtime_core.nn.Module):
    def __init__(self, channel_width=16, memory_width=8, expansion_factor=2.0):
        super().__init__()
        self.content_route = runtime_core.nn.Sequential(
            DetailKernel(channel_width),
            ContextKernel(hidden_dim=channel_width, local_value_1380=memory_width,
                          local_value_1054=expansion_factor, channel_first=True, use_global_local=True),
        )

    def forward(self, feature_grid):
        return self.content_route(feature_grid)
