import torch as runtime_core
from public_entry import SpectralContextUnit

chosen_device = 'cuda' if runtime_core.cuda.is_available() else 'cpu'
chosen_unit = SpectralContextUnit(channel_width=16, memory_width=8).to(chosen_device).eval()
feature_grid = runtime_core.randn(1, 16, 8, 8, device=chosen_device)
with runtime_core.no_grad():
    print(chosen_unit(feature_grid).shape)
